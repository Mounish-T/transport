# SEATU — Project Context for AI Assistants

> **Purpose of this document:** I'm building an Indian chit fund coordination platform called SEATU. The architecture and ~70% of the v1 code has already been designed and partly written. This document gives you (the AI assistant — ChatGPT, Copilot, Gemini, or Claude Sonnet) the full context you need to help me continue the build.
>
> **How I'll use this:** I'll paste this document into a new chat with you, then ask my actual question. Refer back to this document; don't reinvent decisions that are already made.
>
> **What I expect from you:** Concrete answers that fit the patterns we've already chosen. Push back if my question conflicts with a foundational decision (Section 4) — but explain why, don't just refuse.

---

## TABLE OF CONTENTS

1. The 60-second project summary
2. What problem we're solving and for whom
3. The technical stack we've committed to
4. **NON-NEGOTIABLE foundational decisions (the 10 ADRs)**
5. The state of the codebase right now
6. What's been built (file inventory)
7. What's NOT built yet (the work that remains)
8. Key architectural patterns we use
9. Important constraints (security, compliance, legal)
10. How to ask me good questions / how I'll ask you good questions
11. Sample prompts I might send you
12. Appendix A — Full 9-phase build history

---

## 1. The 60-second project summary

**SEATU** is a mobile-first coordination platform for Indian chit funds (Tamil: *seettu*, also called *chitty*).

A chit fund is a group savings scheme: 10 people contribute ₹2,000/month for 10 months. Every month, one member wins the ₹20,000 pool through a sealed-bid auction (the lowest bidder wins, but accepts a discount that's shared among everyone else). It's both savings and credit, popular across India and especially in Tamil Nadu, Andhra Pradesh, Karnataka and Kerala.

The market is large: ₹35,000+ Cr registered annually, an unregistered market several multiples larger, tens of millions of active subscribers. But the trust infrastructure is still paper notebooks and WhatsApp groups.

**SEATU is a coordination platform — we do NOT touch money.** Members continue to pay each other via UPI/bank transfer/cash. We record evidence, run transparent auctions, build trust scores, and resolve disputes. This "coordination only" posture is what lets us launch in 14–16 weeks without RBI or Chit Funds Act licensing.

**Where we are:**
- Founder + CTO team
- 9-phase build mostly complete (see Section 6)
- Backend runnable locally, Flutter app runnable on Android emulator
- Phase 9 deployment kit ready
- Target launch: Tamil Nadu (Coimbatore + Chennai) Q3 2026

**Where we're going:**
- Year 1: 10,000 active users in TN
- Year 2: 100,000 across TN
- Year 3: South India (Karnataka, Andhra), with Kannada and Telugu
- Year 3+: trust-data financial products built on the reputation graph

---

## 2. What problem we're solving and for whom

**The user:** A 30-to-55-year-old member of a chit fund group in Tamil Nadu. Mobile-first. Smartphone-comfortable but not technical. May prefer Tamil over English. Has between 0 and 5 active chit-fund participations.

**The problem they have:**
1. Their records are in paper notebooks or scattered WhatsApp messages. When a dispute arises, there's no evidence.
2. They don't know if other members are trustworthy. A "reliable" person in one group has zero portable reputation when joining another.
3. Auctions are opaque. The foreman announces a winner, but other members didn't see the bids.
4. Foreman fraud is real and frequent. A bad foreman can pocket payouts or favor cronies.

**Our value proposition:**
1. Every contribution and payout is timestamped, with screenshot evidence.
2. A trust score (Bronze/Silver/Gold/Platinum/Diamond) follows the member across groups.
3. Sealed-bid auctions with full history visible after close.
4. Dispute workflow with evidence chain. Member trust is on the line, not just words.

**Crucially, we DON'T:**
- Handle money. Members continue to use UPI/cash directly.
- Replace the foreman. The foreman uses our tools.
- Promise returns or savings rates. We're infrastructure, not a financial product.

---

## 3. The technical stack we've committed to

### Backend
- **Runtime:** Node.js 20 LTS
- **Framework:** NestJS 10 (modular monolith)
- **Language:** TypeScript, strict mode
- **Database:** PostgreSQL 16
- **ORM:** Prisma 5.13
- **Cache / rate limiting / queues:** Redis 7 (via `ioredis`)
- **Auth:** JWT RS256 access tokens (15 min) + opaque refresh tokens (30 days)
- **Logging:** Pino with PII redaction
- **Validation:** class-validator + Zod for env
- **API doc:** OpenAPI 3.1 (one source of truth at `src/openapi.yaml`)
- **Tests:** Jest + Testcontainers for integration
- **Deploy:** Railway or Render, Mumbai (asia-south1)

### Mobile
- **Framework:** Flutter 3.22+
- **State management:** Riverpod 2 (with `riverpod_generator`)
- **Routing:** GoRouter
- **HTTP:** Dio with custom interceptors (auth, refresh, error normalisation)
- **Local storage:** `flutter_secure_storage` for tokens, `shared_preferences` for cache
- **Code generation:** `freezed` (models), `json_serializable` (parsing), `riverpod_annotation` (providers)
- **Material 3** with seed color `#0F766E` (deep teal)
- **i18n:** hand-rolled English + Tamil for v1 (will move to `gen_l10n` later)
- **Tests:** `flutter_test`, golden tests for visual regression

### External services (adapter pattern — see ADR-007)
| Purpose | Provider | Adapter file |
|---|---|---|
| SMS / OTP | MSG91 (DLT-approved) | `src/adapters/sms/sms.adapter.ts` |
| KYC (PAN + bank) | Karza | `src/adapters/kyc/kyc.adapter.ts` |
| Push notifications | Firebase Cloud Messaging | `src/adapters/push/push.adapter.ts` |
| Voucher / rewards | Qwikcilver | `src/adapters/voucher/voucher.adapter.ts` |
| File storage | Supabase Storage | `src/adapters/storage/storage.adapter.ts` |

Every adapter has a `FakeXxxAdapter` for local dev/tests and a `RealXxxAdapter` for prod. Selected by `XXX_PROVIDER=fake|real` env var.

### Observability
- **Errors:** Sentry (both backend and Flutter)
- **Product analytics:** PostHog (event funnels)

### Hosting / managed services
- **Postgres:** Supabase managed, ap-south-1
- **Redis:** Upstash, ap-south-1
- **API host:** Railway (or Render) in asia-south1
- **DNS:** Cloudflare (recommended) or any registrar

---

## 4. NON-NEGOTIABLE foundational decisions

> **READ THIS SECTION CAREFULLY.** If an AI assistant suggests changing any of these, push back. These are the design pillars; changing them invalidates large parts of the existing code.

### ADR-001: Modular monolith, not microservices

We run one NestJS process with 11 modules (IAM, Room, Auction, Ledger, Trust, Gems, Dispute, Notification, Verification, Admin, and shared infrastructure). Module boundaries are STRICT — see ADR-002.

**Why:** Two-dev team. Faster to build, easier to debug, easy to extract later when scale demands it.

**What this means:**
- One deploy artifact, one process
- Inter-module communication via in-process EventBus (not network)
- One database (with strict schema separation — see ADR-002)
- Easy to refactor while we still learn the domain

### ADR-002: One database, twelve schemas, NO cross-schema foreign keys

PostgreSQL has 12 schemas: `iam`, `room`, `auction`, `ledger`, `trust`, `gems`, `dispute`, `notification`, `verification`, `admin`, `audit`, `shared`.

Tables in one schema MUST NOT have foreign keys pointing to tables in another schema. Reference by UUID only.

**Why:** Preserves the microservice extraction path. When we extract a module to its own service later, no FK refactor is needed.

**What this means:**
- When module A needs data about module B's entity, it stores B's UUID and validates existence in code, not via FK
- Cascading deletes happen via application logic, not DB constraints
- Some "soft" data integrity (an orphan UUID is possible) — we accept that

### ADR-003: Money as `Int` paise, never floats

₹2,000 is stored as `200000` (integer paise). Currency formatters convert for display. NEVER use Decimal or Float for amounts.

**Why:** Floating-point arithmetic on currency is a notorious source of off-by-paise bugs. Integer arithmetic is exact.

### ADR-004: Event-sourced ledger with append-only enforcement

The `ledger.ledger_events` and `audit.audit_log` tables have PostgreSQL triggers that reject UPDATE and DELETE. Once written, a row is immutable.

**Why:** Trust infrastructure cannot allow even buggy code to corrupt the audit trail. Code review isn't enough — the database itself refuses.

**What this means:**
- "Undoing" a ledger event means writing a compensating event, not deleting
- Migrations that try to UPDATE these tables will fail; do data corrections via a compensating-event pattern

### ADR-005: JWT RS256 access + opaque refresh + device binding + family revocation

- Access token: JWT RS256, 15-minute TTL, contains `userId`, `deviceId`, `aud` (mobile/admin)
- Refresh token: opaque random string, 30-day TTL, stored hashed in DB
- Device binding: every request must include `X-Device-Id` header matching the JWT claim
- Family revocation: each refresh token belongs to a "family"; when a token in a family is REUSED (used twice), the entire family is revoked. Forces re-login. Defends against token theft.

### ADR-006: Five-gate authorization model

Every API request passes through up to 5 gates:
1. **Auth gate** — Bearer token valid
2. **Role gate** — user/admin/superadmin (declared via decorator)
3. **Verification gate** — required verification level (phone/PAN/bank)
4. **Tier gate** — required trust tier (Bronze+, Silver+, etc.)
5. **Membership gate** — checked in service (you must be in this specific room)

Implemented via NestJS guards + decorators. Skipping any gate is a bug.

### ADR-007: Adapter pattern with env-swappable Fake vs Real impls

Every external service (KYC, SMS, push, voucher, storage) has:
- An abstract base class defining the interface
- A `FakeXxxAdapter` for local dev and tests (logs to console, returns canned data)
- A `RealXxxAdapter` for production (real HTTP calls)
- A factory in `adapters.module.ts` that picks based on `XXX_PROVIDER` env var

Service code NEVER imports the concrete adapter — it injects the abstract base class. This makes tests fast and lets us swap providers later without business-logic changes.

### ADR-008: NO money movement in v1

**This is the most important decision in the entire architecture.**

SEATU does not handle, hold, transfer, or facilitate the transfer of money. Members pay each other via UPI/bank/cash. We record evidence (screenshots, member confirmations) but the rupees never flow through us.

**Why:** Sidesteps the Chit Funds Act 1982 licensing requirement, RBI Payment Aggregator regulations, and the operational burden of a regulated financial entity. Lets us launch in 14–16 weeks instead of 18+ months.

**Consequences:**
- Our ledger tracks *that* money moved between members, not the actual money
- "Contributions" in our system are recorded events, not transactions
- We can never accept revenue that constitutes money custody (subscription is fine; transaction fees on member-to-member flow are NOT)
- If a feature would require us to touch money flow, it's deferred to v2+ and requires a fresh regulatory opinion

### ADR-009: Idempotency-Key required on every mutating request

Every POST, PATCH, DELETE must include an `Idempotency-Key` header (client-generated UUID).

The server uses this + natural-uniqueness DB constraints to make retries safe.

### ADR-010: Tamil + English at launch, hand-rolled i18n

Day-one language support: English and Tamil. No half-translated UI.

Implementation is a simple `S.of(context).welcomeTagline` lookup in Flutter — not `intl`/`.arb` files (we'll convert later when translator workflow exists).

---

## 5. The state of the codebase right now

Two repos exist, both runnable locally:

### `seatu-backend/` — NestJS API
- ~100 files, 73 TS source files
- Boots on `pnpm start:dev`, serves at `:3000`
- Postgres + Redis run in Docker via `docker-compose.yml`
- IAM module FULLY IMPLEMENTED (auth, OTP, JWT, refresh, device binding, /me)
- Room module FULLY IMPLEMENTED (lifecycle state machine: draft → recruiting → active → cycling → completed/cancelled)
- 8 modules are SKELETONS — they have folder structure + module files + one-line method stubs that throw `NotImplementedException`. Filling them in is mechanical; each takes 1–2 dev days following the IAM/Room patterns.
- All 5 adapter implementations (MSG91, Karza, FCM, Qwikcilver, Supabase) are written — they make real HTTP calls
- One integration test (`test/integration/onboarding.spec.ts`) validates the full auth flow against Testcontainers Postgres+Redis
- Deploy configs: `railway.json`, `render.yaml`, `.github/workflows/deploy.yml`, `scripts/smoke.ts`

### `seatu-app/` — Flutter mobile
- ~50 Dart files in `lib/`
- Boots on `flutter run`
- Auth feature FULLY IMPLEMENTED (welcome → phone → OTP → home)
- Rooms feature FULLY IMPLEMENTED (list, create, detail, lifecycle actions)
- 4 stub tabs: trust, gems, auctions, notifications — empty screens with TODO text
- Material 3 theme with deep teal seed color
- Tamil + English hand-rolled i18n
- Phase 7 state management: cache-then-network, optimistic UI for room lifecycle, app lifecycle observer, offline banner
- Phase 8 tests: 10 test files (helpers + widget tests + cache box integration + the critical optimistic-rollback test + tier badge golden)
- Phase 9: Sentry + PostHog wired in `main.dart`, env configs in `env/`

### `seatu-deploy-kit/` — operations
- `SEATU-Launch-Runbook.md` — the procedural document for going live
- `legal/privacy-policy.template.md` and `legal/terms-of-service.template.md` — starting points needing lawyer review
- `store-listing/store-copy.md` — Play Store + App Store copy in English and Tamil

---

## 6. What's been built (file inventory)

For each phase, the documents/files that exist:

| Phase | What exists | Status |
|---|---|---|
| 1: PRD | `SEATU-PRD-Phase1.md` (24 pages, ~6,600 words) | Done |
| 2: Architecture | `SEATU-Architecture-Phase2.md` (~5,200 words) + 10 ADRs | Done |
| 3: Database | `SEATU-Database-Phase3.md` + `prisma/schema.prisma` (924 lines) + migrations + seed | Done |
| 4: API | `SEATU-API-Design-Phase4.md` + `src/openapi.yaml` (2,274 lines, 76 paths, 81 operations) | Done |
| 5: Backend | `seatu-backend/` (100 files) — IAM + Room fully built, 8 skeleton modules, all adapters | Partial (2 of 10 modules) |
| 6: Mobile | `seatu-app/` (~50 Dart files) — auth + rooms fully built, 4 stub tabs | Partial (2 of 6 features) |
| 7: State mgmt | Cache, optimistic UI, offline banner, lifecycle observer | Done |
| 8: Tests | 10 test files including critical optimistic-rollback proof | Done (critical paths) |
| 9: Deploy | Real adapter implementations + deploy configs + runbook + legal templates | Done (waiting on lawyer review and provider onboarding) |

Plus two synthesis documents from later in the conversation:
- `SEATU-Complete-Procedure.md` — strategic recap of all 9 phases, short-term vs long-term tracks
- `SEATU-Developer-Walkthrough.md` — hands-on tutorial: blank machine to running system

---

## 7. What's NOT built yet (the work that remains)

This is the explicit TODO list. Group by area:

### Backend Phase 5.1 — finish the 8 skeleton modules

Each follows the IAM/Room pattern. Per-module estimated effort listed.

| # | Module | Effort | Notes |
|---|---|---|---|
| 1 | **Verification** | 2 days | KYC endpoints (start PAN, start bank); wire to Karza adapter; store last4 + match scores only (per ADR — never full PAN/account) |
| 2 | **Auction** | 3 days | Open auction, place sealed bid, close, settle tie-breakers (lowest bid → earliest timestamp → trust score). Subscribes to room.cycle_started event. |
| 3 | **Ledger** | 2 days | Append-only event store. Records contribution/payout/penalty events. Computed balances are projections. |
| 4 | **Trust** | 2 days | Score calculation rules (on-time contribution +X, missed -Y, dispute outcome ±Z). Tier thresholds: bronze 0–199, silver 200–499, gold 500–799, platinum 800–949, diamond 950+. |
| 5 | **Gems** | 1.5 days | Earn rules (gem ladder by trust score increases). Redemption flow calls Qwikcilver adapter. |
| 6 | **Dispute** | 2.5 days | File dispute, respond within 7 days, optional escalation to admin, decision affects trust score |
| 7 | **Notification** | 2 days | User preferences, outbox event consumers, deduplication, FCM + SMS dispatch |
| 8 | **Admin** | 1.5 days | Internal endpoints for trust adjustments, dispute resolution, suspending users |

### Backend integration tests outstanding

| Test file | Flow | Effort |
|---|---|---|
| `room-lifecycle.spec.ts` | create → publish → join (×5) → start → cycle → complete | 1 day |
| `auction-cycle.spec.ts` | open → bid (×4) → close → tie-break → payout recorded | 1 day |
| `contribution-dispute.spec.ts` | mark-paid → confirm → dispute → respond → decide | 1.5 days |

### Mobile Phase 6.1 — fill out the stub features

| # | Screen / feature | Effort | Notes |
|---|---|---|---|
| 1 | **Verification screens (KYC)** | 3 days | PAN entry → call backend → result. Bank entry → call backend → result. Bilingual. Match-score thresholds explained in UI. |
| 2 | **Contribution mark-paid + screenshot upload** | 3 days | Member uploads payment screenshot, foreman confirms. Uses signed-URL upload via Supabase. |
| 3 | **Auction screen** | 4 days | View open auctions, place sealed bid (UI hides other bids), view history after close. Countdown timer driven by `closes_at` not server push. |
| 4 | **Dispute file + respond** | 4 days | Multi-step form. Evidence attachments. Response within 7 days countdown. |
| 5 | **Gem redemption marketplace** | 3 days | Browse vouchers, redeem with gems, voucher code revealed after redemption (encrypted in DB per ADR). |
| 6 | **Trust tier detail screen** | 1.5 days | History of trust score changes. Tier benefits explained. |
| 7 | **Notification inbox + push handling** | 2 days | `firebase_messaging` plug, deep-link handling, mark-as-read. |
| 8 | **Tamil-language professional review** | n/a | A native Tamil speaker (preferably a copywriter) should review every string. The current Tamil was hand-translated; verify register and tone. |

### Launch prep — non-engineering

| Task | Owner | Lead time |
|---|---|---|
| MSG91 account + DLT registration (TRAI) | Founder | 2–3 business days for DLT, plus template approval |
| Karza production credentials | Founder | 1 week |
| FCM Firebase project + service account JSON | CTO / dev | Same day |
| Qwikcilver partner onboarding | Founder | 3–5 business days for KYC |
| Sentry + PostHog accounts (free tier OK) | CTO / dev | Same day |
| Lawyer review of `legal/privacy-policy.template.md` and `terms-of-service.template.md` | Founder | 2–3 weeks |
| Chit Funds Act 1982 opinion in writing | Founder | 2 weeks |
| Designer engagement: app icon (512x512 + 1024x1024), feature graphic (1024x500), 6 screenshots in both locales | Founder | 1 week |
| Privacy policy + ToS hosted at seatu.in/privacy and /terms | CTO | Same day after lawyer sign-off |
| Hosting setup (Railway/Render) + Postgres (Supabase ap-south-1) + Redis (Upstash ap-south-1) | CTO | 1 day |
| DNS pointing api.seatu.in → host | CTO | Same day |
| Android signing keystore + Play Console internal track | CTO | 1 day |
| App Store account (deferred for v1 if Android-first) | Founder | 1 week |

---

## 8. Key architectural patterns we use

These are patterns you'll see referenced in code or in my questions. Use them when suggesting new code.

### Backend pattern: a feature module

```
src/modules/<feature>/
├── <feature>.module.ts          // NestJS module wiring
├── controllers/
│   └── <feature>.controller.ts  // HTTP handlers; thin
├── services/
│   └── <feature>.service.ts     // business logic; transaction boundaries
├── dto/
│   ├── <action>.dto.ts          // class-validator DTOs
│   └── index.ts
├── events/
│   └── <feature>.events.ts      // event classes published to EventBus
└── policies/
    └── <feature>.policies.ts    // authorization rules
```

Each `<feature>.service.ts` injects:
- `PrismaService` (DB)
- `AuditService` (writes audit log; auto-includes request context)
- `EventBus` (publishes domain events)
- Any adapters needed (`KycAdapter`, `SmsAdapter`, etc.)

### Backend pattern: a transactional write

```typescript
async publishRoom(roomId: string, userId: string): Promise<Room> {
  return this.prisma.$transaction(async (tx) => {
    // 1. State machine check
    const room = await tx.room.findUniqueOrThrow({ where: { id: roomId } });
    this.assertCanTransition(room.status, 'recruiting');
    
    // 2. Mutate
    const updated = await tx.room.update({
      where: { id: roomId },
      data: { status: 'recruiting' },
    });
    
    // 3. Audit log in same tx
    await this.auditService.log(tx, {
      actorUserId: userId,
      action: 'room.published',
      entityType: 'room',
      entityId: roomId,
    });
    
    // 4. Publish event in same tx (durable outbox pattern)
    await this.eventBus.publish(tx, new RoomPublishedEvent(roomId));
    
    return updated;
  });
}
```

The `EventBus.publish(tx, ...)` writes to an `outbox_events` table inside the same transaction. A separate `OutboxDispatcher` worker reads pending events and fires the side effects (push, SMS, etc.) — at-least-once delivery.

### Flutter pattern: a feature

```
lib/features/<feature>/
├── data/
│   └── <feature>_api.dart       // Dio calls; returns domain types
├── domain/
│   └── <model>.dart             // freezed model + fromJson/toJson
├── application/
│   └── <feature>_controller.dart // Riverpod controllers / providers
└── presentation/
    ├── screens/
    │   └── <screen>_screen.dart
    └── widgets/
        └── ...
```

Imports flow strictly downward: presentation → application → domain → data. Never the other way.

### Flutter pattern: optimistic UI

(This is what Phase 7 added. Use this pattern for any UI mutation where rollback is acceptable.)

```dart
Future<Room?> _optimistic({
  required String id,
  required String nextStatus,
  required Future<Room> Function(RoomsApi) op,
}) async {
  // 1. Snapshot
  final notifier = ref.read(roomsListProvider().notifier);
  final previous = ref.read(roomsListProvider()).valueOrNull;
  
  // 2. Apply locally (UI updates instantly)
  if (previous != null) {
    notifier.state = AsyncData(
      previous.map((r) => r.id == id ? r.copyWith(status: nextStatus) : r).toList(),
    );
  }
  
  try {
    // 3. Fire request
    final result = await op(ref.read(roomsApiProvider));
    // 4. Reconcile (server is source of truth)
    ref.invalidate(roomsListProvider);
    return result;
  } catch (e) {
    // 5. Rollback on failure
    if (previous != null) notifier.state = AsyncData(previous);
    rethrow;
  }
}
```

### Error envelope (the wire format)

Every error response from the API uses this shape:

```json
{
  "error": {
    "code": "PERM_VERIFICATION_REQUIRED",
    "message": "PAN verification required for rooms above ₹50,000",
    "user_message": "Please complete PAN verification to join this room",
    "details": { "required_verification": "pan" },
    "request_id": "req-abc123"
  }
}
```

Clients switch on `code`, never on HTTP status (which is still set correctly — 4xx/5xx — but only for HTTP infrastructure). Codes are a shipped contract — once published, never renamed.

The full catalogue of error codes lives in `src/shared/errors/error-codes.ts` on the backend and `lib/core/error/error_codes.dart` on the Flutter side.

---

## 9. Important constraints (security, compliance, legal)

### Security must-haves

- Tokens NEVER logged. Pino redaction is configured in `src/shared/logging/`.
- PAN and bank account numbers NEVER stored in full. Only last4 + name-match-score. The KYC adapter returns these — the service never sees the full values.
- Voucher codes encrypted with AES-256-GCM before DB storage using `APP_ENCRYPTION_KEY`.
- All admin endpoints (`/v1/admin/*`) require the `admin` JWT audience claim, not just a user token.
- Refresh-token reuse detection (Section ADR-005) is critical. Do not weaken it for UX reasons.

### Compliance

- **DPDP Act 2023** (India's privacy law): grievance officer named in privacy policy is REQUIRED. Templates in `seatu-deploy-kit/legal/` have a `[LAWYER]` marker on this point.
- **Chit Funds Act 1982**: this is why Posture A (no money handling) exists. ANY feature that touches money flow triggers a fresh regulatory opinion. Don't go there casually.
- **TRAI / DLT**: all SMS templates must be DLT-registered. MSG91 enforces this; production won't send if a template isn't approved.
- **Play Store / App Store**: account deletion path in-app is REQUIRED. Phase 6.1 task.

### Things explicitly out of scope for v1

These have come up in conversations and we've explicitly deferred them. If the AI suggests adding them, decline:

- Money custody, money transmission, payment processing
- Web client (mobile-only for v1)
- iOS (optional for v1 — Android-first per market research)
- Open-bid auctions (sealed-bid only)
- Real-time updates via WebSocket / SSE
- Multi-currency
- Multi-tenant / B2B SaaS (Enterprise SaaS comes Year 2)
- Offline-queued writes (read caching is fine; writes need server confirmation)
- Government regulatory integrations (none until we change posture)

---

## 10. How to ask good questions / how I'll ask you good questions

### When I ask you something, I will try to:

1. **State the constraint.** Example: "I need to add X without changing the database schema."
2. **Include the relevant code.** If asking about a specific file, paste it (or the relevant section).
3. **Say what I've already tried.** Especially when debugging.
4. **Reference the relevant ADR** if my question touches a foundational decision.

### When you answer me, please:

1. **Fit the existing patterns.** Look at IAM module for backend pattern, auth/rooms features for Flutter pattern. Don't suggest a new architecture for a small feature.
2. **Match the code style.** TypeScript: strict typing, no `any`. Dart: clean architecture imports, prefer immutable models via freezed.
3. **Push back on constraint violations.** If my question would require touching money flow (violating ADR-008), tell me. If it'd require a cross-schema FK (violating ADR-002), tell me.
4. **Be concrete.** Give me code, not concepts. If the answer needs context I haven't provided, ask for the specific file.
5. **Flag uncertainty.** If you're not sure whether a library version supports what I'm asking, say so and tell me how to verify.
6. **Don't reinvent solved problems.** If I ask about auth, the answer probably involves the IAM module patterns — not "let's build OAuth from scratch."

### Things you might not know

You may not have current information about:
- Specific Indian regulatory changes (DPDP rules are still being published)
- Karza/MSG91/Qwikcilver API specifics (their docs change)
- Latest Flutter / NestJS / Prisma feature releases

When in doubt, recommend I check the official docs and don't fabricate specifics.

---

## 11. Sample prompts I might send you

These are real shapes of questions I'll ask. They show the level of context I'll give and the answer shape I expect.

### Example 1 — "Help me implement the Verification module"

> I'm implementing the Verification module in the backend. It's currently a skeleton. The pattern to follow is the IAM module at `src/modules/iam/`.
>
> Need:
> - `POST /v1/verification/pan/start` — accepts `{ pan: string, name_on_pan: string }`, calls Karza adapter via `KycAdapter.verifyPan()`, stores result in `verification.verification_results` table (only last4 + score, never full PAN), returns success/failure with code.
> - `POST /v1/verification/bank/start` — same shape for bank.
> - Both must be idempotent via the standard Idempotency-Key pattern.
> - Both write to audit log within the same transaction.
> - Both publish a `VerificationCompletedEvent` to the EventBus.
>
> Give me the controller, service, DTOs, and event class. Skip the module wiring file — I'll write that myself.

### Example 2 — "Why is my optimistic publish flickering?"

> The optimistic publish on the rooms list is flickering. When I tap "Publish", the status goes draft → recruiting → draft → recruiting. The final state is correct but the user sees the flicker.
>
> Here's my controller code: [paste rooms_controller.dart]
>
> Here's the network log: [paste]
>
> The backend returns 200 quickly. What's causing the double swap?

### Example 3 — "Add a feature that..."

> I want to add a feature where, when a foreman publishes a room, the system automatically sends an SMS to all members with an invitation link.
>
> Constraints:
> - This is a server-side reaction to room.published event
> - Must work even if SMS provider is temporarily down (retry)
> - Cannot affect the publish transaction (don't block the foreman's request)
>
> Walk me through where this code goes. Don't write the full implementation yet.

### Example 4 — "Is this safe?"

> Someone suggested we let users self-register their PAN number directly (skipping Karza). They argue Karza is expensive. Is this OK?

(Expected pushback: violates ADR-008-adjacent compliance posture. Self-attested PAN isn't verification; it's just data collection. Users will fake it. Risk model breaks. Karza isn't optional for our trust score.)

---

## 12. Appendix A — Full 9-phase build history

This is the chronology of how the project was built. Each phase had its own design doc. Reference them in your repo if you want the full reasoning.

### Phase 1 — Product Requirements (PRD)

**Output:** `SEATU-PRD-Phase1.md` (24 pages)

**Key decisions:**
- Three postures considered (A: coordination only, B: own foreman, C: financial partner). Chose A.
- Trust score model: 5 tiers from Bronze to Diamond, starting score 100
- Gems reward marketplace: vouchers only (Amazon, Flipkart, BookMyShow), never cash
- Explicit non-goals: money movement, web client, iOS for v1, real-time auctions
- Timeline: 14–16 weeks, 2 developers

### Phase 2 — System Architecture

**Output:** `SEATU-Architecture-Phase2.md` + 10 ADRs

**Key decisions:** The 10 ADRs in Section 4 above. Most important: modular monolith (ADR-001), schema separation (ADR-002), event-sourced ledger (ADR-004), no money movement (ADR-008).

### Phase 3 — Database design

**Output:** `prisma/schema.prisma` (924 lines) + migrations + seed

**Key decisions:**
- 12 schemas, no cross-schema FKs
- Money as Int paise
- Timestamps `timestamptz` UTC, formatted as ISO 8601 with offset on the wire
- Append-only triggers on `ledger.ledger_events` and `audit.audit_log`
- PII minimisation (PAN/bank last4 only)
- Natural uniqueness for idempotency (e.g., `UNIQUE (room_id, cycle, user_id)` on contributions)
- Seed: 10 users in various tiers, 5 rooms in various states, 1 open auction

### Phase 4 — API design

**Output:** `src/openapi.yaml` (2,274 lines, 76 paths, 81 operations, 66 schemas)

**Key decisions:**
- REST + OpenAPI 3.1 (not GraphQL)
- 5-gate authorization (auth → role → verification → tier → membership)
- JWT RS256 + opaque refresh + device binding + family revocation
- Stable error envelope with `code` as primary contract
- Cursor pagination (never offset)
- Mandatory `Idempotency-Key` on all writes
- Signed-URL uploads to Supabase (server never sees bytes)
- Sealed-bid auctions

### Phase 5 — Backend implementation

**Output:** `seatu-backend/` (100 files, 73 TS sources)

**Key decisions:**
- Built shared infrastructure first (Prisma, request context, errors, logging, JWT, policy guard, idempotency interceptor, audit, EventBus, Outbox, rate limiter, pagination)
- Adapter pattern with Fake/Real for all 5 external services
- IAM module fully implemented as reference
- Room module fully implemented with lifecycle state machine
- 8 modules as skeletons with one-line stubs
- One integration test for onboarding flow against Testcontainers Postgres+Redis

### Phase 6 — Mobile UI

**Output:** `seatu-app/` (~50 Dart files)

**Key decisions:**
- Flutter (not React Native, not native)
- Clean architecture per feature (data → domain → application → presentation)
- Dio with three interceptors (auth, refresh, error)
- Auth-aware GoRouter (redirects unauthenticated to welcome)
- Material 3, deep teal #0F766E seed
- 52px buttons (bigger than M3 default — better for older users)
- Hand-rolled i18n (Tamil + English)
- Error code → user UX mapping (specific codes get specific UX, not generic snackbars)

### Phase 7 — State management

**Output:** Cache layer + optimistic UI + lifecycle + offline banner additions

**Key decisions:**
- Cache-then-network reads with stale-while-revalidate
- `CacheBox` over `shared_preferences` (small data, no Hive complexity)
- 5-minute default TTL, 24× TTL hard expiry
- Optimistic UI on room lifecycle transitions (snapshot → flip → reconcile/rollback)
- App-foreground-resume refresh via `WidgetsBindingObserver` (composition, not inheritance)
- Offline banner via `connectivity_plus` (doesn't short-circuit requests)
- WebSocket/SSE explicitly deferred — sealed-bid doesn't need it

### Phase 8 — Testing

**Output:** 10 test files (3 helpers + 7 tests)

**Key decisions:**
- `FakeDioAdapter` (programmable `HttpClientAdapter`) + `buildTestApp()` helper as the pattern
- One critical test: optimistic publish rollback (proves Phase 7 pattern works)
- One golden test: tier badge (5 tiers, single image)
- Coverage thresholds deliberately NOT enforced (incentive trap)
- Backend integration tests deferred until Phase 5.1 modules exist

### Phase 9 — Deployment

**Outputs:** 
- Real adapter implementations (MSG91, Karza, FCM, Qwikcilver, Supabase)
- `railway.json`, `render.yaml`, `.github/workflows/deploy.yml`, `scripts/smoke.ts`
- Sentry + PostHog in Flutter `main.dart`
- `env/{dev,staging,production.example}.json`
- `SEATU-Launch-Runbook.md` (the procedural launch document)
- Legal templates + store listing copy

---

## End of context

You now have the full project context. When I send my next message, please:

1. Acknowledge that you've read this primer
2. Answer my specific question following the conventions above
3. If my question is ambiguous, ask one clarifying question before answering

Let's build.
