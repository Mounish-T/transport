# SEATU — API Design

**Phase 4 Deliverable · v0.1 (Draft)**
**Owner:** CTO
**Status:** Awaiting founder review before Phase 5 (Backend Implementation)
**Date:** June 2026
**Companion file:** `openapi.yaml` (OpenAPI 3.1 spec, code-gen ready)

---

## 0. What this document covers

The OpenAPI YAML is the **authoritative wire contract**. This markdown explains the decisions that the YAML doesn't and gives detailed prose specs for the non-obvious endpoints.

1. Working assumptions (§1)
2. API design principles (§2)
3. Versioning policy (§3)
4. Authentication model (§4)
5. Authorization model: roles × verification × tier × membership (§5)
6. Request / response conventions (§6)
7. Error model + complete error catalogue (§7)
8. Pagination contract (§8)
9. Rate-limit contract + per-endpoint matrix (§9)
10. Idempotency contract (§10)
11. File upload via signed URLs (§11)
12. Full endpoint inventory (§12)
13. Detailed specs for non-obvious endpoints (§13)
14. Authorization matrix (§14)
15. Anti-patterns we explicitly avoid (§15)
16. Phase 5 handoff (§16)

---

## 1. Working assumptions

Unchanged from prior phases. The two that shape API design most:

- **OQ-3: no money movement in MVP.** No payment-gateway callbacks, no settlement webhooks. The contribution / payout endpoints operate on user-supplied evidence (UPI reference + screenshot), not on real money events.
- **Mobile-first.** Flutter Android first, iOS v1.1. No web client in v1. The API is therefore designed for mobile networks (small payloads, idempotency, signed-URL uploads, offline-tolerant clients).

---

## 2. API design principles

The fifteen rules below are non-negotiable. Every endpoint follows them.

| # | Rule | Why |
|---|---|---|
| 1 | **Resources are nouns; verbs are HTTP methods.** No `/getRoom`, `/createUser`. | REST discipline. |
| 2 | **`/v1/` prefix on every path.** Never break v1; add v2 in parallel when needed. | Mobile clients can't be force-upgraded. |
| 3 | **Plural resources** (`/rooms`, `/auctions`). | Convention. |
| 4 | **kebab-case in URLs, snake_case in JSON.** | URLs are user-visible-ish; JSON matches Dart-via-codegen + Python conventions. |
| 5 | **Money is `*_paise` integers + `currency` field.** Never `amount` alone. | Avoids unit ambiguity in code review. |
| 6 | **Timestamps are ISO 8601 with offset** (`2026-06-02T15:30:00+05:30`). UTC accepted on input, IST returned by default; `?tz=utc` switches. | Forces honest TZ handling. |
| 7 | **Enums are lowercase_snake_case strings**, not ints. Stable forever. | Stable contracts; readable in logs. |
| 8 | **UUIDs are lowercase with hyphens.** | One format, one regex. |
| 9 | **Phone numbers are E.164** (`+919900000001`). | Single representation; KYC providers expect it. |
| 10 | **One way to do each thing.** No "shortcut" endpoints that duplicate a sequence. | Easier to reason about; easier to audit. |
| 11 | **List endpoints always paginate.** No `?limit=10000`. Hard cap 100. | DoS protection. |
| 12 | **Idempotency on every state change.** See §10. | Mobile retries are not optional. |
| 13 | **Errors carry stable `error_code` + localised `user_message` + structured `details`.** | App keys behaviour off code, not message. |
| 14 | **`X-Request-Id` header is echoed back; clients should log it.** Generated server-side if absent. | Support is unworkable without it. |
| 15 | **No sensitive data in URLs or query strings.** Phone, PAN, OTP, refresh token all in bodies/headers only. | URLs leak via logs and analytics. |

---

## 3. Versioning policy

- **`/v1/*`** is the only version in MVP and Track B's foreseeable horizon.
- **Additive changes only** within v1: new endpoints, new optional request fields, new response fields. Existing fields never change type, never change meaning.
- **Deprecation, not deletion.** When something is replaced, the old endpoint stays for at least 12 months, returns a `Deprecation` header (RFC 8594), and emits an alert on use.
- **Breaking change = `/v2/`.** New base path, both run in parallel for at least 6 months.
- **`X-Api-Version: 1`** header echoed on every response. Used for diagnostics.

---

## 4. Authentication model

### 4.1 Token lifecycle

```
   Phone OTP                       Refresh                       Refresh
       │                             │                              │
       ▼                             ▼                              ▼
 ┌───────────┐  Access(15m)   ┌───────────┐  Access(15m)     ┌───────────┐
 │  Tokens   │ ─────────────▶ │  Tokens   │ ──────────────▶  │  Tokens   │
 │  issued   │  Refresh(30d)  │  rotated  │  Refresh(30d)    │  rotated  │
 └───────────┘                └───────────┘                  └───────────┘
       │
       │ if any older refresh in this chain is reused → entire family revoked
       └────────────────────────────────────────────────────────────────────▶
```

### 4.2 Token formats

| Token | Format | Where carried | Storage on client |
|---|---|---|---|
| Access | JWT (RS256), 15-min TTL | `Authorization: Bearer <jwt>` | Memory only |
| Refresh | Opaque 32-byte url-safe random string, 30-day TTL | Request body of `POST /v1/auth/refresh`, never URL | `flutter_secure_storage` (Keystore/Keychain) |

**JWT claims (access):**
```json
{
  "iss": "https://api.seatu.in",
  "sub": "<user_uuid>",
  "aud": "seatu-mobile",
  "iat": 1764703800,
  "exp": 1764704700,
  "jti": "<token_uuid>",
  "device_id": "<device_uuid>",
  "roles": ["admin"]            // omitted for plain members
}
```

**`aud`** is `seatu-mobile` for user tokens and `seatu-admin` for admin tokens. Cross-audience tokens are rejected. Admins logging into the app and admins logging into the ops console use separate token pipelines.

### 4.3 Device binding

The first device for a user is bound at OTP verify time. Subsequent logins from a new device fingerprint require fresh OTP. The client sends:

```
X-Device-Id: <client-generated-uuid-v4>     # stable across reinstalls (best-effort)
X-Device-Fingerprint: <hex64>               # SHA-256(device_id || install_id || os || model)
X-App-Version: 1.0.3
```

The server computes its own fingerprint from these and compares against the bound device for the user. Mismatch → `AUTH_DEVICE_MISMATCH` (401), client must re-OTP.

### 4.4 What's NOT a header

- No API keys. (No third-party API consumers in v1.)
- No basic auth.
- No cookies. (Mobile clients only.)
- No HMAC request signing in v1. Reconsider for Track B once any third party calls our API.

---

## 5. Authorization model

Five dimensions stack to produce an "allowed?" decision. Endpoints declare requirements; a single guard evaluates them.

### 5.1 The five gates

| Gate | Values | Determined by |
|---|---|---|
| **Authentication** | unauthenticated / authenticated | Valid access JWT present |
| **Role** | member (implicit) / foreman (derived) / admin / superadmin | `iam.user_roles` + room ownership |
| **Verification level** | none / phone / pan / bank / pan_and_bank / aadhaar | `verification.verification_results` |
| **Trust tier** | bronze / silver / gold / platinum / diamond | `trust.trust_score_current.tier` |
| **Room membership** | not-a-member / member / foreman-of-room | `room.room_members` + `room.rooms.foreman_user_id` |

### 5.2 Verification level rules (consumed in Trust Gate flow)

- A room with `contribution_amount_paise > 10,00,000` (₹10k) requires every member to have `pan` verified.
- A room with `contribution_amount_paise > 1,00,00,000` (₹1L) requires `pan_and_bank`.
- (Track B) ≥ ₹5L requires `aadhaar`.
- Becoming a foreman requires `pan_and_bank`.
- Redemption above 1000 gems requires `pan` (anti-abuse).

### 5.3 Velocity rules (applied at endpoint level)

| Rule | Endpoint affected |
|---|---|
| Account age < 15 days → cannot join rooms > ₹10k | `POST /v1/rooms/:id/join` |
| Account age < 30 days → cannot create rooms | `POST /v1/rooms` |
| Tier `bronze` → max 1 active room | `POST /v1/rooms/:id/join`, `POST /v1/rooms` |
| Tier `silver` → max 2 active rooms | same |
| Tier `gold` → max 3 active rooms | same |
| Tier `platinum` → max 5 active rooms | same |
| Default removed in last 90d → restricted to ≤ ₹10k rooms | join/create |

Failure → `PERM_VELOCITY_LIMIT` (403) with `details` explaining which rule fired.

---

## 6. Request / response conventions

### 6.1 Required request headers (every authenticated request)

```
Authorization: Bearer <access_jwt>
X-Device-Id: <uuid>
X-App-Version: <semver>
Accept: application/json
Content-Type: application/json; charset=utf-8        # on requests with body
Accept-Language: en | ta                              # optional; defaults to user.language
Idempotency-Key: <uuid-v4>                            # required on POST/PATCH/DELETE
X-Request-Id: <uuid>                                  # optional; server generates if absent
```

### 6.2 Response envelope

We do **not** wrap responses in a generic `{data, meta}` envelope. The response body **is** the resource. Lists use `{items, next_cursor}`.

```json
// GET /v1/me
{
  "id": "8c2e...",
  "phone": "+919900000001",
  "name": "Lakshmi",
  "language": "ta",
  "tier": "gold",
  "score": 580,
  "created_at": "2024-08-12T09:00:00+05:30"
}

// GET /v1/me/contributions
{
  "items": [{...}, {...}],
  "next_cursor": "eyJ0Ijoi..."
}
```

**Why no envelope:** Dart clients deserialise directly into typed models; an envelope adds boilerplate without buying anything once typed errors are separate (§7).

### 6.3 Response headers (always)

```
X-Request-Id: <uuid>                  # echoed or generated
X-Api-Version: 1
X-Ratelimit-Limit: 100
X-Ratelimit-Remaining: 96
X-Ratelimit-Reset: 1764704700
```

### 6.4 Money in requests/responses

Always paired:

```json
"contribution": {
  "amount_paise": 1000000,
  "currency": "INR"
}
```

Never just `"amount": 10000`. The field name itself states the unit.

### 6.5 Phone numbers

E.164 only. `+91` prefix mandatory. No spaces, no hyphens, no parentheses. Validation: `^\+[1-9]\d{6,14}$`.

### 6.6 No nullable enums

Optional enums are absent from the response, not `null`. e.g. an open auction omits `winner_user_id` entirely until close. Reduces "what does null mean" ambiguity.

---

## 7. Error model and complete error catalogue

### 7.1 Error response shape

```json
{
  "error": {
    "code": "ROOM_TRUST_GATE_FAILED",
    "message": "Your current tier does not allow joining this room.",
    "user_message": "உங்கள் தற்போதைய மட்டம் இந்த அறையில் சேர அனுமதிக்கவில்லை.",
    "details": {
      "user_tier": "bronze",
      "required_tier": "silver",
      "room_contribution_paise": 5000000
    },
    "request_id": "9c7d12af-..."
  }
}
```

| Field | Required | Notes |
|---|---|---|
| `code` | always | Stable, screaming snake case. App switches on this. |
| `message` | always | English, technical-ish. For logs. |
| `user_message` | always | Localised per `Accept-Language`. Safe to display. |
| `details` | optional | Structured; shape depends on `code`. |
| `request_id` | always | For support. |

### 7.2 Status code map

| HTTP | When |
|---|---|
| 200 | Success with body |
| 201 | Resource created |
| 202 | Accepted asynchronously (e.g., KYC submitted, awaiting result) |
| 204 | Success with no body (DELETE, mark-read) |
| 400 | Request shape invalid (validation) |
| 401 | Not authenticated, token expired/invalid, device mismatch |
| 403 | Authenticated but not permitted (role, tier, verification, velocity, membership) |
| 404 | Resource not found *or* not visible to caller (we don't leak existence) |
| 409 | State conflict, duplicate, idempotency-key mismatch |
| 410 | Resource permanently gone (cancelled room access after grace) |
| 422 | Request is well-formed but semantically rejected (e.g., bid exceeds 40% cap) |
| 429 | Rate limited |
| 500 | Bug — never expected; logged loud |
| 502 | Downstream provider failure (KYC, SMS) |
| 503 | We are throttling intentionally (maintenance) |

### 7.3 Complete error catalogue

#### Auth

| Code | HTTP | When |
|---|---|---|
| `AUTH_REQUIRED` | 401 | No token on protected route |
| `AUTH_TOKEN_INVALID` | 401 | Signature, structure, or claims invalid |
| `AUTH_TOKEN_EXPIRED` | 401 | Past `exp` |
| `AUTH_TOKEN_REVOKED` | 401 | Logged out / revoked |
| `AUTH_DEVICE_MISMATCH` | 401 | Token's `device_id` differs from header |
| `AUTH_TOKEN_REUSE_DETECTED` | 401 | Old refresh token replayed → family revoked |
| `AUTH_OTP_INVALID` | 401 | Wrong OTP |
| `AUTH_OTP_EXPIRED` | 401 | OTP older than 5 min |
| `AUTH_OTP_TOO_MANY_ATTEMPTS` | 429 | >3 wrong OTPs on the same code |
| `AUTH_OTP_RATE_LIMITED` | 429 | OTP request rate limit hit |

#### Permission / authorisation

| Code | HTTP | When |
|---|---|---|
| `PERM_INSUFFICIENT_ROLE` | 403 | Endpoint needs admin/superadmin |
| `PERM_VERIFICATION_REQUIRED` | 403 | KYC level insufficient. `details.required` lists what's needed. |
| `PERM_TRUST_TIER_INSUFFICIENT` | 403 | Tier below endpoint minimum |
| `PERM_ROOM_NOT_MEMBER` | 403 | Caller isn't in this room |
| `PERM_ROOM_NOT_FOREMAN` | 403 | Caller isn't the foreman of this room |
| `PERM_VELOCITY_LIMIT` | 403 | Velocity rule fired |
| `PERM_ACCOUNT_SUSPENDED` | 403 | Account `status='suspended'` |
| `PERM_ACCOUNT_FLAGGED` | 403 | Restrictive flag set |

#### Validation

| Code | HTTP | When |
|---|---|---|
| `VALIDATION_FAILED` | 400 | DTO failed class-validator. `details.fields` lists each. |
| `BODY_MALFORMED` | 400 | Not JSON / unparseable |
| `IDEMPOTENCY_KEY_MISSING` | 400 | POST/PATCH/DELETE without header |
| `IDEMPOTENCY_KEY_MISMATCH` | 409 | Same key, different body |

#### Resources

| Code | HTTP | When |
|---|---|---|
| `RESOURCE_NOT_FOUND` | 404 | Generic "not found / not visible" |
| `RESOURCE_GONE` | 410 | Cancelled / expired |
| `RESOURCE_CONFLICT` | 409 | Generic state conflict |

#### Rooms

| Code | HTTP | When |
|---|---|---|
| `ROOM_INVALID_TRANSITION` | 409 | E.g., start when not recruiting |
| `ROOM_FULL` | 409 | Member count target reached |
| `ROOM_TRUST_GATE_FAILED` | 403 | User's tier below room's required tier |
| `ROOM_CAP_EXCEEDED` | 403 | Active-room cap by tier hit |
| `ROOM_NOT_RECRUITING` | 409 | Trying to join after recruiting closed |
| `ROOM_CODE_INVALID` | 404 | No such code, or expired |
| `ROOM_CANCELLED` | 410 | Room is cancelled |

#### Invitations

| Code | HTTP | When |
|---|---|---|
| `INVITATION_EXPIRED` | 410 | Past `expires_at` |
| `INVITATION_CONSUMED` | 409 | Already accepted |
| `INVITATION_PHONE_MISMATCH` | 403 | Phone doesn't match the invited number |

#### Auctions

| Code | HTTP | When |
|---|---|---|
| `AUCTION_NOT_OPEN` | 409 | Trying to bid on non-open auction |
| `AUCTION_DISCOUNT_EXCEEDS_CAP` | 422 | Discount > 40% of pool (per Chit Funds Act) |
| `AUCTION_DISCOUNT_BELOW_MIN` | 422 | Discount ≤ 0 |
| `AUCTION_ALREADY_BID` | 409 | One bid per bidder rule |
| `AUCTION_ALREADY_WON` | 403 | Bidder already won a previous cycle in this room |
| `AUCTION_BIDDER_NOT_MEMBER` | 403 | Caller isn't in the room |

#### Contributions / payouts

| Code | HTTP | When |
|---|---|---|
| `CONTRIBUTION_DUPLICATE` | 409 | Already marked this cycle |
| `CONTRIBUTION_AMOUNT_MISMATCH` | 422 | Amount doesn't match expected dues |
| `CONTRIBUTION_NOT_DUE` | 409 | Trying to confirm before mark-paid |
| `CONTRIBUTION_DEFAULTED` | 409 | Action on a defaulted cycle |
| `PAYOUT_DUPLICATE` | 409 | Already marked paid this cycle |
| `PAYOUT_NOT_PENDING` | 409 | Cycle's payout already confirmed |

#### Disputes

| Code | HTTP | When |
|---|---|---|
| `DISPUTE_RESPONSE_WINDOW_CLOSED` | 409 | Past `respond_by_at` |
| `DISPUTE_ALREADY_DECIDED` | 409 | Past `decided_at` |
| `DISPUTE_NOT_PARTY` | 403 | Caller is not filer/respondent |
| `EVIDENCE_LIMIT_EXCEEDED` | 422 | More than 5 evidence items per dispute |

#### Gems / redemptions

| Code | HTTP | When |
|---|---|---|
| `GEMS_INSUFFICIENT_BALANCE` | 422 | Not enough gems |
| `REDEMPTION_OUT_OF_STOCK` | 409 | Voucher partner returned out-of-stock |
| `REDEMPTION_PROVIDER_FAILED` | 502 | Partner API failed |
| `REDEMPTION_VERIFICATION_REQUIRED` | 403 | Amount over threshold, needs PAN |

#### Rate limiting

| Code | HTTP | When |
|---|---|---|
| `RATE_LIMIT_EXCEEDED` | 429 | Hit any rate-limit bucket. `details.retry_after_s` populated. |

#### Downstream

| Code | HTTP | When |
|---|---|---|
| `DOWNSTREAM_KYC_FAILED` | 502 | KYC partner returned error |
| `DOWNSTREAM_KYC_UNAVAILABLE` | 503 | Partner unreachable; client should retry |
| `DOWNSTREAM_SMS_FAILED` | 502 | SMS gateway error |
| `DOWNSTREAM_VOUCHER_FAILED` | 502 | Voucher partner error |
| `INTERNAL_ERROR` | 500 | Unhandled; never returns details |
| `SERVICE_MAINTENANCE` | 503 | Deliberate; `Retry-After` set |

---

## 8. Pagination contract

**Keyset pagination only.** No offset pagination — it gets slower and slower as users scroll, and produces duplicates/skips on concurrent inserts.

### 8.1 Request

```
GET /v1/me/contributions?limit=20&cursor=eyJ0IjoiMjAyNi0wNi0wMSIsImlkIjoiZjQ4NyJ9
```

- `limit`: 1–100, default 20
- `cursor`: opaque base64-encoded JSON `{ "t": "<iso8601>", "id": "<uuid>" }`. Forward cursor only in v1; no backward pagination.

### 8.2 Response

```json
{
  "items": [ ... ],
  "next_cursor": "eyJ0IjoiMjAyNi0wNS0..."  // or omitted on last page
}
```

If `next_cursor` is absent, there are no more items. Clients should not infer "no more" from `items.length < limit` — concurrent deletes break that heuristic.

### 8.3 Sort order

Every paginated endpoint has exactly one canonical sort: `created_at DESC, id DESC` (or the closest analogue: `dispatched_at`, `occurred_at`, `requested_at`). The cursor encodes a single point in that ordering. Other orderings are not supported in v1.

---

## 9. Rate-limit contract + matrix

### 9.1 Algorithm

Sliding-window counters in Redis, keyed by some combination of:
- User ID (`uid:<uuid>`)
- IP address (`ip:<v4-or-v6>`)
- Phone number (`phone:<e164>`)
- Endpoint scope (`scope:<route>`)

Composite keys: `rl:scope:auth.otp.request:phone:+919900000001:hour:1764703200`. Counter incremented per request; expires at window end.

### 9.2 Response headers

On 200/4xx:
```
X-Ratelimit-Limit: 100
X-Ratelimit-Remaining: 97
X-Ratelimit-Reset: 1764704700        # epoch seconds
```

On 429:
```
Retry-After: 42                       # seconds
```
Body:
```json
{ "error": { "code": "RATE_LIMIT_EXCEEDED", "details": { "retry_after_s": 42, "scope": "auth.otp.request" } } }
```

### 9.3 Limits

| Scope | Limit | Window | Key |
|---|---|---|---|
| Default authenticated GET | 600 | 1 hr | user |
| Default authenticated GET (burst) | 100 | 1 min | user |
| Default unauthenticated GET | 60 | 1 min | IP |
| `auth.otp.request` | 5 | 1 hr | phone |
| `auth.otp.request` | 20 | 1 hr | IP |
| `auth.otp.verify` | 10 | 1 hr | phone |
| `auth.refresh` | 60 | 1 hr | user |
| `verification.pan` | 3 | 1 day | user |
| `verification.bank` | 3 | 1 day | user |
| `rooms.create` | 3 | 1 day | user |
| `rooms.join` | 10 | 1 day | user |
| `auctions.bid` | natural (UNIQUE) | n/a | n/a |
| `contributions.mark-paid` | 100 | 1 day | user |
| `contributions.confirm` | 200 | 1 day | user |
| `disputes.create` | 5 | 1 day | user |
| `redemptions.create` | 5 | 1 day | user |
| `files.upload-url` | 20 | 1 hr | user |
| `notifications.read` | 1000 | 1 hr | user |

Endpoints not listed inherit the "Default authenticated GET" tier.

### 9.4 What rate limiting is NOT

- Not a security boundary. It buys time for ops to react, nothing more.
- Not a substitute for input validation, idempotency, or auth.
- Not applied to `/healthz` / `/readyz`.

---

## 10. Idempotency contract

### 10.1 Client responsibility

Every `POST`, `PATCH`, `DELETE` sends:
```
Idempotency-Key: <uuid-v4>
```
- Client generates the UUID once and retries the same call with the same key on network failure / timeout.
- Different operations → different keys.
- Same operation retried after success → same key (still safe; server returns the original response).

### 10.2 Server responsibility

The server constructs an internal idempotency key (`<endpoint>:<user_id>:<client_key>`) and:

1. Checks if a record exists.
2. If yes and the request body matches the original → return the original response.
3. If yes and the body differs → 409 `IDEMPOTENCY_KEY_MISMATCH`.
4. If no → process normally, store key + response.

### 10.3 Storage

For most endpoints, idempotency is enforced via the **natural uniqueness** of inserted rows (see Phase 3 §9 catalogue). For endpoints where there is no natural unique row (e.g., `POST /v1/auth/refresh`), we maintain a small `shared.idempotency_responses` cache (added in v1.1 — for MVP we accept retry-causes-duplicate on these few cases, none of which is a money-equivalent operation).

### 10.4 TTL

- Money-equivalent / state-transition endpoints: key is permanent (the natural unique row never goes away).
- Read-style POSTs (rare; only `POST /v1/files/upload-url`): 24h.

---

## 11. File upload contract

### 11.1 Why signed URLs, not multipart

Multipart on mobile networks is fragile (large bodies + flaky connections + tight server timeouts). Signed URLs let the client upload directly to Supabase Storage with retry and resumability handled by the client SDK. Our API stays JSON-only.

### 11.2 Flow

```mermaid
sequenceDiagram
    participant App
    participant API
    participant Storage as Supabase Storage

    App->>API: POST /v1/files/upload-url<br/>{purpose: "contribution_screenshot", content_type: "image/jpeg", size_bytes: 482910}
    API->>API: validate purpose, type, size
    API->>Storage: create signed PUT URL (15-min TTL)
    API-->>App: { upload_url, file_key, expires_at }
    App->>Storage: PUT upload_url, body=binary
    Storage-->>App: 200
    App->>API: POST /v1/contributions/mark-paid<br/>{ ..., screenshot_file_key: "abc/def.jpg" }
    API->>API: validate file exists in Storage<br/>and was uploaded by this user
    API-->>App: 201 Created
```

### 11.3 Constraints (enforced server-side at `/files/upload-url`)

| Purpose | Allowed types | Max size |
|---|---|---|
| `contribution_screenshot` | image/jpeg, image/png, image/webp | 5 MB |
| `payout_screenshot` | image/jpeg, image/png, image/webp | 5 MB |
| `dispute_evidence` | image/jpeg, image/png, image/webp, application/pdf | 10 MB |
| `profile_avatar` | image/jpeg, image/png, image/webp | 2 MB |

File key format: `{purpose}/{user_uuid}/{yyyymm}/{uuid4}.{ext}`.

### 11.4 What clients never get

- A bucket name.
- A path prefix outside their own user's tree.
- A URL that survives past 15 minutes.

---

## 12. Endpoint inventory

The complete list. Full request/response schemas live in `openapi.yaml`. Detailed prose for the non-obvious ones is in §13.

### 12.1 Auth (iam)

| Method | Path | Purpose |
|---|---|---|
| POST | `/v1/auth/otp/request` | Send OTP to phone |
| POST | `/v1/auth/otp/verify` | Verify OTP, issue tokens |
| POST | `/v1/auth/refresh` | Rotate refresh, issue access |
| POST | `/v1/auth/logout` | Revoke current refresh + family |
| POST | `/v1/auth/logout-all` | Revoke all refresh families for user |

### 12.2 Me (iam)

| Method | Path | Purpose |
|---|---|---|
| GET | `/v1/me` | Current user profile (incl. tier, score, gem balance) |
| PATCH | `/v1/me` | Update name, language |
| GET | `/v1/me/devices` | List my devices |
| DELETE | `/v1/me/devices/:id` | Revoke a device's sessions and tokens |
| GET | `/v1/me/sessions` | List my active sessions |
| POST | `/v1/me/delete` | Initiate account deletion (30-day grace) |
| POST | `/v1/me/delete/cancel` | Cancel pending deletion |

### 12.3 Verification

| Method | Path | Purpose |
|---|---|---|
| GET | `/v1/me/verifications` | Status of all verification types |
| POST | `/v1/verifications/pan` | Submit PAN for verification |
| POST | `/v1/verifications/bank` | Submit bank for penny-drop |

### 12.4 Rooms

| Method | Path | Purpose |
|---|---|---|
| POST | `/v1/rooms` | Create room (draft) |
| GET | `/v1/rooms` | My rooms (member or foreman) |
| GET | `/v1/rooms/:id` | Room detail |
| PATCH | `/v1/rooms/:id` | Edit (draft only) |
| POST | `/v1/rooms/:id/start` | recruiting → active |
| POST | `/v1/rooms/:id/cancel` | Cancel (rules per state) |
| POST | `/v1/rooms/:id/leave` | Leave (during recruiting only) |
| GET | `/v1/rooms/by-code/:code` | Preview room before joining (no membership granted) |
| POST | `/v1/rooms/:id/join` | Join with internal user-already-invited path |
| POST | `/v1/invitations/accept` | Accept by token (link or QR scan) |
| POST | `/v1/rooms/:id/invitations` | Generate an invitation |
| GET | `/v1/rooms/:id/invitations` | List room invitations (foreman only) |
| DELETE | `/v1/rooms/:id/invitations/:invitationId` | Revoke invitation |
| GET | `/v1/rooms/:id/members` | Members of a room |

### 12.5 Auctions

| Method | Path | Purpose |
|---|---|---|
| GET | `/v1/rooms/:id/auctions` | Auctions for a room (history + current) |
| GET | `/v1/auctions/:id` | Auction detail (hides sealed bids until close) |
| POST | `/v1/auctions/:id/bids` | Place a bid |
| GET | `/v1/auctions/:id/my-bid` | My bid in this auction (if any) |

### 12.6 Contributions

| Method | Path | Purpose |
|---|---|---|
| GET | `/v1/rooms/:id/cycles/:cycle/contributions` | All contributions in a cycle (foreman + members of that room) |
| POST | `/v1/contributions/mark-paid` | Self-report payment |
| POST | `/v1/contributions/:eventId/confirm` | Foreman confirms |
| POST | `/v1/contributions/:eventId/dispute` | Foreman or member raises dispute |
| GET | `/v1/me/contributions` | My contributions across rooms |

### 12.7 Payouts

| Method | Path | Purpose |
|---|---|---|
| POST | `/v1/payouts/mark` | Foreman records disbursement |
| POST | `/v1/payouts/:eventId/confirm` | Winner confirms receipt |
| GET | `/v1/me/payouts` | My payouts (received) |

### 12.8 Trust

| Method | Path | Purpose |
|---|---|---|
| GET | `/v1/me/trust` | Score, tier, tier history |
| GET | `/v1/me/trust/events` | Glass-box: every event affecting my score |

### 12.9 Gems & rewards

| Method | Path | Purpose |
|---|---|---|
| GET | `/v1/me/gems` | Balance + lifetime |
| GET | `/v1/me/gems/events` | Earn / redeem history |
| GET | `/v1/rewards` | Available voucher SKUs |
| POST | `/v1/redemptions` | Redeem a voucher |
| GET | `/v1/me/redemptions` | My redemption history |
| GET | `/v1/redemptions/:id` | Redemption detail (incl. code, when fulfilled) |

### 12.10 Disputes

| Method | Path | Purpose |
|---|---|---|
| POST | `/v1/disputes` | File dispute |
| GET | `/v1/disputes/:id` | Detail |
| POST | `/v1/disputes/:id/respond` | Respondent's evidence |
| POST | `/v1/disputes/:id/decide` | Foreman decides (or admin via escalation) |
| POST | `/v1/disputes/:id/evidence` | Add additional evidence |
| GET | `/v1/me/disputes` | My disputes (as filer or respondent) |
| GET | `/v1/rooms/:id/disputes` | All disputes in a room (members + foreman) |

### 12.11 Notifications

| Method | Path | Purpose |
|---|---|---|
| GET | `/v1/me/notifications` | Inbox |
| GET | `/v1/me/notifications/unread-count` | Badge count |
| POST | `/v1/me/notifications/:id/read` | Mark one read |
| POST | `/v1/me/notifications/read-all` | Mark all read |
| GET | `/v1/me/notifications/preferences` | Preferences |
| PATCH | `/v1/me/notifications/preferences` | Update preferences |
| POST | `/v1/me/devices/:id/fcm-token` | Register/update FCM token |

### 12.12 Files

| Method | Path | Purpose |
|---|---|---|
| POST | `/v1/files/upload-url` | Get signed PUT URL |

### 12.13 Admin

| Method | Path | Purpose |
|---|---|---|
| POST | `/v1/admin/auth/login` | Email + password + TOTP |
| POST | `/v1/admin/auth/refresh` | Rotate admin token |
| GET | `/v1/admin/users` | Search / list |
| GET | `/v1/admin/users/:id` | Detail (incl. trust, gems, audit summary) |
| POST | `/v1/admin/users/:id/suspend` | Suspend (dual approval if superadmin-only) |
| POST | `/v1/admin/users/:id/restore` | Restore |
| POST | `/v1/admin/users/:id/score-adjust` | Manual score change (dual approval, reason mandatory) |
| GET | `/v1/admin/rooms` | Search / list rooms |
| GET | `/v1/admin/rooms/:id` | Detail |
| POST | `/v1/admin/rooms/:id/force-cancel` | Force cancel (reason + dual approval) |
| GET | `/v1/admin/disputes` | Escalation queue |
| POST | `/v1/admin/disputes/:id/escalate` | Take over (from foreman) |
| POST | `/v1/admin/disputes/:id/decide` | Decide as platform |
| GET | `/v1/admin/audit-log` | Filterable audit log |
| GET | `/v1/admin/metrics/overview` | High-level KPIs |

### 12.14 Health

| Method | Path | Purpose |
|---|---|---|
| GET | `/healthz` | Liveness (always 200 if process up) |
| GET | `/readyz` | Readiness (200 only if DB + Redis reachable) |

**Endpoint count:** 65. Of which ~50 are in scope for v1.0; admin can ship in v1.5 if needed (per Phase 2 §10.9).

---

## 13. Detailed specs for non-obvious endpoints

The OpenAPI YAML covers all endpoints. The detailed specs below are the ones with subtle behaviour worth explaining in prose.

### 13.1 `POST /v1/auth/otp/request`

**Auth:** none. **Idempotency:** by `(phone, hour)` — repeated requests inside the same hour from same phone return the same `otp_ref` (no new OTP sent).

Request:
```json
{
  "phone": "+919900000001"
}
```

Response 200:
```json
{
  "otp_ref": "7f3d12af-...",
  "resend_after_s": 60
}
```

Errors:
- 429 `AUTH_OTP_RATE_LIMITED` — 5/hr per phone, 20/hr per IP
- 400 `VALIDATION_FAILED` — phone not E.164

**Note:** we do not disclose whether the phone is already registered. Same response in both cases. Prevents phone enumeration.

### 13.2 `POST /v1/auth/otp/verify`

**Auth:** none. **Idempotency:** by `(phone, otp_hash)`.

Request:
```json
{
  "phone": "+919900000001",
  "otp": "123456",
  "device_fingerprint": "ab12...",
  "device_platform": "android",
  "device_model": "Pixel 7"
}
```

Response 200 (existing user):
```json
{
  "access_token": "eyJhbGciOi...",
  "refresh_token": "rt_8c2e...",
  "access_expires_at": "2026-06-02T15:45:00+05:30",
  "refresh_expires_at": "2026-07-02T15:30:00+05:30",
  "user": { ... }                  // same as GET /v1/me response
}
```

Response 201 (new user — account created on first OTP verify):
Same body, `201 Created`.

Errors:
- 401 `AUTH_OTP_INVALID`
- 401 `AUTH_OTP_EXPIRED`
- 429 `AUTH_OTP_TOO_MANY_ATTEMPTS`
- 403 `PERM_ACCOUNT_SUSPENDED`

**Subtle behaviour:** If the device fingerprint is new for an existing user, this endpoint still succeeds (OTP is the new-device check) and a fresh `Device` row is created. The previous device's tokens remain valid until they naturally expire — the client must explicitly call `/auth/logout-all` if it wants to invalidate them.

### 13.3 `POST /v1/auth/refresh`

**Auth:** none (the refresh token is the credential). **Idempotency:** by `(refresh_token_hash)` — replaying a successful refresh returns the same access token if within the access TTL, else triggers family revocation.

Request:
```json
{
  "refresh_token": "rt_8c2e..."
}
```

Response 200:
```json
{
  "access_token": "eyJhbGciOi...",
  "refresh_token": "rt_new_...",       // rotated
  "access_expires_at": "...",
  "refresh_expires_at": "..."
}
```

Errors:
- 401 `AUTH_TOKEN_INVALID`
- 401 `AUTH_TOKEN_EXPIRED`
- 401 `AUTH_TOKEN_REVOKED`
- 401 `AUTH_TOKEN_REUSE_DETECTED` — the family is killed; client must re-OTP

### 13.4 `POST /v1/verifications/pan`

**Auth:** required, phone-verified. **Idempotency:** by `(user_id, client_key)` for 24h. **Async:** result may not be immediate.

Request:
```json
{
  "pan": "ABCDE1234F",
  "name_on_pan": "Lakshmi Subramanian"
}
```

Response 202 (queued):
```json
{
  "verification_id": "...",
  "status": "pending",
  "estimated_completion_s": 5
}
```

The client should poll `GET /v1/me/verifications` or wait for a push notification. In practice the partner responds in <3 seconds and we can return 200 with the result inline; the 202 envelope handles the slow case without changing the response shape (status field shifts to `success`/`failed`).

Errors:
- 400 `VALIDATION_FAILED` — PAN regex `[A-Z]{5}[0-9]{4}[A-Z]`
- 502 `DOWNSTREAM_KYC_FAILED`
- 503 `DOWNSTREAM_KYC_UNAVAILABLE`
- 409 `RESOURCE_CONFLICT` — already verified (success); client should `GET /v1/me/verifications`
- 429 — rate limit

**Important:** PAN is not persisted. We send to Karza, store `pan_last4` + `name_match_score`. The request body's `pan` is scrubbed from logs by an interceptor (matched via regex). The same scrubbing applies to bank account numbers and Aadhaar.

### 13.5 `POST /v1/rooms`

**Auth:** required, `pan_and_bank` verified. **Idempotency:** by `(user_id, client_key)`.

Request:
```json
{
  "name": "Lakshmi's TextileFund #2",
  "contribution_amount_paise": 200000,         // ₹2,000
  "member_count_target": 10,
  "cycle_length_days": 30,
  "foreman_commission_bps": 500,                // 5%
  "auction_window_hours": 24,
  "rules_text": "Pay by 5th of every month..."
}
```

Response 201:
```json
{
  "id": "...",
  "code": "A3B7K9",
  "status": "draft",
  "name": "...",
  "contribution_amount_paise": 200000,
  "currency": "INR",
  "member_count_target": 10,
  "member_count_current": 1,
  "current_cycle": 0,
  "total_cycles": 10,
  "foreman_user_id": "...",
  "created_at": "..."
}
```

Validation:
- `name`: 3–80 chars, no emoji
- `contribution_amount_paise`: 100 (₹1) to 5_00_00_000 (₹5L); upper bound enforced per tier
- `member_count_target`: 5–25
- `cycle_length_days`: 30 only in v1
- `foreman_commission_bps`: 0–500 (i.e., 0–5%, cap per Chit Funds Act)
- `auction_window_hours`: 12–72

Errors:
- 403 `PERM_VERIFICATION_REQUIRED` — missing PAN+bank
- 403 `PERM_VELOCITY_LIMIT` — account < 30 days
- 403 `PERM_TRUST_TIER_INSUFFICIENT` — contribution > tier cap
- 422 `VALIDATION_FAILED` — any constraint

**Side effects:** the creator is automatically added as a `RoomMember` (yes — the foreman is also a subscriber in a chit, traditionally).

### 13.6 `POST /v1/rooms/:id/join`

**Auth:** required, phone-verified. PAN required if room > ₹10k; PAN+bank if > ₹1L. **Idempotency:** by `(room_id, user_id)` (natural — RoomMember unique).

Request:
```json
{}                              // no body; the path identifies the room
```

Response 201:
```json
{
  "room": { ... },
  "membership": {
    "joined_at": "...",
    "cycle_first_eligible": 1
  }
}
```

Errors (the busy endpoint):
- 404 `ROOM_CODE_INVALID` — room not visible to caller via any invitation
- 409 `ROOM_NOT_RECRUITING` — must be in `recruiting` state
- 409 `ROOM_FULL`
- 403 `ROOM_TRUST_GATE_FAILED`
- 403 `ROOM_CAP_EXCEEDED`
- 403 `PERM_VERIFICATION_REQUIRED`
- 403 `PERM_VELOCITY_LIMIT`

**Subtle:** caller must have a path to this room (an invitation, OR they used `POST /v1/invitations/accept` with a token, OR they discovered via room code through `GET /v1/rooms/by-code/:code` and the foreman explicitly allows code-joins on this room — a flag on the room). Random `/v1/rooms/:id/join` with a guessed ID returns 404, not 403.

### 13.7 `POST /v1/auctions/:id/bids`

**Auth:** required, member of the room. **Idempotency:** by `(auction_id, bidder_user_id)` (natural unique).

Request:
```json
{
  "discount_amount_paise": 80000             // ₹800 off the pool
}
```

Response 201:
```json
{
  "bid_id": "...",
  "auction_id": "...",
  "placed_at": "2026-06-02T15:33:21+05:30",
  "locked": true
}
```

Validation:
- `discount_amount_paise`: positive integer, ≤ 40% of pool (per Chit Funds Act §17), in increments of 100 paise (₹1)

Errors:
- 409 `AUCTION_NOT_OPEN`
- 422 `AUCTION_DISCOUNT_EXCEEDS_CAP` — with `details.pool_paise`, `details.cap_paise`
- 422 `AUCTION_DISCOUNT_BELOW_MIN`
- 409 `AUCTION_ALREADY_BID`
- 403 `AUCTION_ALREADY_WON`
- 403 `AUCTION_BIDDER_NOT_MEMBER`

**Sealed-bid:** the response intentionally does NOT include the current highest/lowest bid, count of other bids, or anything that could be used to infer competitors' positions. `GET /v1/auctions/:id` while `status='open'` similarly hides other bids — only `my_bid` is visible.

### 13.8 `POST /v1/contributions/mark-paid`

**Auth:** required, room member. **Idempotency:** by `(room_id, cycle, user_id)` (the inserted ledger event's idempotency key).

Request:
```json
{
  "room_id": "...",
  "cycle": 3,
  "amount_paise": 200000,
  "upi_reference": "402134567890",
  "screenshot_file_key": "contribution_screenshot/.../abc.jpg"
}
```

Response 201:
```json
{
  "contribution_event_id": "...",
  "room_id": "...",
  "cycle": 3,
  "status": "marked_paid",
  "amount_paise": 200000,
  "marked_paid_at": "..."
}
```

Validation:
- `amount_paise` must equal the expected dues for that cycle (foreman commission already accounted for). Mismatch → 422 `CONTRIBUTION_AMOUNT_MISMATCH`.
- `upi_reference`: 10–40 chars (different banks use different formats; intentionally loose). Server stores as-is.
- `screenshot_file_key`: must exist in Storage and belong to caller's upload tree.

Errors:
- 409 `CONTRIBUTION_DUPLICATE` — already marked this cycle
- 422 `CONTRIBUTION_AMOUNT_MISMATCH`
- 409 `CONTRIBUTION_DEFAULTED` — cycle already defaulted

### 13.9 `POST /v1/contributions/:eventId/confirm`

**Auth:** required, foreman of the room. **Idempotency:** natural (event_id is unique; same confirm replays return same response).

Request:
```json
{}
```

Response 201:
```json
{
  "contribution_event_id": "...",
  "status": "confirmed",
  "confirmed_at": "..."
}
```

**Side effects (in one transaction):**
1. New `ledger_event` of type `ContributionConfirmed`.
2. `contribution_status` row → `confirmed`.
3. `trust_events` row: +5 if on-time, no delta if late, −10 if confirmed-after-deadline.
4. `gem_events` row: +10 for on-time.
5. `outbox_events`: push notification to the member.

All five happen atomically. If any fail, none commit.

### 13.10 `POST /v1/disputes`

**Auth:** required, room member. **Idempotency:** by `(room_id, cycle, type, filed_by_user_id)`.

Request:
```json
{
  "room_id": "...",
  "cycle": 3,
  "type": "contribution_not_received",       // or payout_not_received, auction_integrity, rule_violation
  "against_user_id": "...",
  "source_event_id": "...",                  // optional; ledger event this dispute is about
  "reason": "I never received the payout for cycle 3 even though it was marked paid."
}
```

Response 201:
```json
{
  "dispute_id": "...",
  "status": "open",
  "filed_at": "...",
  "respond_by_at": "2026-06-04T15:30:00+05:30",   // +48h
  "decide_by_at": "2026-06-09T15:30:00+05:30",    // +7d
  "type": "contribution_not_received"
}
```

Errors:
- 403 `PERM_ROOM_NOT_MEMBER`
- 422 `VALIDATION_FAILED` — `reason` < 10 chars

**Evidence is added separately** via `POST /v1/disputes/:id/evidence`. This is deliberate: the file-upload contract requires the user to upload before referencing.

### 13.11 `POST /v1/redemptions`

**Auth:** required. Some SKUs require PAN. **Idempotency:** by `(user_id, client_key)` for 24h.

Request:
```json
{
  "voucher_sku": "amazon_500",
  "quantity": 1
}
```

Response 201:
```json
{
  "redemption_id": "...",
  "status": "processing",                  // pending → processing → fulfilled / failed
  "gems_spent": 2500,
  "voucher_sku": "amazon_500",
  "voucher_name": "Amazon Pay ₹500",
  "requested_at": "..."
}
```

When processing completes (usually <30s via webhook from Qwikcilver):

`GET /v1/redemptions/:id`:
```json
{
  "redemption_id": "...",
  "status": "fulfilled",
  "voucher_code": "AMZN-7K2P-9MQR-4V8L",       // decrypted at read time
  "expires_at": "2027-06-02T23:59:59+05:30",
  "fulfilled_at": "..."
}
```

Errors:
- 422 `GEMS_INSUFFICIENT_BALANCE`
- 409 `REDEMPTION_OUT_OF_STOCK`
- 403 `REDEMPTION_VERIFICATION_REQUIRED` — for high-value SKUs
- 502 `REDEMPTION_PROVIDER_FAILED`

**Important:** the voucher code is shown **only once** in the response of `GET /v1/redemptions/:id` within 90 days of fulfilment. After that the code is purged (DPDP minimisation + reduced theft surface). Users should screenshot or copy on first view; the API warns this in the description.

### 13.12 `POST /v1/files/upload-url`

**Auth:** required. **Idempotency:** by `(user_id, client_key)` for 1h (the URL is short-lived anyway).

Request:
```json
{
  "purpose": "contribution_screenshot",
  "content_type": "image/jpeg",
  "size_bytes": 482910
}
```

Response 201:
```json
{
  "file_key": "contribution_screenshot/8c2e.../202606/9c7d12af....jpg",
  "upload_url": "https://supabase-storage.../signed-put?...",
  "upload_url_expires_at": "2026-06-02T15:45:00+05:30",
  "max_size_bytes": 5242880
}
```

Errors:
- 400 `VALIDATION_FAILED` — bad purpose, type, or oversize

The returned `upload_url` is a PUT-only URL pinned to that exact `content_type` and `size_bytes`. The client uploads with the matching headers; Supabase rejects deviations.

---

## 14. Authorization matrix

Every endpoint declares: { auth required, role, verification, tier, room membership, velocity rule, rate scope }. Below is the compact form. The OpenAPI YAML carries `x-auth` extensions encoding the same.

| Endpoint | Auth | Role | Verif | Tier | Membership | Other |
|---|---|---|---|---|---|---|
| POST `/v1/auth/otp/request` | — | — | — | — | — | rate: phone+IP |
| POST `/v1/auth/otp/verify` | — | — | — | — | — | rate: phone |
| POST `/v1/auth/refresh` | refresh-token | — | — | — | — | — |
| POST `/v1/auth/logout*` | yes | — | — | — | — | — |
| GET `/v1/me` | yes | — | phone | — | — | — |
| PATCH `/v1/me` | yes | — | phone | — | — | — |
| POST `/v1/verifications/pan` | yes | — | phone | — | — | rate 3/d |
| POST `/v1/verifications/bank` | yes | — | phone | — | — | rate 3/d |
| POST `/v1/rooms` | yes | — | pan+bank | per cap | — | velocity: age≥30d; rate 3/d |
| GET `/v1/rooms` | yes | — | phone | — | — | — |
| GET `/v1/rooms/:id` | yes | — | phone | — | member or foreman or has-invitation | — |
| PATCH `/v1/rooms/:id` | yes | — | pan+bank | — | foreman & draft | — |
| POST `/v1/rooms/:id/start` | yes | — | pan+bank | — | foreman & recruiting & quorum | — |
| POST `/v1/rooms/:id/cancel` | yes | — | phone | — | foreman or unanimous-via-rpc | — |
| POST `/v1/rooms/:id/leave` | yes | — | phone | — | member & recruiting | — |
| POST `/v1/rooms/:id/join` | yes | — | per room amount | per cap | not-already-member & has-invitation | velocity: age≥15d for >₹10k; rate 10/d |
| POST `/v1/invitations/accept` | yes | — | phone | — | (creates membership) | — |
| POST `/v1/rooms/:id/invitations` | yes | — | phone | — | foreman | — |
| POST `/v1/auctions/:id/bids` | yes | — | phone | — | member & not-already-won | — |
| GET `/v1/auctions/:id` | yes | — | phone | — | member or foreman | (sealed bids hidden) |
| POST `/v1/contributions/mark-paid` | yes | — | phone | — | member of room | rate 100/d |
| POST `/v1/contributions/:id/confirm` | yes | — | phone | — | foreman of room | — |
| POST `/v1/contributions/:id/dispute` | yes | — | phone | — | foreman or member of room | rate 5/d |
| POST `/v1/payouts/mark` | yes | — | phone | — | foreman of room | — |
| POST `/v1/payouts/:id/confirm` | yes | — | phone | — | winner of cycle | — |
| POST `/v1/disputes` | yes | — | phone | — | member of room | rate 5/d |
| POST `/v1/disputes/:id/respond` | yes | — | phone | — | named respondent | — |
| POST `/v1/disputes/:id/decide` | yes | — | phone | — | foreman of room | — |
| POST `/v1/disputes/:id/evidence` | yes | — | phone | — | party to dispute | — |
| POST `/v1/redemptions` | yes | — | phone (pan for high-value) | — | — | rate 5/d |
| POST `/v1/files/upload-url` | yes | — | phone | — | — | rate 20/h |
| `/v1/admin/**` | yes | admin or superadmin | — | — | — | (token aud=seatu-admin) |
| GET `/healthz` | — | — | — | — | — | — |
| GET `/readyz` | — | — | — | — | — | — |

---

## 15. Anti-patterns we explicitly avoid

These are mistakes I've seen kill fintech APIs. We don't make them.

1. **No "do everything" endpoints.** No `POST /v1/rpc` with a `{method: ...}` body. Every operation has its own URL.
2. **No status changes via PATCH.** `room.status` isn't editable by the client — only by `POST /v1/rooms/:id/start`, `/cancel`, etc. Encoding state machines as PATCH-able fields is the second-most-common cause of inconsistent fintech state.
3. **No nested transactional bodies.** A request never says "create a room AND join it AND post first contribution." Each is a separate call. Idempotency stays sane.
4. **No webhooks consumed without HMAC.** None in MVP. When we add them (Track B), every callback is HMAC-signed.
5. **No client-side computed money.** The server returns `amount_paise`. The client renders. The client never sends "I think I owe ₹2,000" back; it sends the cycle reference and the server validates against its own number.
6. **No "soft-delete via PATCH `is_active=false`".** Cancellation is its own endpoint with its own idempotency and audit trail.
7. **No leaking enum values across versions.** New enum values are added; old values aren't repurposed.

---

## 16. Phase 5 handoff — what the backend implementation must deliver

Phase 5 (Backend Implementation) consumes this and Phase 3 to produce:

1. NestJS modular monolith matching Phase 2 §3 module catalogue.
2. Every endpoint in §12 wired with: controller, DTO with class-validator decorators, service, repository, policy guard, idempotency interceptor, audit interceptor.
3. EventBus + outbox + scheduler wired and unit-tested.
4. Integration tests for the four critical flows in Phase 2 §6 (onboarding, room lifecycle, auction cycle, contribution+dispute) using a real Postgres in Docker.
5. The KYC and notification adapters with at least one provider (Karza for KYC, MSG91 for SMS, FCM for push).
6. Seed script + Docker Compose for local dev.
7. OpenAPI spec served at `/v1/openapi.json` (and `/docs` via Scalar or Swagger UI).
8. Sentry + PostHog wired; structured logging via Pino.
9. CI: lint, typecheck, unit tests, integration tests, prisma migrate dry-run.

---

## End of Phase 4

**Files in this delivery:**
- `SEATU-API-Design-Phase4.md` (this document)
- `SEATU-openapi.yaml` (OpenAPI 3.1, code-gen ready)

**Next phase:** Phase 5 — Backend Implementation. Output is a runnable NestJS modular monolith with all v1.0 endpoints, the EventBus + outbox, integration tests for the four critical flows, and a docker-compose for local dev.

**Status:** Awaiting founder review. Approve to proceed, or flag changes — especially around the error catalogue (§7), the auth model (§4), or the authorization matrix (§14).
