# SEATU — Launch Runbook (Phase 9)

**Phase 9 Deliverable**
**Owner:** CTO + Founder
**Status:** Operational document — use for the actual launch
**Date:** June 2026

---

## How to read this

This document is procedural. It tells you what to do, in what order, with what to check. It is NOT a design discussion — design decisions are in the Phase 1–8 docs.

The launch has four streams, mostly parallel but with one sequence:

```
1. Infrastructure  →  Backend deploy  ──┐
2. Provider setup  ─────────────────────┼──→  Staging smoke  →  Production go-live
3. Flutter builds  →  Store internal ──┘
4. Compliance      ────────────────────────────────────────→  (gate before go-live)
```

Each stream below has its own checklist. Tick boxes literally — this is the kind of document where assumptions kill you.

---

## Stream 1 — Infrastructure

### 1.1 Provision (one-time)

- [ ] **Postgres**: create a Supabase project in the AP-South-1 region. Take the connection string with `?sslmode=require`. Note the connection-pool URL too (we'll use it later for the API; direct URL only for migrations).
- [ ] **Redis**: create an Upstash database, region `ap-south-1` (Mumbai). Note the `rediss://` URL.
- [ ] **Backend host**: pick one — Railway or Render. Both have configs in the backend repo (`railway.json`, `render.yaml`). Railway has slightly better cold-start; Render has nicer dashboards.
- [ ] **DNS**: point `api.seatu.in` → hosting CNAME. TTL 300.
- [ ] **TLS**: managed by Railway/Render automatically once DNS resolves. Verify after deploy with `curl -vI https://api.seatu.in/healthz`.

### 1.2 Secrets to set in the host's dashboard

Group by criticality (set in this order so each test step can use the previous secrets):

**Tier 0 — without these the app can't boot:**

- [ ] `DATABASE_URL`
- [ ] `REDIS_URL`
- [ ] `JWT_ALGORITHM=RS256`
- [ ] `JWT_PRIVATE_KEY` — generate with `openssl genrsa -out jwt-private.pem 2048` then base64-encode the file contents. Escape newlines as `\n`.
- [ ] `JWT_PUBLIC_KEY` — derive: `openssl rsa -in jwt-private.pem -pubout -out jwt-public.pem`
- [ ] `JWT_ISSUER=https://api.seatu.in`
- [ ] `APP_ENCRYPTION_KEY` — generate: `openssl rand -base64 32`
- [ ] `NODE_ENV=production`

**Tier 1 — without these key features are degraded:**

- [ ] `SMS_PROVIDER=msg91`
- [ ] `MSG91_AUTH_KEY`
- [ ] `MSG91_OTP_TEMPLATE_ID` — DLT-approved OTP template
- [ ] `MSG91_SENDER_ID=SEATUI` (or your final 6-char header ID)
- [ ] `KYC_PROVIDER=karza`
- [ ] `KARZA_API_KEY`

**Tier 2 — needed for full feature parity at launch:**

- [ ] `PUSH_PROVIDER=fcm`
- [ ] `FCM_SERVICE_ACCOUNT_JSON` — full service-account JSON, single-line
- [ ] `STORAGE_PROVIDER=supabase`
- [ ] `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `SUPABASE_BUCKET=seatu-uploads`
- [ ] `VOUCHER_PROVIDER=qwikcilver`
- [ ] `QWIKCILVER_API_KEY`, `QC_SKU_*` SKU codes for each catalog item

**Tier 3 — observability (set before take traffic, not before deploy):**

- [ ] `SENTRY_DSN`
- [ ] `POSTHOG_API_KEY`

### 1.3 First deploy

1. Push to `main`. The CI workflow (`.github/workflows/ci.yml`) runs first; if it's green, the deploy workflow (`deploy.yml`) takes over.
2. CI will fail-loud if any env var is missing or invalid — env schema in `src/config/env.config.ts` rejects bad configs at boot.
3. First deploy will run `prisma migrate deploy` as part of the build. Confirm it ran by checking the deployment logs for `Applying migration ... bootstrap`.
4. Smoke test (auto-runs in CI deploy job). If it fails, the deploy is marked failed and Slack is notified.

### 1.4 Manual smoke

```bash
SEATU_API_BASE=https://api.seatu.in SMOKE_PHONE=+919900000099 tsx scripts/smoke.ts
```

Expect:
- /healthz: ok
- /readyz: ready
- /v1/openapi.yaml: served
- /v1/auth/otp/request: returns otp_ref (and triggers a real MSG91 SMS to the smoke-test number)

If /readyz fails: database is unreachable. Check connection string.
If openapi fails: build didn't bundle `openapi.yaml`. Add to Docker layer.
If otp/request returns 502: MSG91 misconfigured. Check authkey + template ID.

---

## Stream 2 — Provider setup

These run in parallel with infrastructure; nothing in stream 1 actually fires customer traffic to them until stream 1 is complete.

### 2.1 MSG91 (SMS / OTP) — launch blocker

- [ ] **Account**: paid plan, ₹5-10k credit for launch month
- [ ] **DLT registration**: register entity name "SEATU" (or your registered entity) on TRAI's DLT portal via your operator (Jio/Airtel etc.). This takes 2-3 business days and is a legal requirement.
- [ ] **Sender ID**: register 6-char header (we use `SEATUI`). Approval: ~24 hours.
- [ ] **Templates**: file and get DLT approval for each template you'll send. Minimum required:
  - OTP: "Your SEATU verification code is ##otp##. Valid for 5 minutes. Do not share."
  - Room joined: "##name## joined your SEATU room ##code##. Members: ##count##/##target##."
  - Auction opened: "Auction opened in ##code##. Bid by ##deadline##. https://seatu.in/r/##code##"
  - Contribution reminder: "Contribution of ₹##amt## due in ##code## by ##date##."
  - Payout due: "You have ₹##amt## pending payout in ##code##. Confirm in app."
- [ ] **Templates approved**: each gets a numeric template_id; set as `MSG91_TPL_*` env vars
- [ ] **Test with smoke phone first**: send one OTP to your own phone before opening signups

### 2.2 Karza (KYC)

- [ ] **Account**: prod credentials (separate from sandbox)
- [ ] **DPA signed**: data-processing agreement covers PAN + bank-account data
- [ ] **Webhook (optional)**: Karza supports async results for some products; we use synchronous so no webhook needed in v1
- [ ] **Test with founder's PAN + bank**: real PAN, real account, real bank-name-match
- [ ] **Set `KARZA_API_KEY`** in production env

### 2.3 FCM (Push)

- [ ] **Firebase project**: create one named `seatu-prod`
- [ ] **Android app**: add with package `in.seatu.app`. Download `google-services.json` — goes in `seatu-app/android/app/`
- [ ] **iOS app**: add with bundle ID `in.seatu.app`. Download `GoogleService-Info.plist` — goes in `seatu-app/ios/Runner/`
- [ ] **Service account**: generate, paste single-line JSON into `FCM_SERVICE_ACCOUNT_JSON`
- [ ] **Test**: send a test push via Firebase console to a development build

### 2.4 Qwikcilver (vouchers) — defer if Gems tab isn't in v1.0

- [ ] **Partner account**: business KYC required (3-5 business days)
- [ ] **Catalog selection**: pick 3-5 SKUs for launch (Amazon ₹500, Flipkart ₹500, BookMyShow ₹500 is the conservative set)
- [ ] **Settlement account**: link the SEATU bank account that Qwikcilver debits for issuances
- [ ] **Stress test**: redeem one voucher end-to-end with a real (small) credit

### 2.5 Supabase Storage

- [ ] **Bucket created**: `seatu-uploads`, PRIVATE (never make public)
- [ ] **CORS policy**: allow PUT from your Android/iOS app schemes
- [ ] **Lifecycle rules**: auto-delete dispute evidence older than 18 months (consult counsel on retention requirements)

### 2.6 Sentry + PostHog

- [ ] **Sentry project**: one project, two environments (`staging` + `production`)
- [ ] **Sentry DSN**: set as backend env + Flutter env
- [ ] **PostHog**: project + API key. Set up the launch funnel: app_opened → otp_requested → otp_verified → room_created → room_published

---

## Stream 3 — Flutter builds

### 3.1 Android

- [ ] **Signing key**: `keytool -genkey -v -keystore seatu-upload-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias seatu`. Store the keystore in 1Password; NEVER commit.
- [ ] **`android/key.properties`**: references the keystore (not committed)
- [ ] **Bundle ID**: `in.seatu.app` (claim early — package names are first-come-first-served on Play Console)
- [ ] **Build**: `flutter build appbundle --release --dart-define-from-file=env/production.json`
- [ ] **Internal testing track**: upload the bundle, invite the team
- [ ] **Open testing track**: add ~10 alpha testers (Coimbatore + Chennai mix)

### 3.2 iOS (optional for v1.0 — defer if Android-first)

- [ ] **Apple Developer account**: $99/yr, enrolled under a registered entity
- [ ] **App ID**: `in.seatu.app` with Push Notifications + Sign In capabilities
- [ ] **Distribution cert + profile**: download via Xcode
- [ ] **Build**: `flutter build ipa --release --dart-define-from-file=env/production.json`
- [ ] **TestFlight**: upload via Transporter

### 3.3 Store listings

See `store-listing/` in this deploy kit for copy templates. You'll need:

- App icon: 512×512 PNG (Play) + 1024×1024 PNG (App Store)
- Feature graphic: 1024×500 PNG (Play)
- Screenshots: minimum 4 per locale, both English + Tamil
- Short description (80 chars max for Play)
- Long description (4000 chars max)
- Privacy policy URL (REQUIRED — see Stream 4)

---

## Stream 4 — Compliance (gating)

**This stream gates go-live. Do not skip.**

### 4.1 Privacy + Terms — pre-launch

- [ ] **Templates reviewed by counsel**: the two `.md` files in `legal/` are STARTING POINTS, not final documents. A qualified lawyer in your jurisdiction must approve before publication.
- [ ] **Hosted**: privacy policy and terms hosted at `https://seatu.in/privacy` and `/terms`. Both Play and App Store require accessible URLs.
- [ ] **In-app links**: profile screen shows links to both. Phase 6.1 wiring.

### 4.2 India-specific compliance

- [ ] **Chit Funds Act 1982**: confirm with counsel that v1 (coordination-only, no money handling) is OUTSIDE the Act's licensing requirements. **This is a foundational assumption from Phase 1 §4 and Phase 2 ADR-008. Get a written legal opinion on file.**
- [ ] **DPDP Act 2023**: privacy policy must spell out:
  - what personal data we collect (phone, PAN, bank account, name)
  - why (KYC required by our risk model)
  - retention period
  - user rights (access, correction, erasure)
  - grievance officer contact (REQUIRED — name, email, phone)
- [ ] **TRAI / DLT**: MSG91 templates approved (see 2.1)
- [ ] **Chits SRO membership**: optional but useful — consider applying to a self-regulatory organization for the chit-fund ecosystem if your scale grows

### 4.3 App store policies

- [ ] **Play Store data safety form**: must declare every data type collected/used; matches the privacy policy
- [ ] **Sensitive permissions**: SMS_READ (for OTP autofill) requires extra justification; we use `autofillHints.oneTimeCode` instead, which doesn't need this permission
- [ ] **Account deletion**: Play requires an in-app account deletion path. Phase 6.1.

---

## Launch day procedure

### T-1 day

- [ ] All four streams green
- [ ] Smoke test passes against staging
- [ ] Smoke test passes against production with `ALLOW_OTP_BYPASS=false` (i.e., real OTP)
- [ ] Founder + CTO + on-call rep available
- [ ] Slack channel for the launch window
- [ ] Rollback plan rehearsed (see below)

### T-0

1. Toggle Play Store track from "closed testing" → "open testing"
2. Watch dashboards for 30 minutes:
   - Sentry: any new errors?
   - PostHog: signups happening? where's the drop-off?
   - Backend logs: `pino | grep error` — anything unusual?
   - Postgres: `SELECT count(*) FROM iam.users WHERE created_at > now() - interval '1 hour'` — match PostHog count?
3. If no incidents at +30min, promote → "production" track
4. Announce on social

### T+24h review

- [ ] Active users count
- [ ] OTP delivery success rate (PostHog: `otp_requested` vs `otp_verified`)
- [ ] KYC completion rate
- [ ] Top errors in Sentry (and acknowledged or fixed)
- [ ] Notable user reports from open-testing channel

---

## Rollback

When something is broken in production and you need to roll back fast:

### Backend

```bash
# On Railway:
railway rollback --service seatu-api    # rolls to previous deployment

# On Render:
# Go to dashboard → Deploys → click "Rollback" on the last green deploy
```

Migrations roll back via the standard Prisma "down" — but Prisma doesn't have an automatic down. If a migration has shipped data corruption, you'll likely need a manual hotfix migration rather than a rollback.

### Mobile

You can't roll back a Play Store release. Options:
1. Halt the rollout (Play console: pause staged rollout)
2. Ship a hotfix release (build → upload → expedited review for App Store; instant for Play)
3. Server-side kill switch — if it's a feature gone wrong, set the corresponding env var and restart the API

### Database

Append-only data (ledger, audit_log) cannot be rolled back at the DB level — they're protected by triggers (Phase 3). To "undo" a bad mutation, write a compensating event, never delete.

Backups: Supabase keeps daily snapshots automatically. To restore: support ticket; takes 2-4 hours.

---

## On-call playbook

### Symptom → likely cause → first action

**"App shows offline banner constantly"**
- Likely cause: `connectivity_plus` plugin issue OR Cloudflare blocking specific user
- First action: check Sentry for `connectivityStateProvider` errors; check backend logs for blocked IPs

**"OTP not arriving"**
- Likely cause: MSG91 DLT template flagged / wallet empty / authkey rotated without env update
- First action: MSG91 dashboard → message status. Check wallet balance. Check most recent template rejections.

**"5xx errors spike"**
- Likely cause: Postgres saturated; one slow query holding connections
- First action: `SELECT pid, query, state, query_start FROM pg_stat_activity WHERE state = 'active' ORDER BY query_start;` — kill the long-running. Then patch.

**"Push notifications not delivering"**
- Likely cause: FCM token churn (Android 14 background restrictions) OR service account key rotated
- First action: check `notification.outbox_events` for backlog. `SELECT status, count(*) FROM notification.outbox_events GROUP BY 1;`

**"Sign-in loop"**
- Likely cause: refresh token rotation broke (rare); device fingerprint mismatch after Android update
- First action: ask user to clear app storage; check their `iam.refresh_tokens.revoked_reason` to see what classifier fired

### Escalation order

1. **Backend issue**: on-call backend dev → CTO
2. **Mobile issue**: on-call mobile dev → CTO
3. **Provider outage** (MSG91 down etc.): wait + status page; escalate to founder if >2h
4. **Security incident**: CTO + founder, both immediately, regardless of hour
5. **Trust-and-safety report**: founder + legal counsel

---

## What we are NOT shipping in v1

Carry-overs from Phase 1 PRD. Re-stating here because launch day reveals temptations to expand scope:

- ❌ Money movement (still coordination-only)
- ❌ iOS, if we Android-first
- ❌ Gems redemption (defer if Qwikcilver onboarding is slow)
- ❌ Open-bid auctions (sealed-bid only)
- ❌ Real-time auction updates / WebSocket (Phase 7 §7 decision)
- ❌ Web client (mobile only)
- ❌ Multi-currency (INR only)

If launch is a hit and pressure builds to add these, **fight it for 60 days minimum.** Stabilize the core first.

---

## Sign-off

This runbook is the operational handoff. Treat it as a checklist, not a document. When you've ticked everything in streams 1-3 and the lawyer has signed off on stream 4, you're cleared for launch.

Good luck.

— CTO
