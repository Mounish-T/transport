# SEATU — Product Requirements Document

**Phase 1 Deliverable · v0.1 (Draft)**
**Owner:** Founder + CTO
**Status:** Awaiting founder sign-off before Phase 2 (System Architecture)
**Date:** June 2026

---

## 0. How to read this document

This PRD is intentionally opinionated. Where the brief and reality disagree, this document reflects reality and the disagreement is flagged as an **[OPEN QUESTION]** in §22. Do not approve Phase 2 until the open questions are resolved — most of them change the architecture.

---

## 1. Executive Summary

SEATU is a mobile-first platform that digitises the traditional Tamil *seettu* / Indian *chit* — a rotating savings and credit association (ROSCA) in which a closed group contributes a fixed amount each cycle and one member receives the pooled sum (the *prize*) each cycle, typically through a descending-price auction.

The product preserves the existing social ritual (closed group, monthly contribution, auction, payout) and layers on four things the offline model lacks: verifiable identity, an auditable ledger, a portable reputation score, and automated nudging/dispute hygiene.

**Track A (MVP, 2–4 months, 2 devs):** A *record-keeping and coordination* layer on top of out-of-band money movement. SEATU does **not** hold or move funds in v1. This is the only configuration that is buildable in 2–4 months *without* a chit fund licence and *without* a payment aggregator licence.

**Track B (Scale, 12–24 months):** Move from coordination to settlement — either by registering subsidiary chit fund entities state-by-state, or by partnering with a registered chit fund company as a tech-and-distribution layer (the Money Club model), or by repositioning into the savings-circle / micro-savings space where the Chit Funds Act does not apply.

The single largest strategic decision is which of those three Track B paths to commit to. That decision determines almost every other architectural choice and must be made *before* Phase 2.

---

## 2. Critical Regulatory Context — read this first

A chit, in Indian law, is defined by §2(b) of the **Chit Funds Act, 1982**: a transaction by which a *foreman* enters into an agreement with a number of subscribers that every one of them shall subscribe a certain sum periodically and that each subscriber shall in his turn, as determined by lot or auction or tender, be entitled to the prize amount.

A SEATU "room" matches that definition almost word for word. Consequences:

1. **The foreman must be registered with the State Registrar of Chits** (Tamil Nadu Chit Funds Rules apply locally). An unregistered foreman commits an offence under §76 of the Act.
2. **Foreman must deposit security** with the Registrar — generally 100% of the chit value in cash, bank guarantee, or approved securities — before commencing the chit.
3. **Caps apply to the discount** (max 40% of the chit amount in most states) and **commission** (max 5% of the chit amount per cycle to the foreman).
4. **Drawings/auctions must be minuted** in a prescribed form, signed by two subscribers, filed with the Registrar.
5. The Act applies **regardless of whether the chit is online or offline**. There is no "tech platform exemption."
6. **RBI does *not* regulate chits** (RBI explicitly clarified this in 2023); chits are a State subject. But money movement on the platform separately triggers RBI / NPCI rules (PA-PG guidelines, NPCI UPI circulars).

### Three legal postures SEATU can take. Pick one before Phase 2.

| Posture | What SEATU is | Legal exposure | Time to launch | Unit economics |
|---|---|---|---|---|
| **A. Pure coordination layer** | A bookkeeping & nudge app. Users move money peer-to-peer outside SEATU. SEATU never holds or routes funds. SEATU is not the foreman. | Low — arguably outside the Act if SEATU truly never acts as foreman and the room creator (a natural person) is the foreman in fact. But unregistered chits *between the users* remain illegal once chit value > ₹100 (yes, the threshold in the Act is that low). Liability sits on the users, but SEATU has reputational + aiding-and-abetting risk. | Fastest (this is the only Track A in scope). | Subscription / SaaS-style fees on coordinators. Reward-marketplace economics are very thin. |
| **B. Registered foreman** | SEATU (or a subsidiary) registers as a chit fund company state by state, deposits security, conducts chits per the Act. | High operational cost, fully compliant. | 9–18 months for first state. Tamil Nadu first. | Standard foreman commission (≤5%) + float income. This is where the real money is. |
| **C. Partnership with registered chit company** | SEATU is a tech + customer-acquisition layer. A licensed chit fund partner is the foreman of record. This is the **Money Club** model. | Low for SEATU; the partner carries chit-fund liability. SEATU still needs PA / escrow arrangements for any money it routes. | 4–8 months including partnership negotiation. | Revenue share with partner (typically 30–50% of foreman's commission to the platform). |

**My recommendation as CTO/co-founder: A → C → B.** Launch as a pure coordination layer (Track A in the brief), validate that Indian users will actually use a digital chit room with strangers, then close a partnership with one of Margadarsi, Shriram Chits, or a smaller regional chit fund company to begin actually moving money under their licence, then — once unit economics justify it — incorporate our own chit fund subsidiary for the highest-value rooms.

This is an **[OPEN QUESTION]** in §22.

### Other regulatory items that bite

- **Identity verification.** Mobile OTP + PAN + bank-account verification, as listed in the brief, is the *correct* combination for a v1. Aadhaar e-KYC requires us to be a registered KYC User Agency (KUA) under UIDAI or to use a regulated entity's e-KYC service (most fintechs route this via a bank or a Sub-KUA partner). We **cannot** simply hit the Aadhaar API. Treat Aadhaar/CKYC as v2.
- **DPDP Act, 2023.** PAN, Aadhaar (when added), bank details and trust-score data are all "personal data" / "sensitive personal data." We need: privacy policy, consent flows, a Data Protection Officer once we cross thresholds, breach-notification procedures, and data-minimisation principles in the schema.
- **Anti-money laundering.** Any platform that facilitates pooled money movement attracts PMLA scrutiny above thresholds. Even in Track A this means transaction monitoring and an escalation-to-FIU posture by Track B.
- **Advertising / sales pitches.** The Chit Funds Act, §11, restricts advertisement of chit funds. Marketing copy must be reviewed.
- **Reward marketplace.** Mixer grinders and pressure cookers as rewards for completing chits = possible classification as a "scheme to promote subscriptions" which has its own scrutiny under the Act. Keep gems redeemable for *vouchers* (Amazon, BigBasket, mobile recharges) in v1, not appliances. Appliances are a v3 marketing experiment, not a core mechanic.

---

## 3. Problem Statement

For ~300M Indians, the chit / seettu / committee / kuri is the primary informal credit and savings vehicle. The Reserve Bank's own household-finance studies place ROSCA participation as the second-most-common financial instrument after savings accounts.

Pain points in the offline model, validated by founder's lived context:

1. **Trust is hyper-local.** People only join rooms with relatives, neighbours, or colleagues. Group sizes stall at 10–25. A defaulter destroys the round and is rarely recovered against.
2. **Record-keeping is informal.** A foreman's notebook, WhatsApp messages, paper receipts. Disputes are unresolvable. Inheritance is messy.
3. **No portable reputation.** A subscriber who has completed 20 rounds cleanly cannot signal that to a stranger or to a lender.
4. **Auction process is opaque.** Bids are taken in person or by phone, with no immutable record of who bid what. Allegations of foreman favouritism are common.
5. **Payout is logistically painful.** Cash, cheques, sometimes UPI with no receipts.
6. **Tax and proof.** Subscribers cannot easily prove savings/income from chits for loan applications.

### Why now

- UPI penetration is now near-universal in tier-1–3 cities; the payments rails problem is solved.
- DigiLocker + DPDP Act create an identity + privacy substrate that didn't exist five years ago.
- Existing digital chit players (Money Club, KyePot, ChitMonks) prove there is demand, but UX is weak and trust-scoring is rudimentary or absent.
- The 2023 Money Circle / Cred mainstreaming of "group savings" has reframed the space culturally for younger urban users.

### Why not

- This is a tightly regulated, low-margin, fraud-prone, trust-dependent product. It will not be a winner-takes-all marketplace; it will be a slow grind. If the founder's appetite is for a hyper-growth consumer app, this is the wrong product.
- A "challenge assumptions" note: the brief equates **digital chit** with **innovation**. It is not, by itself, novel. The novelty has to come from the **trust score being portable and respected** (genuinely hard) or **distribution into communities others can't reach** (a sales-led play, not a product play). We must be honest about which one we're building.

---

## 4. Vision · Mission · Values

**Vision (10 years).** Every Indian household has a portable, verifiable savings reputation, and the chit becomes a regulated, transparent, default-resistant financial product accessible to anyone who has earned the trust to use it.

**Mission (3 years).** Be the most trusted digital chit platform in South India, starting from Tamil Nadu, with 100,000 active subscribers across 5,000 rooms and a measurable default rate below the offline industry baseline.

**Values.**
1. **Do not move money you cannot return.** (Operationally: we hold no float in v1.)
2. **Preserve the ritual.** The chit works because it's social. We digitise, we do not disrupt.
3. **Trust is earned by users, not assigned by us.** Score must be auditable to the user themselves.
4. **No dark patterns in financial UX.** Ever.

---

## 5. Personas

### Persona 1 — Lakshmi, the Foreman-Coordinator (primary)
- 42, Coimbatore, runs a small textile shop. Manages two offline seettus already: ₹2,000 × 25 members, and ₹10,000 × 20 members.
- Pain: tracking 45 people in a notebook; explaining auction maths; defaulters in her last round (cost her ₹14,000 personally).
- Goal: Run her existing groups with less friction. Maybe one bigger group eventually.
- *Will she pay?* Yes, ₹50–₹200/month if it saves her two hours/week.

### Persona 2 — Karthik, the Subscriber (primary)
- 29, Chennai, software engineer, takes home ₹85,000/month. In two chits via colleagues.
- Pain: doesn't know auction history, missed last month's auction, suspects his foreman skimmed the discount.
- Goal: passive savings vehicle that's better-documented than a SIP for short-cycle liquidity.
- *Will he pay?* No, but he's the network — he refers Lakshmi.

### Persona 3 — Rekha, the Aspirational Joiner (secondary, Track B)
- 34, Madurai, school teacher. Has never joined a chit because she doesn't have a relative who runs one. Wants to.
- Pain: no entry point to a chit group.
- Goal: Join a small, low-risk chit with strangers she can trust.
- *This persona is the SEATU bet.* If we can serve Rekha — strangers transacting based on platform-verified reputation — we have a real company. If we can only serve Lakshmi and Karthik, we have a useful tool but a small market.

### Persona 4 — Mr. Ramaswamy, the Company Handler (Track B)
- A trained, contract employee of SEATU (or a partner chit fund company) who oversees rooms above a threshold, witnesses auctions, verifies disputes.
- *This is a paid operations role, not a community volunteer.* The brief uses "Community Coordinator" ambiguously. See §22 OQ-4.

---

## 6. Market Sizing (placeholder — full TAM/SAM/SOM in Investor Phase)

- Registered chit fund subscription value in India: ~₹35,000 Cr/year (ICAI estimate, 2022) — this is the *registered* market only.
- Unregistered/informal chit volume: estimated 3–5× registered, so ₹100,000–175,000 Cr/year.
- South India accounts for ~70% of registered chit value (Tamil Nadu, Andhra/Telangana, Kerala, Karnataka).
- Active digital chit users (all platforms combined): <2 million as of 2025. Vastly under-penetrated.

Detailed TAM/SAM/SOM and competitor analysis will be produced in the Investor Phase, not here.

---

## 7. Product Principles

1. **Closed by default, public never.** All rooms are private in v1. No "discover rooms" surface. Public rooms is a Track B feature and a regulatory landmine.
2. **The foreman is a person, not the platform.** This is a legal posture *and* a product principle. SEATU exists to make a person's foreman job easier.
3. **Money flows outside the app in v1.** This is non-negotiable for Track A.
4. **One canonical ledger.** Every event (join, contribute, bid, win, payout, dispute) is an append-only entry. Nothing is mutable.
5. **Trust score is glass-box, not black-box.** Users can see every event that affected their score.
6. **Gamification serves retention, not engagement-at-any-cost.** No streaks that punish missed days, no anxiety loops.
7. **Mobile only, vernacular first.** Tamil + English at launch. Add Telugu, Kannada, Malayalam, Hindi by month 12.
8. **Accessibility is not optional.** WCAG AA, large-text mode, screen-reader friendly. Many subscribers are 45+ with reading-glasses-level vision.

---

## 8. Scope — MVP (Track A)

### 8.1 In scope for MVP

1. **Auth & onboarding:** phone+OTP, optional PAN verification, optional bank account verification (penny-drop), profile creation.
2. **Room CRUD (private only):**
   - Create room with: name, contribution amount, member count, cycle length (monthly only in v1), auction date convention, foreman commission, rules text.
   - Invite via deep link, QR, 6-character room code.
   - Recruiting state with countdown to start.
   - Active state with cycle tracker.
   - Completed and Cancelled states.
3. **Contribution tracking (no money movement):**
   - Foreman marks "received from member X" with optional UPI reference number.
   - Member can self-mark "I paid" with reference; foreman confirms.
   - Three statuses: Pending, Confirmed, Disputed.
4. **Auction (per cycle):**
   - Open at scheduled time, close after configurable window (default 24h).
   - Sealed bids (each bidder enters their willingness to forego — the discount — and bids are hidden until close).
   - Auto-pick winner: lowest discount = winner takes pool minus discount minus foreman commission.
   - Tiebreak rule: earliest bid timestamp.
   - Auction record is immutable and exportable as PDF.
5. **Payout tracking (no money movement):**
   - Foreman records "paid out to member X, ₹Y on date Z, ref ABC."
   - Winner confirms receipt.
6. **Trust score (basic):**
   - Starting score 100.
   - +5 on each cleanly completed cycle as a paying member.
   - +20 on completed room (paid every cycle).
   - −10 per late confirmation, −30 per disputed cycle confirmed against the user, −100 per fraud confirmation.
   - Levels: Bronze (0–199), Silver (200–399), Gold (400–699), Platinum (700–899), Diamond (900+).
   - **Note:** the per-level ₹ caps in the brief (₹10k / ₹50k / ₹1L / ₹5L) are tied to room size. We enforce these as *maximum room contribution* per level. This is the **Trust Gate**.
7. **Seatu Gems (gamification, v0):**
   - +10 gems on on-time confirmation, +100 on completed room, +50 on referral that completes one room.
   - Gems redeemable for **vouchers only** (Amazon, BigBasket, mobile recharge via Qwikcilver/Pine Labs reward API). **Not appliances in v1** — see regulatory note in §2.
8. **Notifications:** FCM push for payment-due (T-3, T-1, T-day, T+1), auction open, auction closing in 1h, winner announced, dispute filed against you, gem awarded.
9. **Disputes (lightweight):**
   - File dispute on a contribution or a payout.
   - Two outcomes: resolved in your favour (counterparty score −30), resolved against you (your score −30), or no-fault (no change).
   - Adjudicator: the foreman, with escalation to SEATU support email (v1). Replace with in-app workflow in v1.5.
10. **Foreman tools:** member roster, cycle calendar, current cycle status dashboard, export to PDF (state Registrar–compliant chit minute book format — even though we're not registering, we produce records that *would* satisfy the Registrar; this is a long-game asset).
11. **Profile:** identity verification status badges, trust score with history, gem balance, achievement list, list of rooms (active, past).

### 8.2 Explicitly out of scope for MVP

- Holding funds, escrow, UPI collection, UPI payout. (See §2; this is a regulatory line.)
- Public rooms, room discovery, "join any room."
- Aadhaar e-KYC. (Requires KUA/Sub-KUA arrangement.)
- AI risk scoring, automated fraud detection.
- Coordinator program as a paid role.
- Loans against trust score.
- Cross-room reputation effects on lenders (no APIs out yet).
- Coupons/appliances reward marketplace.
- Multi-currency, NRI subscribers (separate FEMA considerations).
- Web app. Mobile only.
- iOS in week one (Android only at v1.0, iOS at v1.1).

---

## 9. Scope — Scale (Track B, 12–24 months)

To be detailed in a Track B PRD. Headline features:

- Money movement via registered partner foreman (Posture C) → eventually own foreman entity (Posture B).
- Aadhaar e-KYC via Sub-KUA arrangement.
- Public verified rooms with platform-vouched foremen.
- Dedicated Company Handlers for rooms above ₹1L contribution.
- AI-driven dispute triage and fraud-pattern detection.
- Lending partnerships: trust score as one input to a partner NBFC's credit decision.
- iOS, web foreman dashboard.
- Multi-language: Telugu, Kannada, Malayalam, Hindi.
- Insurance products: per-cycle default insurance underwritten by a partner insurer (regulatory work required — IRDAI corporate-agent licence).

---

## 10. Functional Requirements — detail

### 10.1 Auth & Identity

| Req | Description | Priority |
|---|---|---|
| AUTH-1 | Phone+OTP login; OTP via SMS gateway (MSG91 or similar); 6-digit, 5-min expiry, 3 attempts before lockout. | MVP |
| AUTH-2 | JWT access token (15 min) + refresh token (30 days, rotating). | MVP |
| AUTH-3 | Device binding: token tied to a device fingerprint. Login from new device requires OTP re-verification. | MVP |
| AUTH-4 | PAN verification via NSDL/Karza/Signzy aggregator. Returns name match (≥85% required). Optional but required to join rooms ≥ ₹10,000 contribution. | MVP |
| AUTH-5 | Bank verification via penny-drop (₹1 verification, refunded). Optional. Required to be a foreman. | MVP |
| AUTH-6 | Aadhaar e-KYC via Sub-KUA partner. | Track B |
| AUTH-7 | Biometric (fingerprint/Face) unlock as second factor for sessions > 7 days old. | v1.1 |
| AUTH-8 | Account recovery via verified secondary contact (a person from a completed room, vouching). Hard requirement to prevent SIM-swap account takeover. | v1.1 |

### 10.2 Rooms

| Req | Description | Priority |
|---|---|---|
| ROOM-1 | Foreman creates room: name, contribution ₹, member count (5–25 v1), cycle (monthly), start date, foreman commission % (0–5%), auction window (12h–72h), rules text (markdown), private/private (no public option in MVP). | MVP |
| ROOM-2 | Room created in **Draft** state. Foreman shares invite link / QR / 6-char code. | MVP |
| ROOM-3 | Auto-transition to **Recruiting** on first member join. | MVP |
| ROOM-4 | Auto-transition to **Active** when member count reached AND foreman clicks "Start." | MVP |
| ROOM-5 | Trust Gate: a user cannot join a room whose contribution exceeds their level cap. (Bronze ≤ ₹10k / Silver ≤ ₹50k / Gold ≤ ₹1L / Platinum ≤ ₹5L / Diamond unlimited.) Hard block, with explainer. | MVP |
| ROOM-6 | Identity Gate: rooms ≥ ₹10,000 require PAN verification on all members. Rooms ≥ ₹1L require PAN + bank verification + (Track B) Aadhaar. | MVP |
| ROOM-7 | Room cap per user: Bronze max 1 active room, Silver 2, Gold 3, Platinum 5, Diamond unlimited. Prevents serial-default behaviour. | MVP |
| ROOM-8 | Cancel room before Active: full reset, no score impact. | MVP |
| ROOM-9 | Cancel room mid-Active: requires unanimous consent + foreman initiation. Score-neutral if unanimous, else triggers dispute workflow. | MVP |
| ROOM-10 | Room completion: all cycles closed, every member has won once. Triggers achievement, gem reward, trust-score bonus for all members. | MVP |

### 10.3 Auctions

| Req | Description | Priority |
|---|---|---|
| AUC-1 | One auction per cycle. Opens automatically at scheduled time. | MVP |
| AUC-2 | Sealed-bid: bids hidden until close. Each bidder enters a discount (₹ they will forego from the pool). | MVP |
| AUC-3 | Discount cap: 40% of pool value, per Chit Funds Act (we enforce this even though we're not the foreman, as a platform safety rail). | MVP |
| AUC-4 | A member who has already won in this room cannot bid in subsequent cycles. (Traditional rule — preserved.) | MVP |
| AUC-5 | Tie: earliest timestamp wins. | MVP |
| AUC-6 | If no bids placed: winner determined by lot (random) among eligible members. (Traditional fallback — preserved.) | MVP |
| AUC-7 | Bid is *locked* once submitted — cannot be edited or withdrawn. | MVP |
| AUC-8 | Auction close triggers: notification to all, immutable record, foreman action item to collect & disburse. | MVP |
| AUC-9 | Auction PDF export with all bids, timestamps, signatures (electronic). | v1.1 |

### 10.4 Contributions & Payouts (tracking-only in MVP)

| Req | Description | Priority |
|---|---|---|
| PAY-1 | After auction close, app displays per-member contribution amount and reminds via push. | MVP |
| PAY-2 | Member self-marks "Paid" with UPI ref ID + screenshot upload. Status → Pending. | MVP |
| PAY-3 | Foreman confirms or disputes. Confirmed → Paid. Disputed → enters dispute workflow. | MVP |
| PAY-4 | Payout: foreman records disbursement to winner with UPI ref + screenshot. Winner confirms. | MVP |
| PAY-5 | Overdue: 48h after due date with no confirmation → status **Overdue**, score penalty −10, push to member + foreman. | MVP |
| PAY-6 | 7 days overdue → **Defaulted (this cycle)**, score −30, room flagged. | MVP |
| PAY-7 | Two defaults in one room → **Removed from room**, score −100, account flagged, eligible only for Bronze rooms for 90 days. | MVP |
| PAY-8 | All UPI references and screenshots are stored as part of the immutable ledger entry. They are evidence, not money movement. | MVP |

### 10.5 Trust Score Mechanics

The brief gives a directional spec. Tightened version:

```
Starting score: 100  (Bronze)

EVENTS (numeric deltas)
  on_time_confirm:           +5
  cycle_complete:            +5  (additional)
  room_complete (per room):  +20
  foreman_role_complete:     +30  (additional for foremen)
  positive_peer_rating:      +1 per rating, cap +10 per cycle
  identity_verified_pan:     +10 one-time
  identity_verified_bank:    +10 one-time
  identity_verified_aadhaar: +20 one-time (Track B)

  late_confirm (24h+):        -10
  disputed_against_user:      -30 (only on confirmed adverse outcome)
  default_cycle:              -30
  default_removed:           -100
  fraud_confirmed:           -200 + account suspension
  rule_violation_minor:        -5

LEVELS (computed at score change)
  Bronze:    0   – 199
  Silver:    200 – 399
  Gold:      400 – 699
  Platinum:  700 – 899
  Diamond:   900+

ROOM-SIZE CAP BY LEVEL (max single-cycle contribution)
  Bronze:    ₹10,000
  Silver:    ₹50,000
  Gold:      ₹1,00,000
  Platinum:  ₹5,00,000
  Diamond:   no cap (subject to identity gates)

DECAY
  Inactivity 90+ days: −1/day, floor at 100.
  Prevents long-dormant accounts from leveraging old high scores.

VISIBILITY
  User sees all events that affected their score.
  Counterparties see only level (Bronze..Diamond), never numeric score.
  Rationale: avoids score-shaming and reduces incentive to game.
```

**[OPEN QUESTION OQ-2]:** Should foreman role be score-rewarded *more* than subscriber (to attract foremen) or *less* (to keep score comparable across roles)? My recommendation: more, with separate display (Foreman Tier I/II/III), but **OQ-2** for founder.

### 10.6 Gamification — Seatu Gems

```
EARNING
  on_time_confirm:             +10 gems
  perfect_cycle (room-wide):   +20 gems to every member
  room_complete:               +100 gems
  successful_referral:         +50 gems  (when referee completes 1 room)
  identity_verified (each):    +25 gems
  positive_peer_rating:        +5 gems
  monthly_streak (3 months):   +50 gems
  monthly_streak (12 months):  +500 gems

REDEMPTION (MVP)
  ₹10 mobile recharge:         50 gems
  ₹100 Amazon voucher:         500 gems
  ₹500 BigBasket voucher:      2500 gems
  ₹1000 grocery voucher:       5000 gems

  Conversion: roughly ₹1 = 5 gems. This is a 20% effective payout
  on engagement-driven activity, which is sustainable only if it
  offsets CAC. See unit-economics note below.

ANTI-GAMING RULES
  - Referral gem only on referee's first completed room.
  - One self-rating chain per cycle.
  - Gems forfeited on account suspension.
  - Gems do not convert to cash. (Critical: cash-out would trigger
    Prepaid Payment Instrument rules under RBI.)
```

**Unit-economics warning:** if average user earns 200 gems/month and redeems at the 5:1 ratio, that's ₹40/user/month liability. At 10,000 users that's ₹400,000/month or ~₹50L/year in reward cost. We need either (a) a sponsor (e.g., a brand pays for the voucher pool in exchange for placement), (b) lower payout, or (c) a higher monetisation per user. The brief's "mixer grinder, pressure cooker" rewards are an order of magnitude more expensive and **must not** be in v1.

### 10.7 Disputes (lightweight in MVP, robust in Track B)

```
TYPES (MVP)
  contribution_not_received  (foreman or member files)
  payout_not_received        (winning member files)
  auction_integrity          (any member files)
  rule_violation             (any member files)

WORKFLOW (MVP)
  1. Filer submits dispute with evidence (text, screenshots, UPI refs)
  2. Respondent has 48h to respond with their evidence
  3. Foreman adjudicates within 7 days (foreman is incentivised
     because room cannot progress until resolved)
  4. If foreman is party or fails to act → escalate to SEATU support
     via in-app ticket (email-backed in MVP)
  5. Decision recorded in immutable ledger; score impact applied

WORKFLOW (Track B)
  - In-app adjudicator queue staffed by Company Handlers
  - Decision SLA: 72h for ≤₹1L rooms, 24h for >₹1L rooms
  - Appeal mechanism with second-level review
  - Pattern detection: repeated disputes by same actor trigger flag
```

### 10.8 Notifications

FCM-based push. Critical events also via SMS (cost-controlled — see §16).

```
EVENT                            PUSH    SMS   EMAIL  IN-APP
payment_due_t_minus_3            Y       N     N      Y
payment_due_t_minus_1            Y       N     N      Y
payment_due_t                    Y       Y     N      Y
payment_overdue                  Y       Y     N      Y
auction_open                     Y       N     N      Y
auction_closing_1h               Y       N     N      Y
auction_winner_announced         Y       N     N      Y
dispute_filed_against_you        Y       Y     Y      Y
trust_score_change_significant   Y       N     N      Y
gem_awarded                      N       N     N      Y
room_complete                    Y       N     Y      Y
identity_verification_status     Y       N     Y      Y
new_device_login                 Y       Y     Y      Y
```

### 10.9 Admin / Operations (v1.5)

- User search, view, suspend.
- Room search, view, force-cancel.
- Dispute queue.
- Audit log viewer (read-only).
- Manual trust-score adjustment with mandatory reason + dual approval.
- Reward voucher inventory and redemption status.
- Bulk announcement (for legal/compliance updates).

---

## 11. Non-Functional Requirements

| Category | MVP target | Track B target |
|---|---|---|
| Concurrent users | 1,000 | 100,000 |
| Active rooms | 500 | 50,000 |
| API p95 latency | < 500ms | < 200ms |
| App cold start | < 3s on mid-range Android | < 2s |
| Uptime | 99.5% | 99.95% |
| Data residency | India (mandatory under DPDP and prudent for trust) | India |
| Localisation | English + Tamil at launch | + Te / Kn / Ml / Hi |
| Accessibility | WCAG AA | WCAG AA + voice nav |
| Offline behaviour | View-only of cached data; mutations queue and sync | Same |
| Battery / data | <100MB cached, <50MB/month data | Same |
| Min Android | API 24 (Android 7) — covers ~95% installed base in India | Same |

---

## 12. Success Metrics

### North-star metric
**Active room-cycles per month** — i.e., the count of (room × cycle) pairs that completed cleanly that month. This captures usage, completion, and trust simultaneously.

### Activation
- D1 retention > 50%
- Time from install to first room joined < 7 days for invited users; < 30 days for direct installs

### Engagement
- Cycle on-time-confirmation rate > 92% (offline informal benchmark is ~85%)
- Auction participation rate > 70% of eligible bidders per cycle

### Trust
- Default rate < 4% of cycles (offline informal is 8–12%)
- Dispute rate < 2% of cycles
- % of users who reach Silver within first room completion > 80%

### Growth
- K-factor (foreman invites that activate) > 0.8 in first 6 months
- Cost per activated user < ₹120 (organic + paid blended)

### Monetisation (Phase 2+)
- Paid foreman tools adoption > 20% of foremen
- ARPU among paying users > ₹150/month
- Gross margin on reward marketplace > 10%

---

## 13. Pricing & Monetisation (MVP-relevant only)

The brief lists 7 revenue lines. Realistic v1 (Track A, money doesn't move through us — so no take-rate on transactions):

1. **Foreman Pro subscription** (₹99 or ₹199/month) — unlocks rooms up to 25 members (free tier capped at 10), PDF exports, custom rules text, branded room. **This is the only material revenue line in Track A.**
2. **Reward marketplace margin** — voucher partners typically give 3–8% margin. Thin.
3. **Verified foreman badge** (one-time ₹999 / annual ₹499) — requires identity + bank + (Track B) Aadhaar + a video KYC by our ops. Conveys premium trust.

Track B unlocks the bigger revenue lines: foreman-commission share (with licence partner), platform fee, premium membership, lending lead generation.

Revenue projections will be modelled in the Investor Phase. Order of magnitude in year 1 (Track A only): **₹15–40L ARR**. This is not VC-fundable on its own — we raise on the *trust-score-as-infrastructure* vision and the path to Track B.

---

## 14. Default & Risk Posture

Already partially specified in §10.4. Whole-platform view:

### 14.1 Default Tiers
- **Late** (0–48h overdue): score −10, push reminders, no other action.
- **Cycle default** (48h–7d): score −30, foreman notified, member-tier-restricted from joining new rooms during that period.
- **Room default** (7d+ or 2nd default in one room): score −100, removed from room, restricted to Bronze rooms for 90 days, all gem balance frozen.
- **Fraud confirmation**: account suspended, score −200, gem balance forfeited, IP / device / PAN flagged, name added to internal blocklist.

### 14.2 Foreman Liability (MVP, Track A)
SEATU explicitly disclaims responsibility for funds in v1. Terms of Service must state this in plain Tamil and English on the room-creation flow. **This is the single biggest user-experience friction in v1** and must be acknowledged. Hand-waving it will create regulatory and reputational trouble.

### 14.3 Anti-Abuse
- One account per (phone + PAN). Duplicate PAN block at registration.
- Device fingerprint to prevent multi-account from same device.
- Velocity rules: a new account cannot foreman a room in first 30 days, cannot join a >₹10k room in first 15 days.
- Periodic re-verification of bank account ownership (every 6 months).
- Behavioural anomaly logging (for Track B AI use).

### 14.4 Founder Risk
- **Reputational.** A single defaulted high-value room with a press-y user (journalist, influencer) is an extinction-level event in trust businesses. Mitigation: hard caps on first-year rooms; aggressive QA on the first 50 rooms personally; manual review of any room ≥ ₹50k by ops.

---

## 15. Tech Stack Decisions (PRD-level — full architecture in Phase 2)

The brief's stack (Flutter / Riverpod / GoRouter / NestJS / Prisma / PostgreSQL / FCM / Supabase Storage / Railway) is sound for an MVP and I endorse it. Two adjustments I'd push back on:

1. **Supabase Storage is fine; consider just using Supabase Auth too** for v0 to avoid hand-rolling JWT refresh, then migrate to custom NestJS auth before Track B. Saves 2–3 weeks. (Counter-argument: lock-in. Decision in Phase 2.)
2. **Add Sentry + PostHog from day 1.** Crash reporting and product analytics are non-negotiable. Cost: free tiers cover us through ~20k users.

Choice of Razorpay/Cashfree for penny-drop bank verification will happen in Phase 2.

---

## 16. Operating Cost Estimate (MVP, year 1)

Order-of-magnitude monthly run rate at 5,000 MAU:

| Item | ₹/month |
|---|---|
| Compute (Railway/Render hobby+ plans) | 5,000 |
| Postgres (managed) | 5,000 |
| SMS (MSG91, ~30k SMS/month) | 4,500 |
| Push (FCM, free) | 0 |
| KYC (PAN @ ₹3/verification, ~500/mo) | 1,500 |
| Bank penny-drop (~₹6 × 200/mo) | 1,200 |
| Sentry / PostHog | 0 (free tier) |
| Domain, mail, misc | 2,000 |
| **Tech run rate** | **~₹20,000/mo** |
| Reward voucher liability (see §10.6) | ~₹40,000/mo at 5k MAU |
| Ops (2 contract handlers for disputes, Track A) | ~₹40,000/mo |
| **Total run rate** | **~₹100,000/mo** |

Two-developer salary cost is separate and dwarfs everything else. Tech run rate is genuinely cheap; the cost trap is the reward marketplace.

---

## 17. Compliance & Privacy

### 17.1 DPDP Act readiness (mandatory)
- Privacy policy in English + Tamil before launch.
- Granular consent at collection: phone, PAN, bank, contacts (only if user opts into contact-based invites), location (never required).
- User rights: data export, account deletion, consent withdrawal.
- Breach-notification SOP (template in place by launch).
- DPO designated (founder can play this role at MVP scale).

### 17.2 Data minimisation
- PAN verified, then **only last 4 digits stored**, plus the verification result. Full PAN goes to KYC partner, not us.
- Bank account number similarly hashed-with-last-4.
- Aadhaar (Track B) never stored — only the e-KYC reference.

### 17.3 Audit log
- Append-only, separate from the main transactional DB.
- Retained for 7 years (Income Tax Act baseline).
- User-visible portion: their own actions, score changes, dispute outcomes.

### 17.4 IP / brand
- "SEATU" — confirm trademark availability in Class 36 (financial services) and Class 9 (mobile apps) before any spend. **[OPEN QUESTION OQ-5]**

---

## 18. Localisation

- **Tamil + English at launch**, with Tamil as the *default* for first-time users on Indian SIM cards detected via MCC. This is contrarian — most fintech apps default to English — and is a deliberate trust signal.
- All number formats in Indian system (lakh / crore), not international (million / billion).
- Currency: ₹ only.
- Date format: dd MMM yyyy (15 Jun 2026), not MM/DD/YYYY.

---

## 19. Risks Register

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| R-1 | Regulatory action under Chit Funds Act | M | Existential | Posture A in v1; legal opinion before launch; partnership path defined in 6 months |
| R-2 | Default cascade in a high-value early room | M | Severe | Cap room size to ₹10k in first 90 days; manual ops review |
| R-3 | Account-takeover via SIM swap | L | Severe | Device binding, peer-vouch recovery (§10.1, AUTH-8) |
| R-4 | Trust-score gaming via collusion (round-tripping members across micro-rooms) | M | Moderate | Velocity rules, social-graph anomaly checks, minimum room size of 5 |
| R-5 | Reward marketplace cost > revenue | H | Moderate | Cap monthly redeemable gems per user; pursue brand sponsors |
| R-6 | App-store rejection (chit funds are scrutinised on Play Store) | M | High | Position as "savings group coordination," not "chit fund"; pre-flight with Play Store policy team |
| R-7 | DPDP non-compliance penalty | L | High | Compliance baseline before launch (§17) |
| R-8 | Founder bandwidth — running ops + product + sales simultaneously | H | Moderate | Hire community ops contractor by month 3 |
| R-9 | Cultural mismatch in non-Tamil-speaking markets | M | Moderate | Stay South India in year 1; expand language-by-language with native ops |
| R-10 | "Tamil-only" branding cost in non-Tamil pitches to (mostly North-India-based) VCs | M | Low–Mod | Bilingual positioning materials, but Tamil-first stays as the product principle |

---

## 20. Phasing & Timeline (MVP)

Assuming 2 developers (1 Flutter, 1 NestJS) starting day 1.

```
Month 0 (pre-build)
  - Founder sign-off on this PRD
  - Legal opinion procured (chit funds, posture)
  - Trademark filed
  - Phase 2 (architecture) drafted by CTO, approved by founder

Month 1
  - Phase 3 (DB design) + Phase 4 (API design)
  - Backend skeleton: auth, users, rooms (Draft state)
  - Flutter skeleton: onboarding, auth, dashboard shell

Month 2
  - Rooms (Recruiting → Active), members, invitations
  - PAN + bank verification flows wired
  - Auction module end-to-end
  - Contribution tracking + dispute v1

Month 3
  - Trust score engine
  - Gems + voucher redemption (Amazon test mode)
  - Notifications, profile, achievements
  - Audit log + admin v1
  - Closed alpha with 20 hand-picked users (founder's existing chit network)

Month 4
  - Bugs, polish, accessibility audit
  - Tamil localisation
  - Play Store submission, App Store deferred
  - Public launch in Coimbatore + Chennai (geo-fenced)

Months 5–6
  - Iterate on real-user feedback
  - Begin Track B partnership conversations (Margadarsi / Shriram / regional)
  - Seed round close
```

**Honest assessment of the 2–4 month timeline:** With 2 strong devs and a hands-on CTO/founder, **the bare-bones v1 is buildable in 14–16 weeks**. The brief's "2 months" is unrealistic; "4 months" is achievable if scope holds. The single biggest schedule risk is scope creep on the trust score and the auction edge cases.

---

## 21. Out-of-Scope (explicit, to lock down scope)

The following are **NOT** in MVP, despite appearing in the brief:

- Aadhaar verification (Track B)
- Public rooms / room discovery (Track B)
- AI risk engine (Track B)
- Automated UPI collections (Track B)
- Escrow / wallet (Track B)
- Mixer grinder / pressure cooker rewards (never in v1 — vouchers only)
- Loans / financial product partnerships (Track B+)
- iOS app (v1.1)
- Web app (Track B)
- Languages beyond Tamil/English (Track B)
- Community Coordinator as a paid role (Track B — but volunteer "veterans" feature can ship in v1.5)

---

## 22. Open Questions for Founder (MUST RESOLVE BEFORE PHASE 2)

These are the questions that change the architecture. I am not making Phase-2 decisions until I have answers.

**OQ-1. Legal posture.** Which of the three postures in §2 are we committing to for Track A → Track B path? My recommendation is A → C → B. Confirm or pick differently.

**OQ-2. Trust score asymmetry by role.** Does the foreman role earn score the same way as a subscriber, or do we maintain a separate "Foreman Tier" track (my recommendation)?

**OQ-3. Money movement in MVP.** Do you agree we *do not* move money in v1? If you push to add even simple UPI collection, we add 6–10 weeks for PA partnership / sandboxing and need a different cost model.

**OQ-4. Community Coordinator vs Company Handler.** The brief blurs these. Coordinator = volunteer veteran with limited tools. Handler = paid SEATU/partner staff for high-value rooms. Confirm split, and confirm Coordinator is v1.5 not v1.

**OQ-5. Brand & trademark.** "SEATU" — has the trademark search been done? If not, I need this kicked off in the next 7 days so we don't build under a name we can't own.

**OQ-6. Geographic launch scope.** I'm assuming Tamil Nadu first (Coimbatore + Chennai). Confirm. South-India broad is a year-1 stretch goal.

**OQ-7. Founder time commitment to dispute ops.** In the first 6 months you will personally adjudicate disputes. This is not delegable to a contractor early. Confirm bandwidth (estimate: 5–8 hrs/week from month 4).

**OQ-8. Reward marketplace partner.** Are we comfortable with vouchers-only in v1, despite the brief's mention of appliances? My strong recommendation is yes.

**OQ-9. Co-founder / second-developer hire status.** Is a second developer (Flutter or backend) hired, or do we plan around just one for the first three months? The 2–4 month timeline is built on two FTEs.

**OQ-10. Capital available for runway.** What's the runway assumption — bootstrap, friends-and-family, pre-seed? Tech cost is small (§16) but ops cost (handlers, KYC) scales with users. Pre-seed of ₹50L–₹1Cr is the comfortable range for 12 months.

---

## 23. Glossary

| Term | Meaning |
|---|---|
| Seatu / Seettu / Chit | A rotating savings & credit association where members contribute and one wins the pool per cycle. |
| Foreman | Organiser of a chit, traditionally responsible for collection, auction, and disbursement. In SEATU MVP, a person — not the platform. |
| Subscriber / Member | A participant in a chit. |
| Prize / Pool | The total amount disbursed in a cycle. |
| Discount | The amount a winning bidder forgoes from the pool (their "cost" of winning early). |
| Commission | Foreman's fee per cycle, capped at 5% of chit value by the Chit Funds Act. |
| Cycle | One period (monthly in v1) with one auction and one payout. |
| Room | SEATU's term for one chit group instance. |
| Trust Score | SEATU's portable behavioural score, 100-base, level-banded. |
| Seatu Gems | In-app reward currency, redeemable for vouchers. |
| Track A / Track B | MVP and Scale variants of the product. |

---

## End of Phase 1 PRD

**Next phase:** Phase 2 — System Architecture (modular monolith for Track A; service decomposition map for Track B; sequence diagrams for the four critical flows: onboarding, room creation, auction, dispute).

**Status:** Awaiting founder responses to OQ-1 through OQ-10 in §22, plus overall PRD sign-off.
