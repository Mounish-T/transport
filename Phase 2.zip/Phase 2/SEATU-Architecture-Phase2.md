# SEATU — System Architecture

**Phase 2 Deliverable · v0.1 (Draft)**
**Owner:** CTO
**Status:** Awaiting founder review before Phase 3 (Database Design)
**Date:** June 2026

---

## 0. Working assumptions

Founder approved Phase 1 without explicit answers to OQ-1 through OQ-10. This architecture is built on the following **assumed** answers. Any change to OQ-1, OQ-3, or OQ-9 forces a meaningful rework.

| OQ | Assumed answer | Architectural impact if changed |
|---|---|---|
| **OQ-1 Legal posture** | A → C → B path. MVP = pure coordination layer. | **High.** If "B from day one" (own foreman, hold funds), add escrow, settlement engine, PA partner — adds ~10 weeks. |
| **OQ-2 Foreman score track** | Separate Foreman Tier (I/II/III) parallel to subscriber Bronze..Diamond. | Low. One extra table, one extra projector. |
| **OQ-3 Money movement in MVP** | **No money movement.** Tracking-only ledger. | **Very high.** Reversing this adds escrow accounts, PA integration, settlement engine, RBI reporting. ~30% of this doc changes. |
| **OQ-4 Coordinator vs Handler** | Coordinator = v1.5 volunteer. Handler = Track B paid role. | Low. New role string + a few permission rules later. |
| **OQ-5 Trademark** | Out of my scope; founder owns. | None on architecture. |
| **OQ-6 Geography** | Tamil Nadu launch (Coimbatore + Chennai). | Low. Affects data residency choice (we'd pick ap-south-1 / Mumbai anyway). |
| **OQ-7 Founder dispute ops** | Yes, founder adjudicates first 6 months. | Low. Just means no dedicated handler tooling in v1. |
| **OQ-8 Reward marketplace** | Vouchers only via Qwikcilver-style aggregator. | Low. |
| **OQ-9 Second dev** | Yes, 2 FTE from day 1 (1 Flutter, 1 NestJS). | **Moderate.** If only 1 dev, drop scope further (no admin v1, no gems v1) and stretch timeline to 5–6 months. |
| **OQ-10 Capital** | Pre-seed or bootstrap with frugal posture. Run rate ≤ ₹1.5L/mo. | Low. Drives infrastructure choices (Railway > AWS). |

If any of OQ-1, OQ-3, or OQ-9 is actually different from above, **stop here and tell me before Phase 3.**

---

## 1. Architectural style

### Decision: Modular Monolith for Track A → Service-extraction for Track B

**Why monolith now**
- 2 FTEs, 14–16 weeks. Distributed systems debugging will eat the schedule.
- One DB transaction crossing modules (e.g., "confirm contribution AND emit trust event AND queue notification") is the most common write pattern. Cross-service distributed transactions are the wrong place to be in month one.
- Single deployment, single observability surface, single secret store.
- Local dev = `docker compose up`.

**Why "modular" matters**
- The monolith has hard internal boundaries (NestJS modules; one schema per module in Postgres; no cross-module table reads). When we extract to services in Track B, the cut lines are pre-drawn.
- Strict ESLint rules forbid `import` paths that cross module boundaries except via a module's public `index.ts`.

**Why not microservices now**
- We have ten domain concepts, not ten teams. Microservices require team-shaped boundaries; we have one team.
- Operational cost of 8 services on Railway is real (>₹40k/mo extra) at zero user benefit.

**Why not serverless (Lambda + DynamoDB)**
- Postgres + Prisma is what the team knows. Auction state machine + ledger projectors are not a good fit for ephemeral function execution. Cold starts on UPI-reference-entry are user-hostile.

### What is the monolith composed of?

```
                    SEATU MONOLITH (NestJS)
┌─────────────────────────────────────────────────────────────────┐
│                                                                  │
│   ┌──────────┐   ┌──────────────┐   ┌──────────┐   ┌─────────┐  │
│   │   iam    │   │ verification │   │   room   │   │ auction │  │
│   └──────────┘   └──────────────┘   └──────────┘   └─────────┘  │
│                                                                  │
│   ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌────────────┐   │
│   │  ledger  │   │  trust   │   │   gems   │   │  dispute   │   │
│   └──────────┘   └──────────┘   └──────────┘   └────────────┘   │
│                                                                  │
│   ┌──────────────┐   ┌──────────┐   ┌──────────┐                │
│   │ notification │   │  audit   │   │  admin   │                │
│   └──────────────┘   └──────────┘   └──────────┘                │
│                                                                  │
│   ─── Shared ───                                                 │
│   eventbus  |  outbox  |  scheduler  |  config  |  errors        │
└─────────────────────────────────────────────────────────────────┘
```

Each module = one NestJS feature module = one Postgres schema = one future service.

---

## 2. System context

```mermaid
flowchart LR
    User[("Subscriber / Foreman<br/>(Flutter App)")]
    Ops[("Founder / Ops<br/>(Admin Web v1.5)")]

    subgraph SEATU["SEATU Platform"]
        API["NestJS API<br/>(Modular Monolith)"]
        Jobs["BullMQ Workers<br/>(scheduled + async)"]
        DB[("PostgreSQL<br/>(managed)")]
        Cache[("Redis<br/>(queue + rate limit)")]
        Files[("Supabase Storage<br/>(screenshots, PDFs)")]
    end

    subgraph External["External Providers"]
        SMS["MSG91<br/>SMS / OTP"]
        FCM["Firebase Cloud<br/>Messaging"]
        KYC["KYC Aggregator<br/>(Karza / Signzy)"]
        Vouchers["Voucher Partner<br/>(Qwikcilver / Pine Labs)"]
        Sentry["Sentry<br/>+ PostHog"]
    end

    User -->|HTTPS| API
    Ops -->|HTTPS| API
    API <--> DB
    API <--> Cache
    API <--> Files
    Jobs <--> DB
    Jobs <--> Cache
    API --> SMS
    API --> FCM
    API --> KYC
    API --> Vouchers
    API --> Sentry
    Jobs --> SMS
    Jobs --> FCM
```

What's deliberately *not* in this diagram:
- No payment gateway / payment aggregator. Direct consequence of OQ-3.
- No CDN. Static assets are small; Supabase Storage serves them.
- No analytics warehouse in v1. PostHog handles product analytics; we'll add a warehouse (BigQuery or Postgres replica) in Track B.
- No load balancer. Railway/Render terminates TLS and load-balances internally.

---

## 3. Module decomposition

Each module owns its data, exposes a TypeScript interface (its "service"), and emits/consumes events on a shared in-process EventBus. **Module A may not read Module B's tables.** Enforced by lint + code review.

### 3.1 Module catalog

| Module | Owns | Exposes | Consumes |
|---|---|---|---|
| **iam** | users, sessions, devices, refresh-tokens | `UserService`, `AuthService` | — |
| **verification** | verification_attempts, verification_results | `VerificationService` | `iam.UserService` |
| **room** | rooms, room_members, invitations | `RoomService` | `iam`, `trust` (for Trust Gate) |
| **auction** | auctions, bids, auction_results | `AuctionService` | `room`, `iam`, `trust` |
| **ledger** | ledger_events (append-only), contribution_status, payout_status | `LedgerService` | `room`, `auction` |
| **trust** | trust_events, trust_score_current, trust_tier_history | `TrustService` | events from `ledger`, `dispute`, `verification`, `room` |
| **gems** | gem_events, gem_balance, redemptions | `GemService` | events from `ledger`, `room`, `iam` |
| **dispute** | disputes, dispute_evidence, dispute_resolutions | `DisputeService` | `ledger`, `room`, `auction` |
| **notification** | notification_log, device_tokens (mirror of iam), preferences | `NotificationService` | all modules (via events) |
| **audit** | audit_log (append-only) | `AuditService` | all modules (mandatory write on every mutation) |
| **admin** | admin_users, admin_actions | `AdminService` | all modules (read + privileged ops) |

### 3.2 Module boundary rules (enforced)

```
1. A module's tables are read/written ONLY by its own repository layer.
2. Cross-module calls go through the target module's public service interface
   (the `index.ts` export). Never through a "shared" repository.
3. Cross-module side effects (e.g., "trust score should update when a
   contribution is confirmed") flow via the EventBus, NOT direct calls.
   - Producer: ledger emits `ContributionConfirmedEvent`
   - Consumer: trust subscribes, updates score
4. Audit write is the ONE exception: every mutation handler MUST write to
   `audit.AuditService.record(...)` synchronously in the same transaction.
5. ESLint rule `no-restricted-imports` blocks module-to-module path imports.
```

### 3.3 The EventBus (in-process)

We use NestJS's `EventEmitter2`-based event bus, wrapped in a thin `DomainEventBus` abstraction.

```
                ┌────────────────────────────────────┐
                │            DomainEventBus           │
                │ (in-process, type-safe pub/sub)     │
                └────────────────────────────────────┘
                       ▲                    ▲
              publishes│             subscribes│
                       │                    │
    ┌─────────┐   ┌────────┐         ┌──────┐   ┌─────────────┐
    │ ledger  │   │ room   │   ...   │ trust│   │ notification│
    └─────────┘   └────────┘         └──────┘   └─────────────┘
```

**Critical:** events that have side effects outside the DB (push notifications, SMS, KYC partner calls, voucher redemptions) are **NOT** dispatched directly from the event handler. They go through the **outbox** (§4.3).

---

## 4. The core abstraction: event-sourced ledger

This is the most important decision in this document. Read it twice.

### 4.1 What is event-sourced and what isn't

**Event-sourced (write model is events, read model is projection):**
- `ledger` module — every contribution / payout / dispute event
- `trust` module — every score change event
- `audit` module — every privileged action

**NOT event-sourced (classic CRUD):**
- `iam` — current user, current session
- `room` — room state machine (we use status column + transitions, not events)
- `auction` — auction state machine (same)
- `gems` — could be event-sourced; for simplicity, transaction-style ledger table with running balance

**Why this split:** Event sourcing is overhead. We apply it only where audit/replay is genuinely required — money-equivalent records (ledger) and reputation (trust). Everywhere else, normal SQL is cheaper to build and debug.

### 4.2 The ledger event model

```
ledger_events (append-only, no UPDATE, no DELETE)
─────────────────────────────────────────────────
id              UUID
occurred_at     TIMESTAMPTZ NOT NULL
aggregate_id    UUID NOT NULL      -- usually a room cycle id
aggregate_type  TEXT NOT NULL
event_type      TEXT NOT NULL      -- see vocab below
event_version   INT NOT NULL DEFAULT 1
payload         JSONB NOT NULL
actor_user_id   UUID
actor_role      TEXT
idempotency_key TEXT UNIQUE        -- per-event uniqueness
prev_event_id   UUID               -- for ordered chains within aggregate
metadata        JSONB              -- request_id, ip, user_agent, etc.

INDEX (aggregate_id, occurred_at)
INDEX (event_type, occurred_at)
UNIQUE (idempotency_key)
```

**Event vocabulary (v1):**

```
ContributionMarkedPaid       -- member self-reports "I paid"
ContributionConfirmed        -- foreman confirms
ContributionDisputed         -- foreman or member raises dispute
ContributionResolved         -- dispute outcome applied

PayoutMade                   -- foreman records disbursement
PayoutConfirmed              -- winner confirms receipt

BidPlaced                    -- auction bid (encrypted until close)
AuctionClosed                -- auction window over, winner selected

DisputeFiled
DisputeAccepted
DisputeRejected
DisputeEscalated

DefaultDetected              -- emitted by scheduler when overdue
MemberRemovedForDefault      -- emitted when policy triggers
```

**Read models (projections) built from these events:**
- `contribution_status (room_id, cycle, member_id, status, paid_at, confirmed_at, ref)`
- `payout_status (room_id, cycle, winner_id, status, paid_at, confirmed_at)`
- `room_cycle_summary (room_id, cycle, pool, discount, foreman_commission, net_payout, winner_id)`

Projections are rebuilt from events on demand (`pnpm rebuild:projections`) — a critical operability win.

### 4.3 The outbox pattern (for external side effects)

```mermaid
sequenceDiagram
    participant H as Mutation Handler
    participant DB as Postgres (single TX)
    participant W as Outbox Worker
    participant E as External (FCM/SMS/KYC)

    H->>DB: BEGIN
    H->>DB: write domain change
    H->>DB: write ledger_event
    H->>DB: write outbox_event (status=pending)
    H->>DB: COMMIT
    Note over H,DB: Single ACID transaction.<br/>If anything failed, nothing happened.

    loop every 2s
        W->>DB: SELECT FOR UPDATE SKIP LOCKED<br/>WHERE status='pending'
        W->>E: dispatch (push / sms / api)
        E-->>W: 200 OK
        W->>DB: status='dispatched'
    end
```

**Why this matters:** without it, you get nightmares like "score updated but notification never sent" or "notification sent twice because retry." The outbox is one of the three most important infra decisions in the system.

---

## 5. Data architecture (overview only — full schema in Phase 3)

### 5.1 Storage choices

| Data class | Store | Justification |
|---|---|---|
| Transactional (rooms, users, ledger) | **PostgreSQL** | Strong ACID, mature, Prisma support, single store covers >90% of needs. |
| Hot keys (sessions, rate-limit counters, job queue) | **Redis** | Sub-ms reads, native TTL, BullMQ requires it. |
| Files (screenshots, exported PDFs) | **Supabase Storage** | S3-compatible, cheap, no egress fee for us-equivalents in their pricing. Signed URLs for short-lived access. |
| Search (in v1: none) | — | Postgres full-text is enough for v1. ElasticSearch only at Track B. |
| Analytics warehouse | — (PostHog hosted) | No internal warehouse in MVP. |

### 5.2 Postgres deployment

- **One database, multiple schemas** — one schema per module (`iam`, `verification`, `room`, `auction`, `ledger`, `trust`, `gems`, `dispute`, `notification`, `audit`).
- **Prisma schema files are co-located with modules** (`src/modules/iam/prisma/schema.prisma`) and merged at build time. Avoids the "one giant Prisma file" anti-pattern.
- **Row-level security disabled in v1** — we enforce access at the service layer. RLS adds Postgres role management complexity; not worth it pre-Track-B.
- **Backups:** daily snapshot, 30-day retention. Point-in-time recovery enabled on the managed Postgres plan.

### 5.3 Critical indexes (preview — full list in Phase 3)

- `ledger_events (aggregate_id, occurred_at)` for projection rebuilds
- `ledger_events (idempotency_key)` UNIQUE — protects against double-writes
- `audit.audit_log (actor_user_id, occurred_at DESC)` for per-user audit views
- `room.rooms (foreman_user_id, status)` — foreman's active rooms dashboard
- `auction.bids (auction_id, placed_at)` — auction close worker scan

---

## 6. Critical sequence flows

The four flows that must be designed end-to-end before Phase 3. Everything else is a variation of one of these.

### 6.1 Onboarding & verification

```mermaid
sequenceDiagram
    autonumber
    participant U as User (App)
    participant API as API
    participant SMS as MSG91
    participant KYC as KYC Aggregator
    participant DB as Postgres

    U->>API: POST /auth/otp/request {phone}
    API->>DB: rate_limit check (5/hr per phone)
    API->>SMS: send OTP
    API-->>U: 200 (otp_ref)
    U->>API: POST /auth/otp/verify {phone, otp, device_fingerprint}
    API->>DB: insert user (if new), session, device
    API-->>U: 200 (access_token, refresh_token)
    Note over U,API: User now signed in but unverified.<br/>Can create rooms only ≤ ₹10k.

    U->>API: POST /verification/pan {pan, name}
    API->>DB: insert verification_attempt (status=pending)
    API->>KYC: PAN verify request
    KYC-->>API: name_match=0.92, status=valid
    API->>DB: update verification_attempt (status=success)
    API->>DB: insert verification_result (pan_last4, name_match)
    API->>DB: emit TrustEvent (+10) via EventBus
    API-->>U: 200 (verification status)
```

**Notes:**
- OTP rate limit is enforced in Redis (sliding window, 5/hr/phone, 20/hr/IP).
- Device fingerprint is the SHA-256 of `(device_id || install_id || os_version)`. Stored to allow "new device" detection.
- PAN full value never lands on our DB. We send to KYC partner, get the result, store last 4.

### 6.2 Room lifecycle

```mermaid
stateDiagram-v2
    [*] --> Draft: Foreman creates room
    Draft --> Recruiting: First member joins via invite
    Recruiting --> Recruiting: More members join
    Recruiting --> Active: Foreman taps "Start"<br/>(quorum reached)
    Recruiting --> Cancelled: Foreman cancels before start
    Active --> Active: Cycle N closes,<br/>Cycle N+1 opens
    Active --> Completed: Final cycle done
    Active --> Cancelled: Unanimous member consent
    Completed --> [*]
    Cancelled --> [*]
```

State transitions are enforced in `RoomService.transitionTo(newState, actor, reason)`. Invalid transitions throw `IllegalRoomTransition`. Every transition emits a domain event and writes an audit entry.

### 6.3 Auction cycle (the most complex flow — read carefully)

```mermaid
sequenceDiagram
    autonumber
    participant Sched as Scheduler (BullMQ)
    participant API as Auction Service
    participant DB as Postgres
    participant Bus as EventBus
    participant Notif as Notification Service
    participant Out as Outbox Worker
    participant FCM as Firebase

    Sched->>API: cron: open_auction(room_id, cycle)
    API->>DB: insert auction (status=open, closes_at=now+24h)
    API->>Bus: AuctionOpened
    Bus->>Notif: handler
    Notif->>DB: write outbox_event (push to all members)
    Out->>FCM: dispatch
    FCM-->>Out: 200

    loop for each bidder
        Note over API,DB: Member places bid
        API->>DB: validate (member eligible, not previously won)
        API->>DB: insert bid (discount, encrypted_payload, placed_at)
        API->>Bus: BidPlaced
        Note over Bus: No fanout to other members.<br/>Bids are sealed.
    end

    Sched->>API: cron: close_auction(auction_id)<br/>(triggered at closes_at)
    API->>DB: SELECT bids WHERE auction_id (FOR UPDATE)
    API->>API: pick winner (lowest discount, tie=earliest)
    API->>API: if no bids: random lot
    API->>DB: insert auction_result (winner_id, discount, payout)
    API->>DB: update auction (status=closed)
    API->>DB: insert ledger_event (AuctionClosed)
    API->>Bus: AuctionClosed
    Bus->>Notif: handler → outbox → FCM
    Note over API,DB: Cycle now in "collection" phase.<br/>Members owe contributions.<br/>Foreman owes payout to winner.
```

**Edge cases handled (explicitly):**
- **All members previously won (impossible if logic is right, but defensive):** auction throws, ops alerted.
- **Foreman cancels mid-auction:** auction transitions to `cancelled`, no winner, cycle re-runs next month.
- **Tie at lowest discount:** earliest `placed_at` wins. If exactly equal timestamps (clock collision, unlikely): lexicographic on bid UUID. Deterministic.
- **Scheduler outage:** auctions don't auto-close on time. A "reaper" job runs every 5 min, scanning for auctions past `closes_at`, and closes them. Worst case: ~5 min late close, with notification.
- **Bidder places bid in last second:** bid accepted if `placed_at < closes_at`, atomically checked.

### 6.4 Contribution tracking with dispute branch

```mermaid
sequenceDiagram
    autonumber
    participant M as Member
    participant F as Foreman
    participant API as Ledger Service
    participant Disp as Dispute Service
    participant Bus as EventBus
    participant Trust as Trust Service

    M->>API: POST /contributions/mark-paid {cycle, amount, upi_ref, screenshot}
    API->>API: validate amount matches cycle dues
    API->>API: upload screenshot to Supabase Storage
    API->>API: insert ledger_event (ContributionMarkedPaid)
    API->>Bus: ContributionMarkedPaid
    Bus->>Trust: no-op (status not yet confirmed)
    API-->>M: 200

    alt happy path
        F->>API: POST /contributions/confirm {event_id}
        API->>API: insert ledger_event (ContributionConfirmed)
        API->>Bus: ContributionConfirmed
        Bus->>Trust: handler (+5 score)
        Trust->>API: emit TrustScoreDelta event
    else dispute path
        F->>API: POST /contributions/dispute {event_id, reason, evidence}
        API->>Disp: open_dispute(...)
        Disp->>API: insert ledger_event (ContributionDisputed)
        Disp->>Bus: DisputeFiled
        Note over Disp,Bus: Member has 48h to respond.
        M->>Disp: POST /disputes/:id/respond {evidence}
        Disp->>Disp: 7-day SLA: foreman decides<br/>(or escalation in v1.5)
        Disp->>API: insert ledger_event (ContributionResolved {outcome})
        Disp->>Bus: ResolutionApplied
        Bus->>Trust: handler (apply −30 to losing party)
    end
```

### 6.5 Trust score recalculation

```
Trust score = SUM(all trust_events for user, weighted by event-type rules)
             + identity bonuses
             − decay (inactivity > 90d)

Computed: on every relevant event, in the trust event handler.
Materialized: trust_score_current table updated in same TX.
Replayable: `pnpm rebuild:trust --user-id=<x>` re-derives from events.
```

This is a **deliberately boring** computation. No ML, no opaque weights, no surprises. The user can see every event that affected their score in their profile.

### 6.6 Notification fanout (just to make the outbox flow explicit)

```
EventBus publishes event
  ↓
NotificationModule.handler resolves audience + channel(s)
  ↓
Writes one outbox_event per (recipient × channel) — all in same TX as parent event
  ↓
Outbox Worker (every 2s) dequeues batch with SELECT FOR UPDATE SKIP LOCKED
  ↓
Dispatches to FCM / MSG91 / SES
  ↓
On success: status=dispatched, attempts++, last_attempt_at=now
On failure: backoff (1m, 5m, 30m, 2h, fail-after-4)
```

---

## 7. Auth & security architecture

### 7.1 Token model

- **Access token:** signed JWT (RS256), 15-min TTL, payload = `{user_id, roles, device_id}`.
- **Refresh token:** opaque 32-byte random string, stored hashed in DB (`refresh_tokens` table, one row per device). 30-day TTL, rotating — every use issues a new refresh + invalidates old. Family detection: if a revoked refresh is reused, the whole device family is revoked (theft suspected).
- **Why JWT for access:** stateless, easy to verify in middleware, no DB hit per request. Why not for refresh: we need server-side revocation and rotation tracking.

### 7.2 Device binding

Every access token is bound to a device. A token presented from a different `device_id` (hash) is rejected. Adding a new device requires fresh OTP. This is the single highest-leverage anti-takeover control.

### 7.3 Role-based access

```
ROLES (v1)
  member               default
  foreman              has at least one room they own
  admin                SEATU staff
  superadmin           founder

ROLE-PERMISSION rules live in src/shared/authz/policies/
e.g.:
  can(user, "room:start", room) →
    user.id === room.foreman_id && room.status === "recruiting"
```

Permission checks are done at the controller level via a `@Policy('room:start')` decorator + a guard.

### 7.4 OWASP Top 10 mapping

| OWASP | Control |
|---|---|
| A01 Broken Access Control | Decorator-based policy guards, integration tests on every protected endpoint. |
| A02 Cryptographic Failures | TLS 1.2+ enforced; passwords (admin) bcrypt 12 rounds; KYC data stored last-4 only. |
| A03 Injection | Prisma parameterised queries; class-validator on every DTO. |
| A04 Insecure Design | Threat model in §13. Critical flows reviewed by founder before code-complete. |
| A05 Security Misconfiguration | Helmet middleware; CORS allowlist; no default creds; secrets via env not source. |
| A06 Vulnerable Components | Dependabot weekly; `pnpm audit` in CI. |
| A07 Auth Failures | Device binding, refresh rotation, OTP rate limiting, account lockout. |
| A08 Software & Data Integrity | Image upload virus scan via ClamAV worker; ledger immutability. |
| A09 Logging Failures | Structured logs, audit log separately, Sentry for exceptions. |
| A10 SSRF | Outbound URL allowlist for any user-provided URLs (none in v1, but enforce now). |

### 7.5 Secrets

- All secrets in Railway/Render env vars; never in source.
- Local dev uses `.env` file, not committed.
- Production secrets rotated quarterly; KYC partner keys rotated on personnel change.
- One-way secrets (signing keys) generated by a startup script and stored encrypted at rest.

---

## 8. Integration architecture

```mermaid
flowchart LR
    subgraph App["SEATU Modules"]
        V["verification"]
        N["notification"]
        G["gems"]
    end

    subgraph Adapters["Adapter layer<br/>(ports & adapters)"]
        VA["KycPort<br/>↓<br/>KarzaAdapter / SignzyAdapter"]
        NA["PushPort + SmsPort<br/>↓<br/>FcmAdapter / Msg91Adapter"]
        GA["VoucherPort<br/>↓<br/>QwikcilverAdapter"]
    end

    V --> VA
    N --> NA
    G --> GA

    VA --> Karza["Karza API"]
    VA -.fallback.-> Signzy["Signzy API"]
    NA --> FCM["Firebase"]
    NA --> MSG91["MSG91"]
    GA --> Qwik["Qwikcilver"]
```

**Pattern:** every external dependency sits behind a **Port** (interface). The default adapter is one provider; a second adapter is added when we want a fallback or want to switch. We do not couple business logic to vendor APIs.

**Concrete v1 integrations:**

| Provider | Purpose | Notes |
|---|---|---|
| MSG91 | Transactional SMS, OTP | Cheap (~₹0.15/SMS for India). DLT-registered headers required. |
| Firebase Cloud Messaging | Push notifications | Free at our scale. Token stored in `iam.devices`. |
| Karza (primary) / Signzy (fallback) | PAN verification, bank penny-drop | Bank verification via "Bank account verification API." Karza ~₹3/PAN, ~₹6/bank ping. |
| Supabase Storage | Image/file storage | Signed URLs, 1-hour expiry. Public-read disabled. |
| Qwikcilver / Pine Labs Rewards | Voucher issuance | Settled invoice monthly. Maintain pre-paid float (₹50k starting). |
| Sentry | Error tracking | Free tier covers 5k errors/mo. |
| PostHog | Product analytics | Self-host? — no, hosted EU plan for v1 (DPDP angle: we send pseudonymous IDs only, no PII). |

**Important:** no integration is called inside a request handler. Every external call is enqueued via the outbox (§4.3) or BullMQ. The user-facing API returns within 200ms even if Karza is slow.

---

## 9. Background jobs & scheduling

Job queue: **BullMQ** (Redis-backed). Why: maintained, supports delayed jobs, cron jobs, retries, concurrency control, all out of the box.

### 9.1 Job catalog (v1)

| Job | Trigger | Idempotent? | SLA |
|---|---|---|---|
| `auction.open` | Cron per active room cycle | Yes (idempotency key = `auction:${room_id}:${cycle}`) | ±2 min |
| `auction.close` | Delayed job at `closes_at` | Yes | ±5 min |
| `auction.reaper` | Cron every 5 min | Yes | Catches missed closes |
| `payment.reminder.t-minus-3` | Cron daily | Yes | Same day |
| `payment.reminder.t-minus-1` | Cron daily | Yes | Same day |
| `payment.reminder.t` | Cron daily | Yes | Same day |
| `payment.overdue-check` | Cron hourly | Yes | ≤1h |
| `outbox.dispatcher` | Constant (every 2s) | Yes | ≤2s |
| `outbox.retry` | Cron every 5 min | Yes | Backoff schedule |
| `trust.decay` | Cron daily 02:00 IST | Yes | Same day |
| `voucher.settle` | Cron daily | Yes (idempotent ledger) | Same day |
| `projection.rebuild` | Manual / migration | Yes | On-demand |

**Idempotency is non-negotiable.** Every job MUST be safe to run twice. We use idempotency keys stored in a Postgres `job_locks` table (or BullMQ's `jobId` deduplication for short windows).

### 9.2 Scheduler ownership

A single "scheduler worker" instance owns the cron schedule. It enqueues jobs to BullMQ; multiple "executor workers" pull from BullMQ. This separation prevents duplicate cron execution if we ever scale the API to >1 instance.

---

## 10. Deployment topology

### 10.1 MVP topology (Track A)

```
            Cloudflare (DNS, basic DDoS, TLS pass-through)
                              │
                              ▼
            Railway / Render (region: ap-south-1 / Mumbai)
            ┌─────────────────────────────────────────────┐
            │                                              │
            │   ┌────────────┐    ┌────────────────┐      │
            │   │ API (2x)   │    │ Worker (1x)    │      │
            │   │ NestJS     │    │ BullMQ runner  │      │
            │   └────────────┘    └────────────────┘      │
            │         │                  │                 │
            │         └──────┬───────────┘                 │
            │                ▼                             │
            │         ┌────────────┐  ┌────────────┐      │
            │         │ Postgres   │  │ Redis      │      │
            │         │ (managed)  │  │ (managed)  │      │
            │         └────────────┘  └────────────┘      │
            │                                              │
            └─────────────────────────────────────────────┘
                              │
                              ▼
                  Supabase Storage (IN region)
```

- **2 API instances** for redundancy. Both serve traffic. Stateless.
- **1 worker instance** for BullMQ. Adding instances is one config change when load demands.
- **Postgres:** Railway-managed or Supabase-managed; min instance with daily backup. Cost: ₹4k–₹6k/mo.
- **Redis:** Railway-managed; smallest instance is fine. ₹1k–₹2k/mo.
- **Region:** Mumbai (`ap-south-1`). Required for low latency and effectively required for DPDP.

### 10.2 Why not AWS / GCP in MVP?

- 2-developer team has no DevOps capacity. Railway/Render zero-config deploy saves 4–6 weeks across the year.
- Cost at our scale is comparable.
- Migration path to AWS/GCP exists (Track B); Postgres is portable, BullMQ is portable, containers are containers.

### 10.3 Environments

| Env | Purpose | Data |
|---|---|---|
| `local` | Dev laptops | Synthetic |
| `dev` | Always-on dev branch | Synthetic |
| `staging` | Pre-prod, mirror of prod | Production-like synthetic; never real PII |
| `prod` | Real users | Real |

Promotion: PR → `dev` auto-deploy → manual promote to `staging` → manual promote to `prod`.

### 10.4 CI/CD

- GitHub Actions: lint, typecheck, unit tests, integration tests on every PR.
- On `main` merge: build container, push to Railway registry, auto-deploy to `dev`.
- Promotion to `staging`/`prod` is a manual "Deploy" action with required approvals (founder + CTO).
- Database migrations: Prisma Migrate; migrations run pre-deploy in a pre-deploy hook. Failed migration aborts deploy.

---

## 11. Observability

### 11.1 Three pillars

| Pillar | Tool | What we track |
|---|---|---|
| **Logs** | Pino → Railway log drain → (optional) Logtail | Structured JSON, request_id-correlated. |
| **Metrics** | Railway native + custom Prometheus via OpenTelemetry (v1.5) | API latency p50/p95/p99, job queue depth, outbox lag. |
| **Traces** | OTEL → Sentry Performance | Slow endpoints, slow DB queries. |
| **Errors** | Sentry | All unhandled exceptions, with breadcrumbs. |
| **Product** | PostHog | Funnel: install → OTP → room joined → cycle completed. |

### 11.2 SLOs (initial)

| SLO | Target |
|---|---|
| API p95 latency | < 500ms |
| Auction close latency | < 5 min from `closes_at` |
| Outbox dispatch lag (p95) | < 10s |
| Push notification delivery (FCM → device) | < 30s |
| Successful login rate | > 98% |
| Uptime | 99.5% |

### 11.3 Alerts (PagerDuty equivalent — Slack channel in MVP)

- API error rate > 2% over 5 min → high
- Auction reaper finds >5 missed auctions in one run → critical
- Outbox lag > 60s → high
- Database CPU > 80% sustained 5 min → high
- Disk > 80% → high
- KYC partner success rate < 90% → medium (toggle to fallback adapter)
- Refresh token theft detected → high (ops investigates)

---

## 12. Anti-abuse architecture

(See §14 of PRD for policy. This section is the technical realization.)

### 12.1 Rate limits

Implemented in Redis with sliding window:

```
auth.otp.request    : 5/hr per phone,   20/hr per IP
auth.otp.verify     : 10/hr per phone
room.create         : 3/day per user
room.join           : 10/day per user
contribution.mark   : 100/day per user
auction.bid         : 1 per (auction, user)  -- bid is locked
```

### 12.2 Identity uniqueness

- One account per phone (enforced at OTP step).
- One PAN can be linked to only one account (enforced at verification step).
- Bank account ownership re-verified every 6 months.
- Device fingerprint logged; pattern detection (one device, many accounts) flagged for review.

### 12.3 Velocity rules (encoded as policies)

```
- new_account (< 30 days):       cannot create rooms
- new_account (< 15 days):       cannot join rooms > ₹10k
- bronze_user:                   max 1 active room
- silver_user:                   max 2 active rooms
- platinum/diamond:              standard room caps (PRD §10.2)
```

### 12.4 Fraud detection (v1: rule-based, Track B: ML)

Patterns flagged:

- Multiple accounts from same device fingerprint
- Same PAN attempted on >1 account
- Rooms where 3+ members share a device or IP at creation time
- Trust-score gaming: small rooms (5 members, ₹100/month) created and completed in <30 days repeatedly
- Member who has filed disputes in >25% of cycles
- Foreman whose rooms have default rate > 20%

These flags route to an "ops review" queue (in admin v1.5). For v1, an email to founder.

---

## 13. Track B: decomposition path

The monolith is built so that when we hit one of these triggers, extraction is incremental and safe:

**Triggers for service extraction:**
1. Onboarding latency dominated by KYC calls → extract `verification` first.
2. Notification volume > 1M/mo with backpressure issues → extract `notification`.
3. Auction concurrency > 100 simultaneous auctions → extract `auction`.
4. Need to move money (when Posture C kicks in) → extract `ledger` and add new `settlement` and `disbursement` services.
5. AI fraud detection in production → extract `risk` (new service consuming events).

**Target Track B topology:**

```
                          ┌─────────────────────┐
                          │   Mobile App         │
                          └──────────┬──────────┘
                                     │
                                     ▼
                          ┌─────────────────────┐
                          │   API Gateway        │
                          │   (auth, rate limit) │
                          └──┬───┬───┬──┬───┬───┘
                             │   │   │  │   │
                ┌────────────┘   │   │  │   └────────────┐
                ▼                ▼   ▼  ▼                ▼
        ┌────────────┐  ┌─────────┐ ┌─────────┐  ┌────────────┐
        │ iam-svc    │  │ room-svc│ │ auction-│  │ ledger-svc │
        │            │  │         │ │  svc    │  │ + settle   │
        └────────────┘  └─────────┘ └─────────┘  └────────────┘
                │            │           │              │
                └────────────┴────┬──────┴──────────────┘
                                  │
                                  ▼
                          ┌─────────────────┐
                          │  Event Bus       │
                          │  (Kafka / NATS)  │
                          └────────┬────────┘
                                   │
        ┌──────────────────────────┼───────────────────────────┐
        ▼                          ▼                           ▼
┌────────────┐              ┌──────────────┐          ┌──────────────┐
│ trust-svc  │              │ notif-svc    │          │ risk-svc     │
└────────────┘              └──────────────┘          │ (ML)         │
                                                       └──────────────┘
```

**Why this is achievable from the MVP:**
- Modules already communicate via the EventBus. Replacing the in-process bus with Kafka is a swap of one adapter.
- Modules already have their own Postgres schemas. Database-per-service is a `pg_dump`/`pg_restore` away.
- Outbox already isolates external side effects.

**What we have to NOT do in MVP to keep this path open:**
- ❌ Cross-module JOINs in SQL. (Caught by lint; rejected in code review.)
- ❌ Shared mutable state (e.g., Redis keys read/written by two modules).
- ❌ Inline external calls in request handlers. (Outbox catches this.)

---

## 14. Flutter app architecture (high-level)

Detailed in Phase 6, but architecture-level decisions made here for consistency:

```
lib/
├── app/                   # bootstrap, theming, routing
│   ├── router.dart        # GoRouter config
│   ├── theme.dart
│   └── bootstrap.dart
├── core/                  # framework-agnostic
│   ├── errors/
│   ├── network/           # Dio client, interceptors
│   ├── storage/           # secure storage abstraction
│   └── utils/
├── features/              # one folder per domain feature
│   ├── auth/
│   │   ├── data/          # repositories, DTOs, datasources
│   │   ├── domain/        # entities, use-cases
│   │   ├── presentation/  # screens, widgets, controllers (Riverpod)
│   │   └── auth.dart      # barrel export
│   ├── rooms/
│   ├── auctions/
│   ├── payments/
│   ├── trust/
│   ├── gems/
│   ├── profile/
│   └── notifications/
└── shared/                # cross-feature widgets, design tokens
```

**Conventions:**
- **Riverpod** with code-generated providers (`riverpod_generator`). No global state outside Riverpod.
- **GoRouter** with type-safe route definitions (`go_router_builder`).
- **Dio** for HTTP, with interceptors for auth, retry, error mapping.
- **flutter_secure_storage** for refresh token. Access token in memory only.
- **Localization:** `flutter_localizations` + ARB files, Tamil + English at launch.
- **Theming:** Material 3, single `ThemeData` source. Dark theme deferred to v1.1.
- **No code generation in CI; only locally with committed outputs** (controversial but saves CI time).

---

## 15. Architecture Decision Records — top 10

These are the decisions that are hardest to reverse. Each will be backed by a one-page ADR in `/docs/adr/`.

| # | Decision | Status | Reversibility |
|---|---|---|---|
| ADR-001 | Modular monolith for MVP, extract to services in Track B | Accepted | Easy to extract; hard to merge back |
| ADR-002 | PostgreSQL as single source of truth | Accepted | Hard |
| ADR-003 | Event-sourcing limited to ledger + trust + audit | Accepted | Medium |
| ADR-004 | Outbox pattern for all external side effects | Accepted | Medium |
| ADR-005 | Refresh tokens with rotation + device binding | Accepted | Easy |
| ADR-006 | BullMQ on Redis for background jobs | Accepted | Easy |
| ADR-007 | Railway/Render hosting for MVP | Accepted | Easy |
| ADR-008 | NO money movement in v1 (consequence of OQ-3) | Accepted | **Hard** — adds 10 weeks if reversed |
| ADR-009 | Vouchers via aggregator, no own warehouse | Accepted | Easy |
| ADR-010 | Mumbai region (data residency) | Accepted | Hard |

---

## 16. Risks introduced by this architecture

| # | Risk | Mitigation |
|---|---|---|
| AR-1 | Single Postgres = single point of failure | Managed Postgres with HA + daily backup. RPO 24h, RTO 1h (acceptable for MVP). |
| AR-2 | Outbox lag invisible to users → confusion ("did my contribution register?") | Optimistic UI on client; outbox lag SLO + alert. |
| AR-3 | Event versioning over time (events change schema) | `event_version` column from day 1; projectors handle all known versions. |
| AR-4 | Vendor lock (Karza, Qwikcilver) | Adapter pattern; second adapter for KYC fallback added in month 4. |
| AR-5 | BullMQ scheduler outage → missed auctions | Reaper job (§9.1). |
| AR-6 | Refresh token leak | Family revocation + device binding. |
| AR-7 | Module boundary erosion under deadline pressure | Lint rules; PR review gate; monthly module-boundary audit. |
| AR-8 | Track B extraction painful because something in MVP cheats the boundaries | Quarterly "extraction dry-run" — pick one module, extract it locally, confirm it still works. |

---

## 17. Phase 3 handoff — what the DB design must deliver

Phase 3 (Database Design) is the next deliverable. It must include:

1. **Full Prisma schema** for all 11 modules, partitioned by Postgres schema.
2. **Index plan** with rationale per index.
3. **Migration plan** — order of creation, rollback strategy.
4. **Seed data** for local dev (synthetic users, rooms, auctions in various states).
5. **Idempotency-key strategy** per write endpoint.
6. **Data retention policy** per table (especially audit, ledger).
7. **PII inventory** with classification (sensitive / personal / public) and storage location.
8. **ER diagram** (Mermaid + a generated dbdiagram.io export).
9. **Query catalogue** — the ~30 most-frequent queries, with `EXPLAIN ANALYZE` plans, to validate indexes upfront.

---

## End of Phase 2

**Next phase:** Phase 3 — Database Design. Output is a runnable Prisma schema + ER diagram + migration plan + index plan.

**Status:** Awaiting founder review. Approve to proceed, or flag changes — especially any of the three high-impact assumptions in §0 (OQ-1 legal posture, OQ-3 money movement, OQ-9 second dev).
