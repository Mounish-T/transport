# SEATU — State Management Deep-Dive (Phase 7)

**Phase 7 Deliverable · v0.2.0**
**Owner:** CTO
**Status:** Awaiting founder review before Phase 8 (Testing)
**Date:** June 2026
**Companion:** `seatu-app/` (updated in place from Phase 6)

---

## 0. What this document covers

Phase 7 is a focused state-management pass on the existing Flutter app. We
add resilience patterns — caching, lifecycle awareness, optimistic UI,
offline indicator — without adding new screens or features.

1. Scope and what's NOT in scope (§1)
2. The four patterns delivered (§2)
3. The cache layer (§3)
4. The optimistic UI pattern (§4)
5. Lifecycle-aware refresh (§5)
6. Connectivity awareness (§6)
7. WebSocket / live updates — why we're deferring (§7)
8. What changed in the existing code (§8)
9. What's deliberately deferred (§9)
10. Phase 8 handoff (§10)

---

## 1. Scope

**In scope:**
- Cache-then-network reads (rooms list)
- Optimistic UI on room lifecycle transitions (publish/start/cancel)
- App-foreground-resume refresh
- Offline indicator banner
- Cache invalidation on sign-out

**NOT in scope:**
- Cached writes (offline mutations queued for later sync) — Phase 8/9 if needed
- WebSocket / SSE for live data — deferred (§7)
- Cached /me bundle as a separate refactor — already cached in Phase 6 via
  `AuthSnapshot.me`; Phase 7 doesn't touch it
- Bid placement / contribution mark-paid optimistic flows — those endpoints
  aren't built yet; once Phase 6.1 ships them, the pattern in §4 applies
  directly

This phase is small on purpose — a ~3-day spike's worth of work, not a
two-week rewrite.

---

## 2. The four patterns delivered

### 2.1 Cache-then-network reads (stale-while-revalidate)

Show whatever's in the cache instantly. Fire the network call in the
background. When fresh data arrives, swap it in. If the network call fails
and we had cache, keep showing cache silently — the user shouldn't lose
their view because one fetch failed.

See `RoomsList` in `features/rooms/application/rooms_controller.dart`.

### 2.2 Optimistic UI for state transitions

User taps "Publish" on a draft room. The UI flips the status to
"recruiting" instantly (zero perceived latency), fires the network call,
and on failure rolls back to the previous state with a toast explaining
why. The detail view is invalidated either way so the user sees server
truth when they navigate to it.

See `RoomActions._optimistic` in the same file.

### 2.3 Lifecycle-aware background refresh

When the app comes back to the foreground (user switches from WhatsApp
back to SEATU), rooms list invalidates and refetches. No pull-to-refresh
needed for "freshness on return".

See `appLifecycleProvider` in `core/lifecycle/app_lifecycle.dart`.

### 2.4 Offline indicator

A subtle banner slides down from the top of the screen when connectivity
drops, and slides back up when it returns. We don't block UI — read-only
flows keep working from cache; writes will fail and surface their own
error.

See `OfflineBanner` in `core/widgets/offline_banner.dart`.

---

## 3. The cache layer

`core/cache/cache_box.dart` is a thin facade over `shared_preferences`.
Reasoning:

- **Data volumes are small** (a rooms list + /me bundle is well under
  10 KB).
- **`shared_preferences` is already in the project** (used by
  `LocaleController`), so no new dependency.
- **The cache API doesn't leak the backing store.** When we outgrow it,
  swap the impl for hive_ce or sqflite without touching call sites.

### 3.1 CacheEntry

Each value is wrapped in a `CacheEntry` with `value`, `writtenAt`, and
`ttl`. Two states:

- **Fresh:** `now - writtenAt < ttl`. Use directly.
- **Stale-but-usable:** `ttl < now - writtenAt < 24*ttl`. Use as fallback
  while fetching fresh.
- **Hard-expired:** beyond `24*ttl`. Treated as if missing and dropped on
  next read.

Default TTL is 5 minutes — rooms list won't change minute-to-minute under
normal use, but a foreman who just published a room expects to see it
reflected.

### 3.2 Why no automatic refresh interval

We don't poll. A foreground transition + manual pull-to-refresh + cache
TTL together cover the realistic refresh cases. Polling drains battery
and the use case doesn't justify it.

---

## 4. The optimistic UI pattern

```
User taps "Publish"
  │
  ▼
Snapshot current list state    ─────┐
  │                                  │ keep for rollback
Flip status to 'recruiting'           │
locally (UI updates instantly)        │
  │                                   │
  ▼                                   │
Fire POST /v1/rooms/:id/publish       │
  │                                   │
  ├── 200 OK ──┐                      │
  │           │                       │
  │           ▼                       │
  │     Invalidate list + detail      │
  │     (re-fetch server truth)       │
  │                                   │
  └── error ──┐                       │
              │                       │
              ▼                       │
       Restore snapshot ◄─────────────┘
       Show error toast
```

### 4.1 When to apply this pattern

Apply when ALL of these are true:

1. The outcome is binary (succeeds → known state, fails → known state).
2. The user's confidence in the system is built on perceived speed.
3. Rollback is acceptable (the user will see a brief "wait it didn't
   work" if the network blips).

Examples in SEATU:
- ✅ Room publish/start/cancel (delivered)
- ✅ Bid placement (Phase 6.1)
- ✅ Mark contribution paid (Phase 6.1) — fits the pattern
- ❌ Room creation — no prior state to optimistically display
- ❌ KYC submission — too consequential; users want explicit feedback
- ❌ Voucher redemption — burns balance; we need to wait for confirmation

### 4.2 Why we don't have a generic "optimistic mutation" utility

Each mutation has its own snapshot/apply/rollback semantics. A generic
wrapper would either be too rigid (one-size-fits-all rollback) or too
abstract (every caller passing closures for snapshot, apply, rollback —
at which point it's just inline code). The `_optimistic` helper in
`RoomActions` is the right size for room lifecycle transitions; auctions
and contributions will write their own.

---

## 5. Lifecycle-aware refresh

`AppLifecycle` is a single Riverpod provider that wraps
`WidgetsBindingObserver`. Other providers `ref.listen` to it:

```dart
ref.listen(appLifecycleProvider, (prev, next) {
  if (next == AppLifecyclePhase.resumed &&
      prev != AppLifecyclePhase.resumed) {
    ref.invalidateSelf();
  }
});
```

The `prev != resumed` guard avoids re-firing on the initial "resumed"
state when the screen first builds — we only want to refresh on actual
transitions.

### 5.1 Why not refresh everything on resume

Right now only `RoomsList` does this. Reasonable additions:
- Room detail (when the user opens a backgrounded app on a room screen)
- Notifications (Phase 6.1)
- /me bundle (cheap; once an hour is enough)

We don't refresh ALL providers on resume because:
- Some are expensive (auction history could be large)
- Most are auto-disposed when the user navigates away, so they refetch
  anyway on the next navigation
- Refreshing everything blocks UI when the user just wants to look at
  what they had open

### 5.2 Why we don't refresh on visibility change of individual screens

Tempting but expensive — visibility changes fire often (tab switches,
modal sheets, keyboard show/hide). Foreground/background is a coarser
signal and matches the user's mental model: "I came back to this app, so
get me fresh data."

---

## 6. Connectivity awareness

`connectivity_plus` plugin → `ConnectivityState` Riverpod provider →
`OfflineBanner` widget.

### 6.1 What we use it for

- **The offline banner.** That's it.
- We do NOT use it to short-circuit network requests. A request might
  succeed even when the plugin reports offline (some carriers' VPN
  configurations, captive portals, etc.). Let Dio try, let the
  `ErrorInterceptor` translate the failure into `LOCAL_NO_NETWORK`, and
  let the UI show what's appropriate.

### 6.2 What we explicitly don't do

- **Captive portal detection** — too much complexity for v1. If a user is
  on hotel wifi without auth, they'll see API failures with a generic
  network error; the offline banner won't fire because the system thinks
  it has wifi.
- **Predictive fetching when reconnecting** — when connectivity returns,
  we could auto-refetch everything stale. We don't, because the
  lifecycle-on-resume already covers most of this and it's hard to predict
  what a user actually wants to refresh first.

---

## 7. WebSocket / live updates — deferring

The Phase 6 handoff flagged this as Phase 7 work. I'm pushing back: **we
don't need it yet** for these reasons:

### 7.1 Sealed-bid auctions don't need real-time

Per Phase 4 §13.7, bids are sealed — no bidder can see other bids until
the auction closes. The only "live" information is the countdown timer,
and even that doesn't need server pushes: it counts down to a
known `closes_at` timestamp. The client renders `Dates.relativeShort()`
from the cached timestamp, and the timer is wall-clock-driven, not
server-driven.

### 7.2 What WOULD need real-time

- **Open-bid auctions** if/when we ever ship them. Each bid would need to
  notify other bidders of the new low.
- **Live chat in rooms** (not in v1 roadmap).
- **Notifications inbox** updating in real-time without a fetch.

For these we'd use Server-Sent Events (SSE) over a WebSocket because:
- One-way (server → client) suffices for notifications
- Works through more proxies than WebSocket
- Auto-reconnects in the SSE spec
- Backend wires it as another fan-out from the existing EventBus

When the time comes, the implementation sketch:

```
backend:
  POST /v1/notifications/stream     SSE endpoint, JWT-auth
  EventBus → SSE writer per connected user

flutter:
  package:eventsource_plus
  StreamProvider wraps the SSE connection
  Reconnect on network restoration via ref.listen on connectivityStateProvider
```

Estimated: 3 dev-days. Not in scope for v1.

### 7.3 Pushback opportunity

If you want WebSocket-class freshness for some specific screen
(auction inbox, dispute responses?), tell me which one and I'll prioritize
it. Otherwise the static countdown + foreground-refresh combo is what we
ship.

---

## 8. What changed in the existing code

### 8.1 New files

```
lib/core/
├── cache/
│   ├── cache_box.dart                  CacheBox provider + impl
│   └── cache_entry.dart                CacheEntry<T> with TTL
├── connectivity/
│   └── connectivity_provider.dart      Reactive online/offline state
├── lifecycle/
│   └── app_lifecycle.dart              AppLifecycle observer as a provider
└── widgets/
    └── offline_banner.dart             Slide-down banner widget
```

### 8.2 Changed files

- `lib/app/app.dart` — wraps router with `OfflineBanner`; eagerly subscribes
  to `appLifecycleProvider` and `connectivityStateProvider` so observers
  register at app boot, not lazily.
- `lib/features/rooms/application/rooms_controller.dart` — full rewrite to
  add stale-while-revalidate + optimistic transitions.
- `lib/features/auth/application/auth_controller.dart` — sign-out flushes
  the cache box so the next user doesn't see stale data.
- `pubspec.yaml` — adds `connectivity_plus: ^6.0.3`.

### 8.3 Unchanged on purpose

- The Dio client and interceptors. The cache layer sits ABOVE the API
  layer, not inside it. This means the cache is opt-in per provider, not
  applied universally — which is what we want because not every request
  should be cached (e.g., OTP request mutations).
- The error envelope and error codes. Cache misses surface as their own
  user-visible state, not as fake "INTERNAL_ERROR" responses.
- Existing screens. The optimistic flip is invisible to the screen code —
  it just reads `roomsListProvider` like before; the controller does the
  state magic.

---

## 9. What's deliberately deferred

| What | Why | When |
|---|---|---|
| Cached /me bundle (disk) | Already cached in-memory via `AuthSnapshot.me` in Phase 6; disk caching for fast cold-start is nice but not critical | Phase 8 (Testing) — let user-testing tell us if cold-start needs the extra step |
| Offline-queued writes | Foreman scenarios (mark-paid, publish) need server confirmation for trust reasons; users will expect immediate sync feedback, not "we'll do it later" | Probably never — explicitly out of scope per PRD |
| Background sync via WorkManager | Same as above | Same |
| WebSocket / SSE | Sealed-bid auctions don't need it | Add when/if open-bid auctions ship (§7) |
| Optimistic create | No prior state to fall back to; the user just submitted a form | N/A — wait pattern is correct |
| Cache compression / encryption | Cached data is non-sensitive (room metadata, /me bundle). Tokens live in `flutter_secure_storage`, not the cache box | N/A |
| Migration framework for cache schema | When `Room.fromJson` changes incompatibly, cached entries will throw at decode; the `read` method already catches and prunes them. This is a self-healing approach that suffices for v1 | Add a versioned cache schema if we ever need a controlled migration |

---

## 10. Phase 8 handoff

Phase 8 is the testing phase:

1. **Widget tests** for the auth flow and rooms list/create. Use
   `ProviderScope(overrides: [...])` to swap real Dio with a fake.
2. **Golden tests** for the rooms list card and the tier badge — they're
   the most "visually salient" pieces.
3. **Integration test** of the cache layer with a real
   `SharedPreferences.setMockInitialValues({})`.
4. **Integration test** of the full onboarding flow against a running
   backend (decide later: in CI or only locally).
5. **A test that the optimistic publish rolls back on simulated failure.**
   This is the trickiest one to write and the most valuable — get this
   right and we have confidence the pattern works.

Phase 8 is bigger (~1 week of test writing). Phase 9 is deployment.

---

## End of Phase 7

**Status:** Awaiting founder review. Approve to proceed to Phase 8
(Testing), or flag changes — especially around the WebSocket deferral
(§7), or if you want offline writes added back into scope (which I'd push
back on hard).
