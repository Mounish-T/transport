# SEATU — Flutter App (Phase 6)

**Phase 6 Deliverable · v0.1 (Draft)**
**Owner:** CTO
**Status:** Awaiting founder review before Phase 7 (State Management deep-dive)
**Date:** June 2026
**Companion:** `seatu-app/` (runnable Flutter project)

---

## 0. What this document covers

The repo (`seatu-app/`) is the artifact. This explains what you can't see in
the file structure: why the layering looks like that, how the auth flow holds
together end-to-end, what's deliberately stubbed.

1. Assumptions (§1)
2. What's delivered (§2)
3. Architecture (§3)
4. Recipe: adding a feature (§4)
5. The auth-aware router (§5)
6. The API client + auto-refresh (§6)
7. Riverpod conventions (§7)
8. i18n model (§8)
9. Theming (§9)
10. Testing (§10)
11. Local dev (§11)
12. Production build & release (§12)
13. What's deliberately stubbed (§13)
14. Phase 7 handoff (§14)

---

## 1. Assumptions

Carried forward from Phases 1–5. The two that shape this layer:

- **One mobile client; no web in v1** (PRD §3). Flutter, not React Native or
  native Android/iOS, because (a) we don't have iOS+Android specialists,
  (b) we want one codebase for both stores, (c) the Material 3 + Cupertino
  story is finally good.
- **Backend is source of truth.** No offline-first ambitions in v1. We
  cache the last /me bundle so cold-start feels instant, but every action
  hits the server.

---

## 2. What's delivered

### 2.1 Real, working features

- **Auth flow end-to-end** (`features/auth/`): welcome screen → phone input
  (E.164 normalised, +91 only for v1) → OTP verify (autofill-friendly,
  resend cooldown, code-specific error messages).
- **Rooms feature** (`features/rooms/`): list (pull-to-refresh, empty state),
  detail (foreman actions per state machine), create (form with Indian
  number formatting, live pool preview, tier-aware error surfaces).
- **Profile tab** (`features/profile/`): /me bundle display, tier badge,
  verification status, language switcher, sign out.
- **Home tab scaffold** (`features/home/`) with bottom nav.

### 2.2 Core infrastructure (the bits that make Phase 6.1 mechanical)

- **API client** with three Dio interceptors (auth headers, refresh-on-401,
  error normalisation) → §6.
- **Token storage** in `flutter_secure_storage` (Android: encrypted shared
  prefs; iOS: keychain with first-unlock-this-device).
- **Stable device identity**: per-install UUID v4 + random fingerprint,
  generated once and reused forever. Sent as `X-Device-Id` and as a JWT
  device-binding claim.
- **Error envelope mapper**: every backend error becomes a typed
  `ApiException` with `code`/`userMessage`/`requestId`. Screens switch on
  `code`, never on HTTP status.
- **Auth-aware GoRouter** that redirects unauthenticated users away from
  protected paths and vice versa — driven by a single boolean derived from
  `authStateProvider`.
- **i18n**: hand-rolled English + Tamil dictionary (`S.of(context).*`).
  Sufficient for v1; convert to `.arb` codegen once we have translators.
- **Material 3 theme** with brand-seed colour, Noto Sans (Latin + Tamil
  glyphs in one ramp), opinionated input/button styling.
- **Indian-numbering money formatter** (lakh/crore comma placement).
- **Reusable widgets**: tier badge, loading, error display.

### 2.3 Stubs (one-file placeholders)

- `features/trust/`, `features/gems/`, `features/auctions/`,
  `features/notifications/` — each has a stub screen explaining what
  Phase 6.1 will build there.

### 2.4 Tests

- `test/welcome_screen_test.dart` — widget test for the welcome screen
  (English + Tamil).
- `test/formatters_test.dart` — Money.paiseToInr (Indian comma placement),
  Validators.indianPhone, PhoneFormat.pretty. Pure-logic unit tests.

---

## 3. Architecture

Clean architecture, lightly applied. Each feature folder has four layers:

```
features/<name>/
├── data/                Dio-backed API client (talks to backend)
├── domain/              Pure Dart models (freezed) + repository interfaces
├── application/         Riverpod controllers (orchestrate flows)
└── presentation/        Widgets, screens
```

**Imports cross layers down, never up.** Presentation can import from
application, domain, data. Application can import from data, domain. Data
imports only domain. Domain imports nothing from this project.

Why this matters: a screen test only needs to mock the application layer; an
API change only ripples through `data/` if the mapper handles it.

### 3.1 What's NOT enforced

- **No `repository` abstraction layer in this delivery.** For v1 the
  `data/<name>_api.dart` is the repository — there's no second
  implementation. When we add caching, we'll introduce an interface in
  `domain/` and move the Dio call behind it. Adding the indirection
  prematurely is over-engineering.

- **No reusable BLoC-style "use case" classes.** Riverpod controllers are
  small enough that splitting business logic into separate use-case classes
  adds noise. We'll revisit if any controller exceeds ~200 lines.

---

## 4. Recipe: adding a feature

Reference: `features/rooms/`.

### Step 1 — domain model

In `domain/<entity>.dart`, define a freezed class matching the backend's
API shape. Use `@JsonKey(name: 'snake_case')` to rename camelCase fields:

```dart
@freezed
class Auction with _$Auction {
  const factory Auction({
    required String id,
    required String status,
    @JsonKey(name: 'pool_amount_paise') required int poolAmountPaise,
    @JsonKey(name: 'closes_at') required DateTime closesAt,
  }) = _Auction;
  factory Auction.fromJson(Map<String, dynamic> j) => _$AuctionFromJson(j);
}
```

Run `dart run build_runner build --delete-conflicting-outputs`. This generates
`*.freezed.dart` and `*.g.dart`.

### Step 2 — API client

In `data/<name>_api.dart`, wrap the relevant endpoints:

```dart
@riverpod
AuctionsApi auctionsApi(AuctionsApiRef ref) => AuctionsApi(ref);

class AuctionsApi {
  AuctionsApi(this._ref);
  final Ref _ref;
  Dio get _dio => _ref.read(dioClientProvider);

  Future<Auction> get(String id) async {
    final res = await _dio.get<Map<String, dynamic>>('/v1/auctions/$id');
    return Auction.fromJson(res.data!);
  }
}
```

You don't write any auth/idempotency/refresh code — interceptors handle it.

### Step 3 — application controller

In `application/<name>_controller.dart`:

```dart
@riverpod
Future<Auction> auctionDetail(AuctionDetailRef ref, String id) async {
  return ref.read(auctionsApiProvider).get(id);
}
```

For imperative actions (place bid, etc.), use a `@riverpod class` Notifier
that exposes `Future<bool>` methods and an `AsyncValue<void>` state for
loading/error.

### Step 4 — screen

In `presentation/<screen>_screen.dart`, watch the provider with `.when()`:

```dart
class AuctionScreen extends ConsumerWidget {
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncAuction = ref.watch(auctionDetailProvider(id));
    return asyncAuction.when(
      loading: () => const SeatuLoading(),
      error: (e, _) => SeatuError(error: e),
      data: (auction) => _AuctionBody(auction: auction),
    );
  }
}
```

For error UX that differs by error code, use a `ref.listen` block (see
`room_create_screen.dart` for the pattern — it specifically translates
`ROOM_CAP_EXCEEDED`, `PERM_VERIFICATION_REQUIRED`, `PERM_VELOCITY_LIMIT`
into user-friendly messages with CTAs).

### Step 5 — route

Add a route in `app/router.dart`. If it's protected (most are), the existing
redirect logic covers it — no extra work.

### Step 6 — codegen + run

```bash
dart run build_runner build --delete-conflicting-outputs
flutter run
```

---

## 5. The auth-aware router

`app/router.dart` is small but high-leverage. Two redirect rules:

1. Not signed in + trying to access an authed path → `/welcome`.
2. Signed in + on an auth path → `/`.

The router rebuilds when `authStateProvider.select((s) => s.isSignedIn)`
changes — and only when. We don't watch the full snapshot because the /me
field changes on every refetch and we don't want to rebuild the router on
that.

**The router does NOT call /me eagerly.** The home screen does, lazily, on
first tab build. This keeps cold-start fast and avoids a network round-trip
before showing anything.

---

## 6. The API client + auto-refresh

`core/api/api_client.dart` builds a single Dio instance with three
interceptors, in order:

### 6.1 `AuthInterceptor` (outbound)

Attaches `Authorization: Bearer <jwt>`, `X-Device-Id`, `X-App-Version`, and
on POST/PATCH/DELETE an `Idempotency-Key` (`ts-<ms>-<base36>`). The
backend rejects mutating calls without the key (per Phase 4 §6.5).

### 6.2 `RefreshInterceptor` (inbound, on 401)

Three behaviours depending on the error code in the response body:

- `AUTH_TOKEN_EXPIRED` → call /refresh, save new tokens, retry the original
  request once.
- `AUTH_TOKEN_REUSE_DETECTED` / `AUTH_TOKEN_REVOKED` / `AUTH_DEVICE_MISMATCH`
  → wipe local state; router redirects to welcome.
- Anything else → pass through.

**Concurrency:** if multiple requests fail with `AUTH_TOKEN_EXPIRED` at the
same time (e.g., after a long sleep), only one refresh runs; the others
await it. Avoids a thundering-herd refresh that would trip rate limits.

### 6.3 `ErrorInterceptor` (inbound, last)

Translates network errors and 4xx/5xx envelopes into typed `ApiException`s.
Every downstream layer (controllers, screens) catches `ApiException` and
switches on `code`, never on HTTP status. This is what makes the error UX
consistent across the app.

---

## 7. Riverpod conventions

- **Always code-gen.** Hand-rolling provider variables (`final fooProvider
  = Provider(...)`) is allowed but discouraged. `@riverpod` annotation
  gives compile-time-checked provider names + family handling for free.
- **AsyncValue, not custom state.** Loading/error/data is built in; don't
  rebuild it.
- **`keepAlive: true`** only for app-wide singletons (token storage, dio,
  auth state, locale, device identity). Everything else is auto-dispose,
  which is the safe default — avoids stale state when the user navigates
  away and back.
- **Read for actions, watch for reactivity.** `ref.watch` rebuilds the
  consumer when the source changes; `ref.read` fires once. In a callback
  (`onPressed: () { ref.read(...) }`) you always want read.
- **Invalidate to refetch.** Don't manually mutate a Future provider's
  result. `ref.invalidate(roomsListProvider)` after creating a room is the
  idiomatic refresh.

---

## 8. i18n model

For v1 we use a hand-rolled `S.of(context)` class with English + Tamil
strings in code (`lib/core/i18n/strings.dart`). One file, two locales, no
build step.

This is intentional. The flutter_localizations + `.arb` workflow is more
official but assumes a translator handoff — which we don't have yet. When
we do (probably Phase 6.1 once we have the Tamil copywriter contracted),
swap to gen_l10n in a single PR.

The framework localisation (`GlobalMaterialLocalizations`, date pickers, etc.)
is wired correctly so Material widgets are localised even though our app
strings are hand-rolled.

---

## 9. Theming

Seed colour is `#0F766E` (deep teal). Material 3 generates the full
palette. Dark mode is supported but follows system; not yet a manual toggle.

**Typography:** Noto Sans throughout. It's the only widely-available
typeface that gives Latin + Tamil + Devanagari in a consistent metric ramp.
The "Tamil text looks weirdly bigger than English" problem we'd otherwise
have to fight is gone.

**Buttons** are 52px tall and rounded 12px. Tap targets matter for our
audience (older users in textile and small-merchant communities); Material
3 default (40px tall) is too small.

**Inputs** are filled (not outlined) by default. Filled inputs cue
"this is a field" better at a glance and look modern; we override
Material 3's underline-only default.

### Things to push back on

1. **Deep teal.** Some founders want the Tamil-saffron palette (the
   marigold and turmeric tones). I argued no in Phase 1 — it can read as
   politically aligned and adds friction we don't need. Brand can revisit
   once we have user feedback.

2. **One typeface, not two.** Some apps use a serif for headers + sans for
   body. With Tamil we'd need a Tamil serif (Mukta Malar) and the mixing
   gets uneven. One ramp = one fewer thing to maintain.

---

## 10. Testing

Three layers:

- **Unit tests** (pure logic): formatters, validators, error mapping.
  `flutter test test/`. Fast (<1s).
- **Widget tests**: render screens with stub data, assert visible elements.
  We have one for welcome.
- **Integration tests**: full app on an emulator, hitting the real backend
  (deferred to Phase 8).

The pattern for testing screens that depend on Riverpod providers: use
`ProviderScope(overrides: [...])` to swap real providers with mock ones.
See the test file for the welcome screen.

---

## 11. Local dev

```bash
flutter pub get
dart run build_runner build --delete-conflicting-outputs
# Make sure backend is running: cd ../seatu-backend && pnpm start:dev
flutter run --dart-define=SEATU_API_BASE=http://10.0.2.2:3000   # Android emulator
flutter run --dart-define=SEATU_API_BASE=http://localhost:3000  # iOS simulator
```

**Test phone in dev:** any +91 number you like. **OTP**: `123456` (the
backend's `DEV_OTP_BYPASS`).

For codegen in watch mode while developing:
```bash
dart run build_runner watch --delete-conflicting-outputs
```

---

## 12. Production build & release

### Android

```bash
flutter build apk --release \
  --dart-define=SEATU_API_BASE=https://api.seatu.in
```

For Play Store: `flutter build appbundle --release`.

Signing config (`android/app/build.gradle`) and the upload keystore are
NOT in this delivery. Generate the keystore with `keytool` and add the
`key.properties` referencing it. Per Phase 2 §10.5, the keystore lives
in 1Password and is never committed.

### iOS

```bash
flutter build ios --release \
  --dart-define=SEATU_API_BASE=https://api.seatu.in
```

App Store Connect / Provisioning profile setup is a separate Phase 9 task.

### Per-env builds

Use `.dart-define-from-file=env/staging.json` (etc.) for non-trivial config
sets. The base URL is the only env-specific knob right now; that lives in
`String.fromEnvironment` in `api_client.dart`.

---

## 13. What's deliberately stubbed

| What | Where | Reason | Phase to address |
|---|---|---|---|
| Trust tab | `features/trust/` | Backend endpoints not in MVP scope | 6.1 |
| Gems tab | `features/gems/` | Same | 6.1 |
| Auctions screen | `features/auctions/` | Sealed-bid UX needs design pass | 6.1 |
| Notifications inbox | `features/notifications/` | Push UX comes after FCM wiring in backend Phase 5.1 | 6.1 |
| KYC flow | n/a | PAN/bank verification screens — need partner UX + screenshot upload flow | 6.1 |
| Invite + join-by-code | `features/rooms/` | Endpoints exist (Phase 4 §13.6) but UI is a 2-day task | 6.1 |
| Contribution mark-paid / confirm | `features/rooms/` | Needs upload-screenshot flow + signed URL handling | 6.1 |
| Dispute file/respond | n/a | Multi-screen flow | 6.1 |
| Push notification handling | `firebase_messaging` not wired | FCM setup is part of Phase 6.1 with the real adapter | 6.1 |
| Real platform detection | Hardcoded `device_platform: 'android'` in `auth_api.dart` | Need `platform.dart` import | trivial fix |
| `package_info_plus` | Hardcoded `X-App-Version: 0.1.0` in `auth_interceptor.dart` | Add the package | trivial fix |
| App icon + launch screen | `assets/` empty | Brand pass | pre-release |
| Crashlytics / Sentry | Not wired | Phase 9 | 9 |
| Analytics (PostHog) | Not wired | Phase 9 | 9 |
| Deep links | Not configured | Need Universal Links / App Links + the join-by-code wiring | 6.1 |

---

## 14. Phase 7 handoff

Phase 7 (State Management deep-dive) covers:

1. **Offline tolerance for reads.** Cache the rooms list + me bundle so
   the app shows useful state when the user is on a flaky connection.
   `flutter_riverpod` + a hand-rolled disk cache (or `hive` if we want
   ttl management). 2-day spike.
2. **Optimistic UI for one or two surfaces.** Bid placement is the
   obvious one — feels worse with a network round-trip. Mark-paid is
   another candidate.
3. **Background refresh on app foreground.** Rooms list and notifications.
4. **A WebSocket or SSE channel** for live auction countdowns (deferred
   from Phase 5 because sealed-bid doesn't strictly need it; user testing
   in Coimbatore will tell us if the static "closes in 2h 30m" countdown
   is enough).

Phase 7 is small (~1 week). Phase 8 (Testing) is bigger.

---

## End of Phase 6

**Status:** Awaiting founder review. Approve to proceed to Phase 7 (State
Management), or flag changes — especially around the auth-flow UX, the
i18n strategy (§8), or the theme decisions (§9).
