# SEATU — Database Design

**Phase 3 Deliverable · v0.1 (Draft)**
**Owner:** CTO
**Status:** Awaiting founder review before Phase 4 (API Design)
**Date:** June 2026
**Companion file:** `schema.prisma` (runnable, in this same delivery)

---

## 0. What this document covers

1. Module → schema map and the cross-schema FK rule (§1, §2)
2. Money/time/PII conventions used throughout the schema (§3, §4, §5)
3. ER diagram (§6)
4. Per-module schema notes (§7)
5. Index plan with rationale (§8)
6. Idempotency-key catalogue per write endpoint (§9)
7. Migration plan and rollback strategy (§10)
8. Data retention policy (§11)
9. Query catalogue — 30 hot-path queries with expected access patterns (§12)
10. Seed data plan (§13)
11. Track B: partitioning and growth (§14)
12. Phase 4 handoff (§15)

The actual schema lives in the **companion `schema.prisma`**. This document explains the *why* behind every choice in that file.

---

## 1. Assumptions (carry-forward from Phase 2)

Unchanged from Phase 2 §0. The high-impact assumptions baked into this schema:

- **No money movement in MVP (OQ-3).** There is no `escrow_account` table, no `settlement` table, no payment-aggregator-callback table. Adding these later requires a new `settlement` module, not a retrofit into `ledger`.
- **Modular monolith with strict per-module schemas (OQ-1 posture A).** Cross-schema foreign keys are deliberately absent. See §2.
- **Tamil Nadu launch, INR only.** No multi-currency. No FX columns.
- **Track A: 2 devs, ₹1.5L/mo run rate.** Single Postgres instance, no read replicas in MVP.

If any of those changes, **stop and tell me before approving** — particularly the no-money one, which adds an entire `settlement` schema with reconciliation tables.

---

## 2. Module → schema map

| Module | Postgres schema | Tables |
|---|---|---|
| iam | `iam` | users, devices, sessions, refresh_tokens, otp_attempts, user_roles |
| verification | `verification` | verification_attempts, verification_results |
| room | `room` | rooms, room_members, invitations |
| auction | `auction` | auctions, bids |
| ledger | `ledger` | ledger_events, contribution_status, payout_status |
| trust | `trust` | trust_events, trust_score_current, trust_tier_history |
| gems | `gems` | gem_events, gem_balances, redemptions |
| dispute | `dispute` | disputes, dispute_evidence |
| notification | `notification` | outbox_events, notification_log, notification_preferences |
| audit | `audit` | audit_log |
| admin | `admin` | admin_users, admin_actions |
| shared | `shared` | job_locks |

### 2.1 The cross-schema FK rule — non-negotiable

**Within a module:** real `@relation` definitions, `ON DELETE CASCADE` where appropriate. Postgres enforces.

**Across modules:** plain `Uuid` columns referencing other modules' primary keys *by convention*. **No `@relation`. No `REFERENCES` constraint.** Integrity is enforced at the service layer.

Example: `room.rooms.foreman_user_id` is a `Uuid`. The fact that it points to `iam.users.id` is documented in a code comment and enforced in code; the database does not know about it.

Why this rule exists (worth re-stating because the first dev who sees this will want to "fix" it):

1. **Track B extraction.** When we split `iam` into its own service with its own database, no FK has to be dropped. The columns already speak a network-friendly language.
2. **Event-bus mental model.** Modules communicate via events, not joins. Cross-schema FKs invite cross-module joins, which invite tight coupling.
3. **Multi-region future.** If we ever shard a service to a separate region, FKs across DBs are impossible. We build the discipline early.

**Failure mode this introduces:** orphaned UUIDs (e.g., a deleted user with rooms still pointing at them). We accept that. Hard-deleting users is anyway rare and goes through an admin workflow that cleans dependents explicitly (see §11).

---

## 3. Money conventions

| Rule | Detail |
|---|---|
| Storage type | `Int` (PostgreSQL `INTEGER`, 32-bit signed) |
| Unit | **Paise.** ₹1 = 100 paise. ₹10,000 = 1,000,000 paise. |
| Max single value | 2,147,483,647 paise = ~₹2.14 crore. Safe for v1 (Diamond cap is ₹5L = 50,000,000 paise). |
| Track B note | When we cross ₹2 crore single-room values (years away), migrate to `BigInt`. |
| Forbidden types | `Float`, `Decimal`, `Numeric`. Floating-point money is malpractice. |
| Display | Conversion to ₹ happens in the API response layer only. UI shows ₹. |
| Basis points | Commission stored as `Int` basis points (`500` = 5%). Avoids fractional percentages. |

This is one of the things that gets violated when the dev is in a hurry. **Code review must reject any `Float`/`Decimal` column for money.**

---

## 4. Time conventions

- All `DateTime` columns are `@db.Timestamptz`. Postgres stores in UTC.
- API layer converts to **IST (Asia/Kolkata)** for display.
- Cron schedules: defined in IST, converted to UTC for the scheduler.
- "Day boundaries" (e.g., "payment due on day N") use IST calendar days.
- Never store local time without a timezone. Bugs hide in tz-naive columns; they will eventually corrupt the ledger.

---

## 5. PII inventory and classification

This is the canonical map of where personal data lives. The DPO uses this. Every new column with PII must be added here.

| Schema.Table.Column | Classification | Retention | Disclosure on data request |
|---|---|---|---|
| `iam.users.phone` | Personal | While active + 7y | Yes |
| `iam.users.name` | Personal | While active + 7y | Yes |
| `iam.users.email` | Personal | While active + 7y | Yes |
| `iam.devices.fingerprint` | Personal (pseudonymous) | While active + 90d | Yes |
| `iam.devices.fcm_token` | Personal (pseudonymous) | While active + 30d | No (operational) |
| `iam.sessions.*` | Operational | 30d after expiry | No |
| `iam.refresh_tokens.*` | Operational | 90d after expiry | No |
| `iam.otp_attempts.*` | Operational | 30d | No |
| `verification.verification_attempts.external_ref_id` | Operational | 7y (KYC reg) | No |
| `verification.verification_results.pan_last4` | Sensitive (PAN derivative) | 7y | Yes |
| `verification.verification_results.bank_acc_last4` | Sensitive | 7y | Yes |
| `verification.verification_results.bank_ifsc` | Sensitive | 7y | Yes |
| `room.rooms.foreman_user_id` | Pseudonymous link | Forever (ledger) | Yes |
| `room.rooms.rules_text` | User content | Forever | Yes |
| `room.invitations.recipient_phone` | Personal | 1y | Yes |
| `ledger.ledger_events.*` | Financial (immutable) | **Permanent** | Yes (own events) |
| `ledger.contribution_status.upi_reference` | Sensitive | Permanent | Yes |
| `ledger.contribution_status.screenshot_url` | User-supplied, may contain PII | Permanent | Yes |
| `ledger.payout_status.screenshot_url` | Same as above | Permanent | Yes |
| `dispute.disputes.reason` | User content | 7y | Yes |
| `dispute.dispute_evidence.file_url` | User content | 7y | Yes |
| `notification.notification_log.body` | Personal (may contain PII) | 1y | Yes |
| `audit.audit_log.actor_ip` | Personal | 7y | Yes |
| `audit.audit_log.actor_user_agent` | Pseudonymous | 7y | Yes |
| `gems.redemptions.voucher_code` | Sensitive (bearer instrument) | App-encrypted; 90d after use | Yes |
| `admin.admin_users.password_hash` | Credential | While admin active | No |
| `admin.admin_users.totp_secret` | Credential | While admin active | No |

### 5.1 PII never persisted (data minimisation)

| Item | Why we don't store it | Where it lives |
|---|---|---|
| Full PAN | Last-4 sufficient for any check | KYC partner only |
| Full Aadhaar | Never needed; only hash/ref | UIDAI / Sub-KUA partner |
| Full bank account | Last-4 + IFSC sufficient | KYC partner |
| OTP (cleartext) | We store SHA-256 of OTP for verification | Never |
| Refresh token (cleartext) | We store SHA-256 | Never |
| Admin password (cleartext) | bcrypt 12 rounds | Never |
| User contact list | Never imported in v1 | Device only |

### 5.2 Application-level encryption (NOT column-level Postgres encryption)

- `gems.redemptions.voucher_code` — encrypted with a service-managed key (AES-256-GCM) before insert. Decrypted only at user-read time. Reason: a voucher code is a bearer instrument; a database dump shouldn't be cashable.
- `admin.admin_users.totp_secret` — same.

We do *not* application-encrypt PAN-last-4 or bank-last-4; the data is already minimised, and encrypting it would defeat any future joins/search needed for KYC compliance reports.

---

## 6. ER diagram

The diagram below uses module colours implicitly via Mermaid's grouping. Cross-schema arrows are dashed (`-..->`), within-schema FKs are solid.

```mermaid
erDiagram

  %% ============ iam ============
  USERS ||--o{ DEVICES : has
  USERS ||--o{ SESSIONS : has
  USERS ||--o{ USER_ROLES : has
  DEVICES ||--o{ SESSIONS : "issued on"
  DEVICES ||--o{ REFRESH_TOKENS : "issued on"

  USERS {
    uuid id PK
    string phone UK
    string name
    UserStatus status
    string language
    timestamptz created_at
  }
  DEVICES {
    uuid id PK
    uuid user_id FK
    string fingerprint
    string platform
    string fcm_token
    bool is_revoked
  }
  SESSIONS {
    uuid id PK
    uuid user_id FK
    uuid device_id FK
    timestamptz expires_at
  }
  REFRESH_TOKENS {
    uuid id PK
    uuid user_id
    uuid device_id FK
    string token_hash UK
    uuid family
    uuid parent_id
  }
  OTP_ATTEMPTS {
    uuid id PK
    string phone
    string otp_hash
    timestamptz expires_at
  }
  USER_ROLES {
    uuid id PK
    uuid user_id FK
    Role role
  }

  %% ============ verification (links to iam.users by uuid only) ============
  USERS ||..o{ VERIFICATION_ATTEMPTS : "uuid ref"
  USERS ||..o{ VERIFICATION_RESULTS : "uuid ref"

  VERIFICATION_ATTEMPTS {
    uuid id PK
    uuid user_id
    VerificationType type
    string provider
    VerificationStatus status
  }
  VERIFICATION_RESULTS {
    uuid id PK
    uuid user_id
    VerificationType type
    string pan_last4
    string bank_acc_last4
    timestamptz verified_at
  }

  %% ============ room ============
  USERS ||..o{ ROOMS : "foreman uuid ref"
  USERS ||..o{ ROOM_MEMBERS : "uuid ref"
  ROOMS ||--o{ ROOM_MEMBERS : has
  ROOMS ||--o{ INVITATIONS : has

  ROOMS {
    uuid id PK
    string code UK
    uuid foreman_user_id
    int contribution_amount_paise
    int member_count_target
    RoomStatus status
    int current_cycle
    int total_cycles
  }
  ROOM_MEMBERS {
    uuid id PK
    uuid room_id FK
    uuid user_id
    bool has_won
    int won_in_cycle
  }
  INVITATIONS {
    uuid id PK
    uuid room_id FK
    InvitationChannel channel
    string invite_token UK
    timestamptz expires_at
  }

  %% ============ auction ============
  ROOMS ||..o{ AUCTIONS : "uuid ref by room_id+cycle"
  AUCTIONS ||--o{ BIDS : has

  AUCTIONS {
    uuid id PK
    uuid room_id
    int cycle
    AuctionStatus status
    timestamptz closes_at
    int pool_amount
    uuid winner_user_id
    int final_discount
    int net_payout
  }
  BIDS {
    uuid id PK
    uuid auction_id FK
    uuid bidder_user_id
    int discount_amount
    timestamptz placed_at
  }

  %% ============ ledger ============
  LEDGER_EVENTS {
    uuid id PK
    timestamptz occurred_at
    uuid aggregate_id
    string aggregate_type
    string event_type
    jsonb payload
    string idempotency_key UK
  }
  CONTRIBUTION_STATUS {
    uuid id PK
    uuid room_id
    int cycle
    uuid member_user_id
    int amount
    ContributionState status
    timestamptz due_at
  }
  PAYOUT_STATUS {
    uuid id PK
    uuid room_id
    int cycle
    uuid winner_user_id
    int amount
    PayoutState status
  }

  %% ============ trust ============
  USERS ||..o| TRUST_SCORE_CURRENT : "uuid ref"
  USERS ||..o{ TRUST_EVENTS : "uuid ref"

  TRUST_EVENTS {
    uuid id PK
    uuid user_id
    string event_type
    int score_delta
    string source_module
    string idempotency_key UK
  }
  TRUST_SCORE_CURRENT {
    uuid user_id PK
    int score
    TrustTier tier
    timestamptz last_event_at
  }
  TRUST_TIER_HISTORY {
    uuid id PK
    uuid user_id
    TrustTier from_tier
    TrustTier to_tier
  }

  %% ============ gems ============
  USERS ||..o| GEM_BALANCES : "uuid ref"
  USERS ||..o{ GEM_EVENTS : "uuid ref"
  USERS ||..o{ REDEMPTIONS : "uuid ref"

  GEM_EVENTS {
    uuid id PK
    uuid user_id
    int gem_delta
    string event_type
  }
  GEM_BALANCES {
    uuid user_id PK
    int balance
    int lifetime_earned
  }
  REDEMPTIONS {
    uuid id PK
    uuid user_id
    string voucher_sku
    int gems_spent
    int inr_value
    RedemptionStatus status
  }

  %% ============ dispute ============
  DISPUTES ||--o{ DISPUTE_EVIDENCE : has

  DISPUTES {
    uuid id PK
    DisputeType type
    uuid room_id
    int cycle
    uuid filed_by_user_id
    uuid against_user_id
    DisputeStatus status
    timestamptz decide_by_at
    DisputeOutcome outcome
  }
  DISPUTE_EVIDENCE {
    uuid id PK
    uuid dispute_id FK
    EvidenceType type
    string file_url
  }

  %% ============ notification ============
  OUTBOX_EVENTS {
    uuid id PK
    NotificationChannel channel
    uuid recipient_user_id
    string template_key
    OutboxStatus status
    string idempotency_key UK
  }
  NOTIFICATION_LOG {
    uuid id PK
    uuid user_id
    NotificationChannel channel
    string title
    string body
    timestamptz read_at
  }
  NOTIFICATION_PREFERENCES {
    uuid user_id PK
    bool payment_reminders_push
    string language
  }

  %% ============ audit ============
  AUDIT_LOG {
    uuid id PK
    uuid actor_user_id
    ActorType actor_type
    string action
    string resource_type
    uuid resource_id
    jsonb changes
  }

  %% ============ admin ============
  ADMIN_USERS {
    uuid id PK
    uuid user_id UK
    string email UK
    string password_hash
    AdminRole role
  }
  ADMIN_ACTIONS {
    uuid id PK
    uuid admin_user_id
    string action
    uuid target_user_id
    string reason
  }
```

(Mermaid renders fine in GitHub / VS Code / Obsidian. For a higher-fidelity export, the next step is to drop the same model into [dbdiagram.io](https://dbdiagram.io) — I'll generate a DBML file in a later pass if needed.)

### 6.1 What the diagram does *not* show

- The hot indexes (see §8) — too noisy to draw.
- The JSON payload shapes of `ledger_events` and `outbox_events` — captured in §7.
- Soft-delete columns — there are none. We don't soft-delete in v1 except via status enums. Soft-delete columns are a famous bug factory.

---

## 7. Per-module notes (the why, not the schema)

The schema itself is in `schema.prisma`. This section flags the design subtleties.

### 7.1 `iam`

- **Refresh-token family detection.** `family` is a UUID shared across the rotation chain originating from one login. `parent_id` points to the previous token. If a token is presented whose `used_at` is non-null (i.e. someone tried to use an already-rotated token), we revoke the entire family. This catches refresh-token theft. See Architecture §7.1.
- **OTP storage.** We never store the OTP itself, only `SHA-256(otp || phone)`. The salt-with-phone prevents rainbow-table attacks against the hash even though OTPs are 6 digits.
- **Role enum is *small* on purpose.** `member` and `foreman` are intentionally *not* enum values. `member` is implicit for any authenticated user. `foreman` is derived from "owns ≥1 active room." Keeping these out of the role table avoids drift between "role row says foreman" and "no rooms exist."

### 7.2 `verification`

- **`verification_attempts` vs `verification_results`.** Attempts log every try (including failures, for analytics and abuse detection). Results capture the *current verified state* per (user, type). One result row per (user, type); `UNIQUE(user_id, type)`.
- **`expires_at` on results** is for the periodic bank-account re-verify (every 6 months). Null on PAN (PAN doesn't expire).

### 7.3 `room`

- **`code` UNIQUE.** 6-character alphanumeric (avoiding ambiguous chars: no `0`, `O`, `I`, `1`). Generated by the service; collision-checked on insert with retry (3 attempts, then service-generated longer code as fallback).
- **`foreman_commission_bps`** stored in basis points (not percentage) to avoid float. Cap of 500 (=5%) enforced in the service per Chit Funds Act §17.
- **No `is_active` boolean.** Status is captured by the `status` enum; redundant booleans are a future inconsistency bug.
- **`hasWon` and `wonInCycle` on RoomMember.** These are projection columns kept current by the auction event handler. The source of truth is the `ledger_events` + `auctions` tables. We accept the duplication because the foreman dashboard needs "members who haven't won yet" in <50ms and a join across schemas would violate §2.

### 7.4 `auction`

- **`UNIQUE(auction_id, bidder_user_id)`** on `bids`. This is the *single* constraint that enforces "one bid per bidder per auction." It also serves as our idempotency key (re-posting the same bid throws a unique-violation, which the controller maps to 409 Conflict).
- **`UNIQUE(room_id, cycle)`** on `auctions`. Cannot have two auctions for the same cycle.
- **Composite index `(auction_id, discount_amount, placed_at)`** is the *most important* index in the auction module. The close worker reads bids in this exact order to pick the winner; with this index, it's an index-only scan.
- **`status='closed'` is terminal.** No re-opening. Cancellation goes through a separate transition.

### 7.5 `ledger`

- **Append-only, enforced by trigger** (added in migration; Prisma doesn't model it). The trigger blocks `UPDATE` and `DELETE` on `ledger_events`:
  ```sql
  CREATE OR REPLACE FUNCTION ledger.block_mutation() RETURNS trigger AS $$
  BEGIN
    RAISE EXCEPTION 'ledger_events is append-only';
  END $$ LANGUAGE plpgsql;

  CREATE TRIGGER ledger_no_update BEFORE UPDATE ON ledger.ledger_events
    FOR EACH ROW EXECUTE FUNCTION ledger.block_mutation();
  CREATE TRIGGER ledger_no_delete BEFORE DELETE ON ledger.ledger_events
    FOR EACH ROW EXECUTE FUNCTION ledger.block_mutation();
  ```
  Same triggers on `audit.audit_log`. This is paranoia; we want it.

- **`payload` JSONB shape**, by event type (informal — codified in TypeScript types):
  - `ContributionMarkedPaid`: `{ roomId, cycle, memberUserId, amount, upiReference, screenshotUrl }`
  - `ContributionConfirmed`: `{ contributionEventId, confirmedBy }`
  - `BidPlaced`: `{ auctionId, bidderUserId, discountAmount }`
  - `AuctionClosed`: `{ auctionId, winnerUserId, finalDiscount, foremanCommission, netPayout, selectionMethod, bidIds[] }`

- **`idempotency_key`** is the single most-used protection in this schema. Format examples in §9.

### 7.6 `trust`

- **`trust_score_current` is a projection**, rebuildable from `trust_events`. We replay events when the score formula changes (rare but allowed). This is what "glass-box score" means — every change is traceable.
- **`trust_tier_history`** is for charts and for proving to a user "you became Silver on this date."

### 7.7 `gems`

- **Pattern matches `trust`** (events → balance projection) by design. Familiarity = fewer bugs.
- **Voucher code is encrypted before write** at the service layer (AES-256-GCM, key from env). Decrypted on user read. A `pg_dump` does not leak cashable codes.

### 7.8 `dispute`

- **Two timestamps for SLA tracking.** `respond_by_at` (48h from filing) and `decide_by_at` (7d from filing). The reaper job scans `WHERE status IN ('open','awaiting_response','responded') AND decide_by_at < now()` to escalate.
- **`source_event_id`** is a UUID pointer into `ledger.ledger_events`. Not an FK (cross-module rule). The service validates on insert.

### 7.9 `notification`

- **`outbox_events`** is the workhorse. The dispatcher's query (see §12 Q-12) uses `SELECT ... FOR UPDATE SKIP LOCKED` to safely parallelise.
- **`notification_log`** is the user-visible inbox. The split between `outbox_events` (transient, dispatch infra) and `notification_log` (durable, user-facing) is deliberate: we can wipe dispatched outbox rows after 30 days without affecting the inbox.

### 7.10 `audit`

- **Mandatory write on every mutation.** Enforced by a NestJS interceptor in `src/shared/audit`, not by triggers. Reason: we want the `actor_*` and `request_id` context, which is only available at the application layer.
- **`changes` JSONB** is `{before: {...}, after: {...}}` for critical actions. Optional for everything else (would explode storage).

### 7.11 `admin`

- **`admin_users.user_id`** mirrors `iam.users.id`. Every admin is also a normal user (so they can test the consumer flow). Admin login is a *separate flow* from user OTP — admins use email + password + TOTP.
- **`admin_actions.reason` is `NOT NULL`.** This is not optional. The schema enforces auditability.

### 7.12 `shared`

- **`job_locks`** backs the application-layer idempotency for scheduled jobs (BullMQ has its own dedup, but it expires; we want long-window dedup for things like monthly auctions).

---

## 8. Index plan

Indexes are listed in two buckets: **structural** (uniqueness / FK support — non-negotiable) and **performance** (chosen for specific queries). Every performance index has a query in §12 that justifies it.

### 8.1 Structural

Already declared via `@unique`, `@@unique`, and the implicit indexes on FK columns. Not re-listed here.

### 8.2 Performance indexes (with target query and rationale)

| # | Index | Justifies query | Rationale |
|---|---|---|---|
| I-1 | `iam.users (status)` | admin user-list filter | Selective for `suspended`/`flagged`. |
| I-2 | `iam.users (last_seen_at)` | inactivity decay job | Trust decay scans `last_seen_at < now() - 90 days`. |
| I-3 | `iam.devices (fcm_token)` | push send / token rotation | Reverse lookup when FCM reports a stale token. |
| I-4 | `iam.devices (user_id, is_revoked)` | active devices for user | Login flow. |
| I-5 | `iam.sessions (user_id, expires_at)` | session validation | Common. |
| I-6 | `iam.refresh_tokens (family)` | family revocation on theft | Critical for security path. |
| I-7 | `iam.refresh_tokens (expires_at)` | cleanup job | Daily prune. |
| I-8 | `iam.otp_attempts (phone, created_at DESC)` | OTP rate limit + verify | Hot. |
| I-9 | `iam.otp_attempts (expires_at)` | cleanup job | Daily prune. |
| I-10 | `verification.verification_attempts (status, created_at)` | provider-success-rate dashboard | Ops. |
| I-11 | `verification.verification_results (expires_at)` | bank re-verify reminder | Cron. |
| I-12 | `room.rooms (foreman_user_id, status)` | foreman dashboard "my rooms" | Hot — every foreman login. |
| I-13 | `room.rooms (status, created_at)` | admin room search | Ops. |
| I-14 | `room.room_members (user_id)` | "rooms I'm in" | Hot. |
| I-15 | `room.room_members (room_id, has_won)` | "who can still bid?" in auction prep | Critical for auction open. |
| I-16 | `room.invitations (recipient_phone)` | invitation lookup at signup | Onboarding flow. |
| I-17 | `auction.auctions (status, closes_at)` | reaper, scheduler | Critical. |
| I-18 | `auction.auctions (winner_user_id)` | "rooms I've won" history | User profile. |
| I-19 | `auction.bids (auction_id, discount_amount, placed_at)` | winner selection at close | **Most-read index in v1.** |
| I-20 | `ledger.ledger_events (aggregate_id, occurred_at)` | projection rebuild | Common in ops. |
| I-21 | `ledger.ledger_events (event_type, occurred_at)` | analytics, ops queries | Ops. |
| I-22 | `ledger.ledger_events (actor_user_id, occurred_at DESC)` | user activity history | DSR / user-facing. |
| I-23 | `ledger.contribution_status (member_user_id, status)` | "what do I owe?" on dashboard | Hot — every member login. |
| I-24 | `ledger.contribution_status (room_id, cycle)` | foreman cycle view | Hot. |
| I-25 | `ledger.contribution_status (status, due_at)` | overdue scanner | Hourly job. |
| I-26 | `ledger.payout_status (winner_user_id)` | "payouts owed to me" | Profile. |
| I-27 | `trust.trust_events (user_id, occurred_at DESC)` | user score history | User profile. |
| I-28 | `trust.trust_score_current (tier)` | aggregate by tier | Analytics. |
| I-29 | `gems.gem_events (user_id, occurred_at DESC)` | user gem history | Profile. |
| I-30 | `gems.redemptions (user_id, requested_at DESC)` | "my voucher history" | Profile. |
| I-31 | `dispute.disputes (room_id, status)` | foreman dispute queue | Hot. |
| I-32 | `dispute.disputes (status, decide_by_at)` | SLA reaper | Daily. |
| I-33 | `notification.outbox_events (status, next_retry_at)` | outbox dispatcher | **Hottest write-then-read in v1.** |
| I-34 | `notification.outbox_events (recipient_user_id, created_at DESC)` | debug "did this user get notified?" | Ops. |
| I-35 | `notification.notification_log (user_id, dispatched_at DESC)` | in-app inbox | Hot. |
| I-36 | `notification.notification_log (user_id, read_at)` | unread badge | Hot. |
| I-37 | `audit.audit_log (actor_user_id, occurred_at DESC)` | per-user audit view | DSR / ops. |
| I-38 | `audit.audit_log (resource_type, resource_id, occurred_at DESC)` | per-resource audit view | Ops. |
| I-39 | `audit.audit_log (action, occurred_at)` | action-frequency analytics | Ops. |
| I-40 | `admin.admin_actions (admin_user_id, performed_at DESC)` | admin activity log | Ops. |

### 8.3 Indexes deliberately NOT created in MVP

- **GIN on JSONB payloads.** Tempting for ledger/audit. Costly to maintain on append-heavy tables. Add only when a specific query in §12 is too slow.
- **Text search on `room.name` or `dispute.reason`.** No search in v1 UX.
- **Partial indexes** for things like `WHERE status='open'`. Will revisit after the first month of prod metrics — premature.

---

## 9. Idempotency-key catalogue

Every state-changing endpoint either has a natural uniqueness (`UNIQUE(auction_id, bidder_user_id)` on bids) or an `idempotency_key` column on the inserted row. Clients must send `Idempotency-Key` header on POST/PATCH; the server constructs the DB key from request context + that header.

| Endpoint | Key format | Window |
|---|---|---|
| `POST /auth/otp/request` | `otp_req:{phone}:{hour_bucket}` | 1 hour (sliding) |
| `POST /auth/otp/verify` | `otp_verify:{phone}:{otp_hash}` | 5 minutes |
| `POST /auth/refresh` | natural (token_hash UNIQUE) | n/a |
| `POST /verification/pan` | `pan:{user_id}:{client_request_id}` | 24h |
| `POST /verification/bank` | `bank:{user_id}:{client_request_id}` | 24h |
| `POST /rooms` | `room_create:{foreman_id}:{client_request_id}` | 24h |
| `POST /rooms/:id/start` | `room_start:{room_id}` | permanent (single transition) |
| `POST /rooms/:id/join` | `room_join:{room_id}:{user_id}` | permanent (RoomMember unique) |
| `POST /rooms/:id/cancel` | `room_cancel:{room_id}` | permanent |
| `POST /auctions/:id/bids` | natural (UNIQUE on auction_id+bidder) | n/a |
| `POST /contributions/mark-paid` | `contrib_mark:{room_id}:{cycle}:{user_id}` | 24h |
| `POST /contributions/:event_id/confirm` | `contrib_confirm:{event_id}` | permanent |
| `POST /contributions/:event_id/dispute` | `contrib_dispute:{event_id}` | permanent (one dispute per contribution event) |
| `POST /payouts/mark` | `payout_mark:{room_id}:{cycle}` | permanent |
| `POST /payouts/:event_id/confirm` | `payout_confirm:{event_id}` | permanent |
| `POST /disputes/:id/respond` | `dispute_respond:{dispute_id}` | permanent |
| `POST /disputes/:id/decide` | `dispute_decide:{dispute_id}` | permanent |
| `POST /redemptions` | `redeem:{user_id}:{client_request_id}` | 24h |
| Scheduled `auction.open` | `auction_open:{room_id}:{cycle}` | permanent |
| Scheduled `auction.close` | `auction_close:{auction_id}` | permanent |
| Scheduled `payment.reminder` | `pay_reminder:{room_id}:{cycle}:{phase}:{date}` | per day |
| Scheduled `outbox.dispatch` | natural (per outbox_event id) | n/a |

**Why so explicit:** the easiest way to corrupt a financial ledger is a double-confirmed contribution. Each of these keys exists to make that specific bug impossible.

---

## 10. Migration plan

### 10.1 Tool

**Prisma Migrate.** Migrations live in `prisma/migrations/`. Every PR that changes schema includes a migration; CI rejects schema drift.

### 10.2 Bootstrap migration (init)

Prisma's multi-schema support does **not** create schemas — the DB user must own them and they must exist before `prisma migrate`. We add a pre-migration bootstrap script:

```sql
-- prisma/migrations/00000000000000_bootstrap/migration.sql

CREATE SCHEMA IF NOT EXISTS iam;
CREATE SCHEMA IF NOT EXISTS verification;
CREATE SCHEMA IF NOT EXISTS room;
CREATE SCHEMA IF NOT EXISTS auction;
CREATE SCHEMA IF NOT EXISTS ledger;
CREATE SCHEMA IF NOT EXISTS trust;
CREATE SCHEMA IF NOT EXISTS gems;
CREATE SCHEMA IF NOT EXISTS dispute;
CREATE SCHEMA IF NOT EXISTS notification;
CREATE SCHEMA IF NOT EXISTS audit;
CREATE SCHEMA IF NOT EXISTS admin;
CREATE SCHEMA IF NOT EXISTS shared;

-- pgcrypto for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- pg_trgm reserved for v1.5 if/when we add text search
-- CREATE EXTENSION IF NOT EXISTS pg_trgm;
```

### 10.3 Append-only triggers (post-table-creation migration)

```sql
-- prisma/migrations/00000000000001_append_only_triggers/migration.sql

CREATE OR REPLACE FUNCTION shared.block_mutation()
RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION '% is append-only', TG_TABLE_NAME;
END $$ LANGUAGE plpgsql;

CREATE TRIGGER ledger_events_no_update
  BEFORE UPDATE ON ledger.ledger_events
  FOR EACH ROW EXECUTE FUNCTION shared.block_mutation();

CREATE TRIGGER ledger_events_no_delete
  BEFORE DELETE ON ledger.ledger_events
  FOR EACH ROW EXECUTE FUNCTION shared.block_mutation();

CREATE TRIGGER audit_log_no_update
  BEFORE UPDATE ON audit.audit_log
  FOR EACH ROW EXECUTE FUNCTION shared.block_mutation();

CREATE TRIGGER audit_log_no_delete
  BEFORE DELETE ON audit.audit_log
  FOR EACH ROW EXECUTE FUNCTION shared.block_mutation();
```

### 10.4 Order of migration application

1. `00000000000000_bootstrap` — schemas + extensions
2. `prisma migrate` — generates everything from `schema.prisma`
3. `00000000000001_append_only_triggers` — applies triggers AFTER tables exist
4. `00000000000002_seed_prod_constants` — voucher SKU catalogue, notification templates (see §13.2)

### 10.5 Migration rollback strategy

| Migration type | Rollback strategy |
|---|---|
| Adding a column (nullable, no default) | Reverse migration drops it. Safe. |
| Adding a column (NOT NULL, with default) | Two-step: nullable + backfill + alter. Reverse migration drops it. |
| Adding an index | Reverse migration drops it. Safe but slow on big tables (concurrent drop in Track B). |
| Renaming a column | **Forbidden in prod.** Always add new + dual-write + cut over + drop old. Three migrations, three deploys. |
| Dropping a column | **Multi-step.** Stop writing in code (deploy 1) → drop column (deploy 2). Never combined. |
| Dropping a table | Same multi-step. |
| Adding a constraint that may fail (CHECK, UNIQUE) | Apply `NOT VALID` first, validate after backfill. |

### 10.6 What's forbidden in any migration

- `DROP COLUMN` in the same PR as the code change removing it.
- `RENAME` of a column or table.
- Removing rows from `ledger_events` or `audit_log`. (Triggers also prevent this; the discipline is layered.)
- Long-running migrations on tables >1M rows without `CONCURRENTLY`.
- Lock-taking migrations during business hours. Migrations run during deploy windows (pre-09:00 IST or post-23:00 IST).

---

## 11. Data retention policy

| Data class | Retention | Mechanism |
|---|---|---|
| Active user data | While account active | n/a |
| Deleted user (DSR-triggered "delete me") | 30-day grace, then hard delete in `iam` + anonymisation in `room`, `auction`, `ledger` (replace `user_id` with reserved sentinel `00000000-...-deleted`) | Job: `iam.dsr.delete` |
| `ledger_events` | **Permanent.** Even on user delete; we only anonymise the actor reference. | Trigger-protected |
| `audit.audit_log` | 7 years | Annual archive job (Track B); MVP keeps in primary DB |
| `iam.otp_attempts` | 30 days | Daily prune job |
| `iam.refresh_tokens` (revoked) | 90 days | Daily prune job |
| `iam.sessions` (expired) | 30 days | Daily prune job |
| `notification.outbox_events` (dispatched) | 30 days | Daily prune job |
| `notification.outbox_events` (failed) | 90 days | Daily prune job |
| `notification.notification_log` | 365 days | Daily prune job |
| `verification.verification_attempts` (failed) | 90 days | Daily prune job |
| `verification.verification_results` | 7 years from last reference | Track B archive |
| `gems.redemptions` (voucher_code field) | Cleared 90 days after `fulfilled_at` | Daily prune job (column-level) |

### 11.1 Anonymisation, not deletion, for financial events

When a user invokes their DPDP "right to be forgotten":

1. We delete from `iam.users` and cascade dependents within `iam`.
2. We **do not** delete `ledger_events`, `audit_log`, `trust_events`, `gem_events`, `disputes`, etc.
3. We update the `user_id` columns in those events to a fixed sentinel UUID (`00000000-0000-0000-0000-000000000001`).
4. We retain the right to do this under DPDP's exception for legal/accounting records (§17.1 PRD).
5. We notify the user via the same channel they used for the deletion request, with the retention rationale.

This is **legally defensible**, not optional. Deleting financial records on demand creates evidentiary holes that hurt every other user.

---

## 12. Query catalogue (top 30 hot paths)

Each query gets an intent, an expected access pattern, and the index that supports it. Phase 4 (API Design) will turn these into actual repository methods; Phase 5 (Backend) will benchmark them with `EXPLAIN ANALYZE` on seeded data.

| # | Intent | Query shape | Supporting index | Expected access |
|---|---|---|---|---|
| Q-1 | Login: find user by phone | `SELECT * FROM iam.users WHERE phone = ?` | UNIQUE on phone | Index-only on lookup, table fetch |
| Q-2 | Refresh token rotation | `SELECT ... FROM iam.refresh_tokens WHERE token_hash = ? AND used_at IS NULL AND revoked_at IS NULL` | UNIQUE on token_hash | Index-only candidate |
| Q-3 | Revoke refresh family on theft | `UPDATE iam.refresh_tokens SET revoked_at=now() WHERE family = ?` | I-6 | Range scan, small |
| Q-4 | Dashboard: my active rooms | `SELECT * FROM room.room_members rm JOIN room.rooms r ON r.id = rm.room_id WHERE rm.user_id = ? AND r.status = 'active'` | I-14 + status filter | Two-table; same schema, FK join allowed |
| Q-5 | Foreman dashboard | `SELECT * FROM room.rooms WHERE foreman_user_id = ? AND status IN ('recruiting','active')` | I-12 | Index range |
| Q-6 | Join room by code | `SELECT * FROM room.rooms WHERE code = ?` | UNIQUE on code | Index-only |
| Q-7 | Trust Gate check at join | `SELECT score, tier FROM trust.trust_score_current WHERE user_id = ?` | PK | Index-only |
| Q-8 | "Has user hit room cap?" | `SELECT count(*) FROM room.room_members rm JOIN room.rooms r ON r.id = rm.room_id WHERE rm.user_id = ? AND r.status = 'active'` | I-14, then PK | Two-table; bounded by tier cap |
| Q-9 | Scheduler: open due auctions | `SELECT * FROM auction.auctions WHERE status = 'scheduled' AND opened_at <= now()` | I-17 (modified) | Small set |
| Q-10 | Close auction — pick winner | `SELECT * FROM auction.bids WHERE auction_id = ? ORDER BY discount_amount ASC, placed_at ASC LIMIT 1 FOR UPDATE` | I-19 | Index-only top-1 |
| Q-11 | Auction history per room | `SELECT * FROM auction.auctions WHERE room_id = ? ORDER BY cycle` | UNIQUE(room_id, cycle) | Index range |
| Q-12 | **Outbox dispatcher** | `SELECT * FROM notification.outbox_events WHERE status = 'pending' AND (next_retry_at IS NULL OR next_retry_at <= now()) ORDER BY created_at LIMIT 50 FOR UPDATE SKIP LOCKED` | I-33 | Hot — runs every 2s |
| Q-13 | Overdue contribution scanner | `SELECT * FROM ledger.contribution_status WHERE status IN ('pending','marked_paid') AND due_at < now() - interval '48 hours'` | I-25 | Hourly job |
| Q-14 | "What do I owe?" | `SELECT * FROM ledger.contribution_status WHERE member_user_id = ? AND status IN ('pending','marked_paid','disputed','overdue')` | I-23 | Hot, per login |
| Q-15 | Foreman cycle view | `SELECT * FROM ledger.contribution_status WHERE room_id = ? AND cycle = ?` | I-24 | Hot per foreman session |
| Q-16 | Trust history | `SELECT * FROM trust.trust_events WHERE user_id = ? ORDER BY occurred_at DESC LIMIT 50` | I-27 | Profile view |
| Q-17 | Gem balance | `SELECT * FROM gems.gem_balances WHERE user_id = ?` | PK | Index-only |
| Q-18 | Redemption history | `SELECT * FROM gems.redemptions WHERE user_id = ? ORDER BY requested_at DESC LIMIT 20` | I-30 | Profile view |
| Q-19 | Open dispute queue (foreman) | `SELECT d.* FROM dispute.disputes d WHERE d.room_id IN (?,?,?) AND d.status IN ('open','awaiting_response','responded')` | I-31 + IN | Foreman dashboard |
| Q-20 | Dispute SLA reaper | `SELECT * FROM dispute.disputes WHERE status IN ('open','awaiting_response','responded') AND decide_by_at < now()` | I-32 | Daily |
| Q-21 | In-app inbox | `SELECT * FROM notification.notification_log WHERE user_id = ? ORDER BY dispatched_at DESC LIMIT 30` | I-35 | Hot |
| Q-22 | Unread badge count | `SELECT count(*) FROM notification.notification_log WHERE user_id = ? AND read_at IS NULL` | I-36 | Hot |
| Q-23 | User audit (DSR) | `SELECT * FROM audit.audit_log WHERE actor_user_id = ? ORDER BY occurred_at DESC` | I-37 | On-demand |
| Q-24 | Resource audit | `SELECT * FROM audit.audit_log WHERE resource_type = ? AND resource_id = ? ORDER BY occurred_at DESC` | I-38 | Admin/ops |
| Q-25 | Ledger replay for a room cycle | `SELECT * FROM ledger.ledger_events WHERE aggregate_id = ? ORDER BY occurred_at` | I-20 | Projection rebuild |
| Q-26 | KYC partner success rate | `SELECT provider, status, count(*) FROM verification.verification_attempts WHERE created_at > now() - interval '24 hours' GROUP BY provider, status` | I-10 | Ops dashboard |
| Q-27 | Inactivity scan for decay | `SELECT id FROM iam.users WHERE last_seen_at < now() - interval '90 days' AND status = 'active'` | I-2 | Daily |
| Q-28 | "Who can still bid?" in auction prep | `SELECT user_id FROM room.room_members WHERE room_id = ? AND has_won = false` | I-15 | Per auction open |
| Q-29 | Admin user search by phone | `SELECT * FROM iam.users WHERE phone = ?` | UNIQUE on phone | Index-only |
| Q-30 | Admin room search by code | `SELECT * FROM room.rooms WHERE code = ?` | UNIQUE on code | Index-only |

**Notes**
- Q-12 is the single most-frequent query in the system (every 2 seconds). `SELECT FOR UPDATE SKIP LOCKED` is the magic — it lets us parallelise outbox workers without explicit coordination.
- Q-10 must be index-only or it'll dominate auction-close latency at scale. The composite `(auction_id, discount_amount, placed_at)` includes everything the planner needs.
- Q-4 and Q-8 are *intra-schema* joins — `room.room_members` and `room.rooms` are both in `room`. Cross-schema joins do not appear in this catalogue and won't be added without breaking §2.

---

## 13. Seed data

For local dev + integration tests. Synthetic but realistic.

### 13.1 Demo accounts

```
1.  Lakshmi   (foreman)       +91 90000 00001  Gold tier, score 580
2.  Karthik   (member)        +91 90000 00002  Silver tier, score 250
3.  Rekha     (member)        +91 90000 00003  Bronze tier, score 120
4.  Murugan   (member)        +91 90000 00004  Silver tier, score 310
5.  Anitha    (member)        +91 90000 00005  Bronze tier, score 105
6.  Suresh    (foreman)       +91 90000 00006  Platinum tier, score 820
7.  Diana     (member, new)   +91 90000 00007  Bronze tier, score 100
8.  Vimal     (member, flagged) +91 90000 00008 Bronze tier, score 40
9.  founder@seatu.in (admin/superadmin)
10. ops@seatu.in     (admin)
```

All OTPs in `dev` accept `123456` (env-gated; rejected in `staging`/`prod`).

### 13.2 Seed rooms

| Room | Foreman | Members | Status | Notes |
|---|---|---|---|---|
| "Lakshmi's TextileFund #1" | Lakshmi | 5 | active, cycle 3 of 5 | 1 contribution pending, 1 disputed |
| "Lakshmi's Friends ₹5k" | Lakshmi | 4/10 | recruiting | Joinable, code `LAK001` |
| "Suresh's Premium 1L" | Suresh | 8 | active, cycle 5 of 8 | Open auction closes in 2 hours |
| "Murugan's Old Round" | Murugan (one-off) | 6 | completed | For testing history view |
| "Vimal's Cancelled Round" | Vimal | 3 | cancelled | For testing cancelled state |

### 13.3 Reference data (loaded by migration, not seed)

- **Notification templates** (`notification.templates` *not* in schema — these are code constants for now):
  - `payment.due.t_minus_3`, `payment.due.t_minus_1`, `payment.due.t`, `payment.overdue`, …
- **Voucher SKU catalogue** (`gems.voucher_skus` would be a table — *deferred to v1.1*; in MVP these are code constants):
  - `recharge_10`, `recharge_50`, `recharge_100`
  - `amazon_100`, `amazon_500`
  - `bigbasket_500`, `bigbasket_1000`

Both will graduate to admin-editable DB tables in v1.5 when Ops needs to change them without a deploy.

### 13.4 Seed script structure

```
prisma/seed.ts
├── seedUsers()             # 10 users above + roles
├── seedTrustScores()       # initial scores + a trust event each
├── seedGemBalances()
├── seedRooms()             # 5 rooms in various states
├── seedAuctionsAndBids()   # 1 open, 1 closed, 1 about to close
├── seedContributions()     # variety of states
├── seedDisputes()          # 1 open dispute
└── seedNotifications()     # 5 sample notifications for Lakshmi's inbox
```

Seed is **only** run with `pnpm prisma db seed` in `local`/`dev`/`staging`. **Never in `prod`.** The script asserts `process.env.NODE_ENV !== 'production'` and refuses to run otherwise.

---

## 14. Track B: partitioning and growth

When we cross the thresholds below, this is the playbook. Not for MVP.

| Table | Threshold | Strategy |
|---|---|---|
| `ledger.ledger_events` | >50M rows | Range-partition by month on `occurred_at`. Archive partitions >12 months to S3 Glacier; keep recent in primary. |
| `audit.audit_log` | >100M rows | Same — monthly range partition. |
| `notification.notification_log` | >50M rows | Monthly partition; drop partitions >365 days. |
| `notification.outbox_events` (dispatched) | >10M rows | Move to a separate `notification_archive` schema; keep `outbox_events` to pending+recent only. |
| `iam.otp_attempts` | >5M rows | Already pruned in 30 days; if it grows, drop to 7d retention. |

We do not partition in MVP. Premature partitioning makes development harder and is the wrong fight at <100k users.

### 14.1 Read replicas

Add one read replica when read load on the primary exceeds 70% CPU sustained. Route to replica from:
- Audit views
- Admin dashboards
- Long analytics queries

Never route from:
- Auction close
- Contribution confirm
- Anything in the write path

### 14.2 Connection pooling

PgBouncer in transaction mode, fronted by the API. Critical when worker count grows (each BullMQ worker holds connections). Add in v1.1 even if not strictly needed in v1, because Prisma's behaviour around connection limits is one of the easier ways to take down a small DB.

---

## 15. Risks specific to this schema

| # | Risk | Mitigation |
|---|---|---|
| DR-1 | Cross-schema reference drift (e.g., room.foreman_user_id points at a deleted iam.users row) | Service-layer integrity checks on every write touching cross-module UUIDs; nightly reconciliation job in v1.1. |
| DR-2 | JSONB payload schema drift in `ledger_events` | `event_version` column + TypeScript discriminated-union types; projector handles all known versions. |
| DR-3 | Append-only triggers bypassed by superuser | Migrations run as the `seatu_app` role (which has no superuser privileges). Superuser is only the cloud-managed `postgres` role used by ops. |
| DR-4 | Idempotency-key collisions due to ambiguous client_request_id | Server prepends a UUID derived from `(user_id || endpoint || day)` so two clients can't collide. |
| DR-5 | Voucher code leak via DB dump | App-layer AES-256-GCM encryption; key in env, not DB. Dumps are useless without the key. |
| DR-6 | Trust score drift between projection and events | Daily reconciliation job: pick 1000 random users, replay events, compare. Alert on mismatch. |
| DR-7 | Storage growth from screenshots in disputes | Screenshots in Supabase Storage (not DB); DB stores URL only. Per-dispute cap of 5 evidence files in v1. |

---

## 16. Phase 4 handoff

Phase 4 (API Design) consumes this schema and produces:

1. **REST API spec** (OpenAPI 3.1) for every endpoint listed in PRD §10 and Phase 2 §6.
2. **DTOs** (request/response shapes) — derived from these models, NOT one-to-one with them. Hide internals (e.g., `idempotency_key`, projection columns) from clients.
3. **Validation rules** per endpoint (class-validator decorators).
4. **Error catalogue** — every failure has a stable `error_code`, `http_status`, and `user_message`.
5. **Rate-limit policy per endpoint** (already sketched in Architecture §12.1).
6. **Pagination strategy** — keyset pagination on `(created_at, id)` for all list endpoints. No offset pagination.
7. **API versioning policy** — `/v1/*` prefix, never break in v1, deprecate-not-delete.
8. **Authentication & authorisation matrix** — endpoint × role × required verification level.

---

## End of Phase 3

**Files in this delivery:**
- `SEATU-Database-Phase3.md` (this document)
- `SEATU-schema.prisma` (the runnable schema)

**Next phase:** Phase 4 — API Design. Output is an OpenAPI 3.1 spec, DTOs, error catalogue, validation rules, rate-limit and auth matrices.

**Status:** Awaiting founder review. Approve to proceed, or flag changes — especially around the cross-schema FK rule (§2), the immutability triggers (§7.5, §10.3), or the retention/anonymisation policy (§11).
