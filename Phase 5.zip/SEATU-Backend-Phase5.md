# SEATU — Backend Implementation (Phase 5)

**Phase 5 Deliverable · v0.1 (Draft)**
**Owner:** CTO
**Status:** Awaiting founder review before Phase 6 (Flutter UI)
**Date:** June 2026
**Companion:** `seatu-backend/` (runnable NestJS modular monolith)

---

## 0. What this document covers

The repo (`seatu-backend/`) is the artifact. This document explains the
decisions you can't see in the file structure:

1. Working assumptions (§1)
2. What's actually delivered (§2)
3. Project structure & conventions (§3)
4. Recipe: adding a new endpoint (§4)
5. Recipe: adding a new module (§5)
6. Cross-cutting concerns — how they actually work (§6)
7. The adapter pattern (§7)
8. Auth flow end-to-end (§8)
9. Testing strategy (§9)
10. Local dev (§10)
11. Production deployment notes (§11)
12. What's deliberately stubbed (§12)
13. Phase 6 handoff (§13)

---

## 1. Working assumptions

Carried forward from Phases 1–4. No changes. The two that shape this layer:

- **Modular monolith, not microservices** (ADR-001). Module boundaries are
  package boundaries, not network boundaries.
- **No money movement** (OQ-3). The ledger records evidence — UPI references,
  screenshots — not real transactions.

---

## 2. What's actually delivered

### 2.1 Real, working code

Everything in `src/shared/` and `src/adapters/` is built and wired. So is:

- `src/modules/iam/` — full implementation: OTP request/verify, JWT issue,
  refresh-token rotation with family revocation, device binding, /me, logout.
- `src/modules/room/` — create with all velocity/tier/verification gates, get,
  list, update (draft-only), and the state-machine service that owns every
  transition. This is the reference for every other resource module.
- `src/modules/health/` — `/healthz` (liveness) and `/readyz` (DB ping).

### 2.2 Skeletons

Eight skeleton modules: `verification`, `auction`, `ledger`, `trust`, `gems`,
`dispute`, `notification`, `admin`. Each is a `*.module.ts` placeholder with a
TODO comment pointing at the recipes in §4–§5. Filling these in is mechanical
once you've worked through `iam` and `room`.

### 2.3 Tests

- `test/integration/onboarding.spec.ts` — full onboarding flow with
  Testcontainers Postgres+Redis. Validates token shape, refresh rotation,
  reuse detection, idempotency-key enforcement, unauthenticated rejection.
- `test/unit/tier-rules.spec.ts` — pure-logic unit test as a template.

### 2.4 Infrastructure

- `docker-compose.yml` — Postgres 16 + Redis 7 for local dev.
- `Dockerfile` — multi-stage prod build.
- `.github/workflows/ci.yml` — lint, typecheck, migrate, unit tests,
  integration tests, all on every PR.
- `prisma/` — schema from Phase 3, bootstrap migration (schemas + pgcrypto),
  append-only triggers migration (ledger + audit_log), seed script (10 demo
  users + 3 rooms + 1 open auction).

### 2.5 What's NOT here on purpose

See §12. Short version: the eight skeleton modules, real provider integrations
(Karza, MSG91, FCM, Qwikcilver) past the adapter interface, and admin auth.

---

## 3. Project structure & conventions

### 3.1 The shape of every module

```
src/modules/<name>/
├── <name>.module.ts           NestJS module — declares controllers/providers/exports
├── controllers/
│   └── <name>.controller.ts   Thin: validate, delegate, return DTO
├── services/
│   └── <name>.service.ts      All business logic; the only thing that talks to repos
├── dto/
│   └── *.dto.ts               class-validator decorated request shapes
├── repositories/
│   └── <name>.repository.ts   The ONLY layer that touches Prisma directly
└── mappers/
    └── <entity>.mapper.ts     DB row -> API shape (snake_case, ISO timestamps)
```

The discipline isn't enforced by tooling — it's a code review checklist. The
payoff is that every PR looks the same shape, so reviewers can move fast.

### 3.2 Conventions worth knowing

- **No cross-module DB access.** If module `A` needs data from module `B`'s
  schema, it goes through `B`'s service. No exceptions; this is what keeps
  the monolith decomposable. (Yes, this means you'll inject services across
  modules. That's fine.)
- **No cross-schema foreign keys.** Phase 3 §3 — intra-module FKs only.
  Cross-module references are plain UUIDs.
- **Money is `*Paise: Int`** in the DB and `*_paise: number` on the wire.
  The mapper carries the rename.
- **Timestamps are `DateTime` in Prisma (UTC) and ISO 8601 with offset on
  the wire.** Mapper does the conversion.
- **DTOs use snake_case fields** because the wire format does. The repo's
  internal types use camelCase.
- **Services accept primitive args** (userId, ids, plain objects), not
  controller DTOs. Services should be controller-agnostic.

### 3.3 Imports

- Use absolute paths only across module boundaries: `@/shared/...`,
  `@/modules/<name>/...`. Tsconfig already wires the `@/` alias.
- Inside a module, relative imports are fine (and shorter).
- Never import from `dist/`. Never re-export Prisma types through a barrel.

---

## 4. Recipe: adding a new endpoint

Steps in order, with the reasoning. Use `iam/auth.controller.ts` and
`room/room.controller.ts` as references.

### Step 1 — define the DTO

```ts
// src/modules/foo/dto/foo-create.dto.ts
import { IsString, MinLength } from 'class-validator';

export class FooCreateDto {
  @IsString()
  @MinLength(3)
  name!: string;
}
```

Match Phase 4's field names exactly. snake_case in the body. class-validator
decorators give you free 400 errors via the global validation pipe.

### Step 2 — add a service method

Services own the business logic. Inject `PrismaService`, `EventBus`,
`AuditService`, `OutboxService` as needed.

```ts
async create(actorUserId: string, dto: FooCreateDto) {
  return this.prisma.$transaction(async (tx) => {
    const foo = await tx.foo.create({ data: { name: dto.name, userId: actorUserId } });
    await this.audit.write({ action: 'foo.create', resourceType: 'foo', resourceId: foo.id }, tx);
    return foo;
  });
}
```

Pattern: **business write + audit write happen in the same transaction**.
EventBus + OutboxService get called inside the tx too (the dispatcher polls
after commit).

### Step 3 — add the controller

```ts
@Controller('v1/foos')
export class FooController {
  constructor(private readonly foos: FooService) {}

  @Post()
  @RequireVerification('phone')
  @RateLimit({ scope: 'foos.create', limit: 10, windowSec: 86400, keyBy: 'user' })
  async create(@CurrentUser() u: AuthenticatedUser, @Body() dto: FooCreateDto) {
    return this.foos.create(u.userId, dto);
  }
}
```

- `@CurrentUser()` is set by the JWT strategy and the request-context middleware.
- `@RequireVerification()` is a declarative gate; the PolicyGuard handles it.
- `@RateLimit()` is also declarative; the RateLimitGuard runs before the handler.
- `Idempotency-Key` header is enforced by the idempotency interceptor on
  POST/PATCH/DELETE — you don't write anything in the controller for this.

### Step 4 — declare it in the module

Register the controller and service in `foo.module.ts`. If you split into
repository/mapper, declare those too.

### Step 5 — wire into app.module

If it's a new module, import it in `app.module.ts`. Existing modules don't
need changes when you add endpoints.

### Step 6 — test

- Unit test the service logic (mock Prisma if needed, or use the test app
  with a real DB — your call).
- Integration test the full HTTP round-trip via supertest if the endpoint is
  in one of the four critical flows (auth, room lifecycle, auction, contribution).

That's it. The five gates (auth, role, verification, tier, membership) are all
declarative. The cross-cutting concerns (idempotency, audit, errors, rate
limit, logging) are all centralized. You write controller + service + DTO and
you're done.

---

## 5. Recipe: adding a new module

When you decide a new resource is big enough for its own module:

1. `mkdir -p src/modules/foo/{controllers,services,dto,repositories,mappers}`
2. Create `foo.module.ts` with `@Module({})`.
3. Add it to `app.module.ts` imports.
4. Add a Prisma schema for the new domain (Phase 3 §3 — one schema per module).
5. `pnpm prisma:migrate:dev --name add_foo` — Prisma generates the migration.
6. Add the new entity to `prisma/seed.ts` if it should have demo data.

Per Phase 2 ADR-006: keep module boundaries strict so we can extract a module
into its own service later without rewriting consumers.

---

## 6. Cross-cutting concerns — how they actually work

### 6.1 Errors

Every error in the system ends up as the same envelope:

```json
{
  "error": {
    "code": "ROOM_TRUST_GATE_FAILED",
    "message": "your current tier does not allow this room",
    "user_message": "your current tier does not allow this room",
    "details": { "actual_tier": "bronze", "required_tier": "silver" },
    "request_id": "..."
  }
}
```

How? `GlobalExceptionFilter` (`src/shared/errors/global-exception.filter.ts`):

- `DomainException` → render its `errorCode`, `message`, `details`.
- `HttpException` from a guard / pipe → translate status code → error code.
- Prisma error → swallow message, return `INTERNAL_ERROR`.
- Anything else → log to Sentry, return `INTERNAL_ERROR`.

To throw a domain error from anywhere:

```ts
throw new DomainException(ErrorCode.ROOM_FULL, {
  details: { target: 10, current: 10 },
});
```

The HTTP status is mapped automatically from `ERROR_HTTP_STATUS` in
`error-codes.ts`.

### 6.2 Idempotency

The `IdempotencyInterceptor` is wired as a global interceptor. On every
POST/PATCH/DELETE it:

1. Reads `Idempotency-Key` header.
2. If missing → `IDEMPOTENCY_KEY_MISSING` (400).
3. If present → attaches to `req.idempotencyKey`.

Endpoint-level enforcement happens at the data layer (Phase 3 §9): natural
unique constraints on the inserted rows make replays idempotent without
needing a separate idempotency table. For endpoints with no natural unique
row (rare in MVP), use `@IdempotencyOptional()` and rely on the natural
safety of the operation (e.g. logout-all).

### 6.3 Audit

`AuditService.write({...}, tx?)` accepts an optional Prisma transaction
client. **Always pass `tx`** when called inside `prisma.$transaction()` so the
audit row commits with the business write. Out-of-tx audit writes log on
failure but don't rethrow.

### 6.4 EventBus + Outbox

These are two different things:

- **EventBus** is in-process, synchronous, used for *in-process* reactions
  (e.g., when a `ContributionConfirmed` event fires, the trust module
  increments the score). Lost if the process dies between publish and handler.
- **Outbox** is durable. `OutboxService.enqueue()` writes a row in
  `notification.outbox_events` *inside the same tx* as the business write.
  After the tx commits, `OutboxDispatcher` polls every 2s with `FOR UPDATE
  SKIP LOCKED`, calls the right adapter (push, sms), and marks dispatched.
  Use this for anything that calls an external provider.

Rule of thumb: **internal reactions → EventBus; external side effects →
Outbox**.

### 6.5 Rate limiting

Declarative per endpoint:

```ts
@RateLimit({ scope: 'rooms.create', limit: 3, windowSec: 86400, keyBy: 'user' })
```

The `RateLimitGuard` reads the spec, hashes a Redis key from
`scope + keyBy + key-value`, runs a sliding-window counter, sets the
`X-Ratelimit-*` headers, and throws `RATE_LIMIT_EXCEEDED` if over.

### 6.6 Request context (ALS)

`requestContext` is an `AsyncLocalStorage`. The middleware opens a scope per
request and populates `{ requestId, userId, deviceId, ip }`. From anywhere
in the request — service, repo, async handler — you can call
`getRequestContext()`. The Pino logger automatically tags every line with
`request_id` and `actor_user_id` via this.

### 6.7 Pagination

Use `paginationArgs(cursor, limit)` to turn `(cursor, limit)` into Prisma
`{ take, orderBy, cursor, skip }`. Use `nextCursorFrom(items)` to encode the
next cursor. See `src/shared/pagination/cursor.ts`.

---

## 7. The adapter pattern

Every external system is behind an abstract class:

```
KycAdapter        — abstract class
├── FakeKycAdapter      — always-success; default in dev/test
└── KarzaKycAdapter     — real impl (stub in this delivery)
```

The factory in `src/adapters/adapters.module.ts` picks the impl based on the
env var:

```ts
{
  provide: KycAdapter,
  useFactory: (config, fake, karza) =>
    config.get('KYC_PROVIDER') === 'karza' ? karza : fake,
}
```

**Swap rules:**
- In tests: provider env vars are all `fake` (set in `test/helpers/jest-setup.ts`).
- In dev: usually `fake`. Set to real to do an end-to-end with a sandbox account.
- In staging: real with sandbox creds.
- In prod: real with prod creds.

**No service ever knows which provider it's talking to.** It calls the abstract
class. This is what makes the KYC provider swap (or the SMS provider swap) a
config change, not a code change.

---

## 8. Auth flow end-to-end

```
   ┌─────────────────┐
   │ POST /otp/request │  Public, rate-limited per phone (5/hr)
   └────────┬────────┘
            │  SmsAdapter.sendOtp(phone, code)
            │  Stores hash + salt in iam.otp_challenges
            ▼
   ┌─────────────────┐
   │ POST /otp/verify│  Public
   └────────┬────────┘
            │  Verifies hash; DEV_OTP_BYPASS in non-prod
            │  UserService.registerIfNew → creates User + TrustScore + GemBalance + phone verification
            │  DeviceService.upsert → binds device fingerprint
            │  TokenService.issue → JWT access (RS256/HS256) + opaque refresh
            ▼
        access + refresh
            │
            ▼
   ┌─────────────────┐
   │ Authenticated   │  Authorization: Bearer <jwt> + X-Device-Id
   │ requests        │
   └─────────────────┘
            │
            ▼  When access expires:
   ┌─────────────────┐
   │ POST /refresh   │  Validates refresh hash
   └────────┬────────┘  Rotates (issues new refresh, marks old consumed)
            │           If old refresh is replayed → kills entire family
            ▼
        new bundle
```

Five gates evaluated per request:

1. **JwtAuthGuard** — verifies signature, expiry, audience.
2. **JwtStrategy.validate** — verifies device binding (header matches token claim).
3. **PolicyGuard / @RequireRoles** — checks roles.
4. **PolicyGuard / @RequireVerification** — checks `verification_results` rows.
5. **PolicyGuard / @RequireMinTier** — checks `trust_score_current.tier`.

Membership (you're in this specific room) is checked in the service — it
needs the path parameter to know which room.

---

## 9. Testing strategy

Three layers, fast to slow:

- **Unit tests** — pure logic, no DB. Tier rules, cursor encoding, error
  mapping, mapper functions. Run in <1s. Live in `test/unit/`.
- **Service-level tests with real DB** — Testcontainers Postgres + an
  isolated schema per test file. Tests business logic across a transaction
  boundary. (Not provided in this delivery; recipe in §9.1.)
- **Integration tests** — full Nest app + supertest. Tests the actual HTTP
  contract including guards, interceptors, error envelope. Run in CI;
  ~30s each because of Testcontainers boot. The onboarding test is the
  reference.

### 9.1 Required integration tests for Phase 5.1

Per Phase 2 §6 (critical flows):

- ✅ Onboarding (delivered)
- ⬜ Room lifecycle: create → publish → join (×5) → start → cycle → complete
- ⬜ Auction cycle: open → bid (×4) → close → tie-break → payout
- ⬜ Contribution + dispute: mark-paid → confirm → dispute → respond → decide

Use the onboarding test as a template. Each takes about 100-150 lines of
supertest.

---

## 10. Local dev

```bash
docker compose up -d                    # postgres + redis
cp .env.example .env                    # tweak if you want
pnpm install
pnpm prisma:generate
pnpm prisma:migrate:dev
pnpm db:seed
pnpm start:dev
```

The seed prints demo phones to console. OTP=`123456` in dev (DEV_OTP_BYPASS).

To reset the DB completely: `pnpm db:reset`.

To swap to a real KYC provider for a session:

```bash
KYC_PROVIDER=karza KARZA_API_KEY=... pnpm start:dev
```

---

## 11. Production deployment notes

Per Phase 2 §10.5 (Railway/Render Mumbai region).

- **DATABASE_URL** must include `?sslmode=require` for Supabase/managed PG.
- **REDIS_URL** must include `?family=6` for Upstash global Redis (IPv6).
- **JWT_ALGORITHM=RS256** in prod. Generate keys with
  `openssl genrsa -out jwt-private.pem 2048` and `openssl rsa -in jwt-private.pem -pubout -out jwt-public.pem`,
  then load into env vars (escape newlines as `\n`).
- **DEV_OTP_BYPASS must be unset** in prod. The env schema enforces this.
- **APP_ENCRYPTION_KEY** must be a base64-encoded 32-byte random key. Generate
  with `openssl rand -base64 32`. Rotate annually; both old + new must
  remain valid during the rotation window (kid scheme — Track B).
- **OUTBOX_DISPATCHER** runs in-process for MVP. When you hit
  >100k events/day, split it into its own worker process (same code path,
  just a different entrypoint that imports only `OutboxModule`).
- **SENTRY_DSN** and **POSTHOG_API_KEY** should be set in staging and prod.

### Migrations

In CI, `pnpm prisma:migrate:deploy` is what's used. It's purely additive and
non-interactive. Never run `prisma migrate dev` against a production DB.

---

## 12. What's deliberately stubbed

These are intentional. Each has a clear path forward.

| What | Where | Reason | Path to "real" |
|---|---|---|---|
| Karza KYC | `adapters/kyc/kyc.adapter.ts:KarzaKycAdapter` | No API key in the dev environment | Wire `fetch` calls + add unit tests with `nock` |
| MSG91 SMS | `adapters/sms/sms.adapter.ts:Msg91SmsAdapter` | Same | Same |
| FCM push | `adapters/push/push.adapter.ts:FcmPushAdapter` | Same | Use `firebase-admin` SDK |
| Qwikcilver voucher | `adapters/voucher/voucher.adapter.ts:QwikcilverVoucherAdapter` | Same | Wire `fetch` |
| Supabase storage | `adapters/storage/storage.adapter.ts:SupabaseStorageAdapter` | Same | Use `@supabase/supabase-js` storage client |
| 8 skeleton modules | `modules/{verification,auction,...}/` | One controller pair fully implemented (iam + room) is enough to establish the pattern | Follow §4 recipe; each takes 1–2 dev-days |
| Admin TOTP login | `modules/admin/` | Not in v1.0 critical path | Add a separate token issue path with `aud: 'seatu-admin'` |
| WebSocket auction updates | n/a | Sealed-bid auctions don't need live updates | Add when/if open-bid auctions ship |

The reason this scaffold is large: every shared piece is shared. Once it
exists, each remaining module is mechanical.

---

## 13. Phase 6 handoff

Phase 6 (Flutter UI) consumes:

1. **The OpenAPI YAML** (Phase 4) — feed to `openapi-generator` or `chopper`
   to get Dart client code.
2. **The error code catalogue** (`src/shared/errors/error-codes.ts`) — the
   client switches on these to drive UX (e.g., `PERM_VERIFICATION_REQUIRED` →
   route to KYC screen, `ROOM_TRUST_GATE_FAILED` → show explainer).
3. **The token lifecycle** — store refresh in `flutter_secure_storage`,
   keep access in memory, refresh on 401.
4. **The signed-URL upload contract** — call `/v1/files/upload-url` then PUT
   to the returned URL. Don't try multipart.

Phase 5.1 (parallel with Phase 6, by a backend dev):

- Finish the 8 skeleton modules following §4 recipe.
- Wire real Karza + MSG91 + FCM + Supabase adapters.
- Add 3 more integration tests (room lifecycle, auction, contribution).
- Admin TOTP login.

---

## End of Phase 5

**Status:** Awaiting founder review. Approve to proceed to Phase 6 (Flutter
UI), or flag changes — especially around the module boundaries (§3.1), the
adapter pattern (§7), or the auth model (§8).
